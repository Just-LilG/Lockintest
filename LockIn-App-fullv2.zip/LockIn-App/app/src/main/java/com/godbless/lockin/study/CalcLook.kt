package com.godbless.lockin.study

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.godbless.lockin.ui.Fonts
import kotlin.random.Random

// How the calculator looks, kept apart from how it works. Everything here is drawn with gradients and strokes (no images)
// so it stays crisp on any screen: a moulded body with a fine grain, a recessed LCD under glass, keycaps with a bevel, a
// highlight and a drop of shadow, a metal-ringed direction pad and the little solar strip across the top.

/** Mix [c] towards white by [f]. */
internal fun lighter(c: Color, f: Float): Color = lerp(c, Color.White, f)

/** Mix [c] towards black by [f]. */
internal fun darker(c: Color, f: Float): Color = lerp(c, Color.Black, f)

/** The body of the device: a soft vertical gradient, a faint light from the top, and a fine speckle like moulded plastic. */
internal fun Modifier.calcChassis(): Modifier = this.drawWithCache {
    val rnd = Random(7)
    val specks = List(360) { Offset(rnd.nextFloat() * size.width, rnd.nextFloat() * size.height) to rnd.nextFloat() }
    val body = Brush.verticalGradient(listOf(Color(0xFF1C1C1F), Color(0xFF151517), Color(0xFF0E0E10)))
    val glow = Brush.radialGradient(
        listOf(Color(0x0FFFFFFF), Color.Transparent),
        center = Offset(size.width * 0.5f, 0f),
        radius = size.width * 0.95f,
    )
    onDrawBehind {
        drawRect(body)
        drawRect(glow)
        val r = 0.6.dp.toPx()
        specks.forEach { (p, a) -> drawCircle(if (a > 0.5f) Color(0x0AFFFFFF) else Color(0x14000000), r, p) }
    }
}

/**
 * Draws a screen under glass. Put it after the screen's own background and clip: it adds the soft shadow the bezel throws
 * on the top and sides, the faint pixel rows of an LCD, and a diagonal reflection across the upper left.
 */
internal fun Modifier.lcdGlass(rowPx: Float = 3f): Modifier = this.drawWithCache {
    val w = size.width
    val h = size.height
    val top = Brush.verticalGradient(listOf(Color(0x4D000000), Color.Transparent), startY = 0f, endY = 12.dp.toPx())
    val left = Brush.horizontalGradient(listOf(Color(0x26000000), Color.Transparent), startX = 0f, endX = 7.dp.toPx())
    val right = Brush.horizontalGradient(listOf(Color.Transparent, Color(0x1A000000)), startX = w - 7.dp.toPx(), endX = w)
    val bottom = Brush.verticalGradient(listOf(Color.Transparent, Color(0x14000000)), startY = h - 5.dp.toPx(), endY = h)
    onDrawWithContent {
        drawContent()
        drawRect(top); drawRect(left); drawRect(right); drawRect(bottom)
    }
}

/** The ink's shadow on an LCD: segments sit a hair above the back plate, so each glyph throws a faint offset shadow. */
internal fun lcdInkShadow(ink: Color) = Shadow(ink.copy(alpha = 0.12f), Offset(1f, 1.5f), 1.5f)

/** The dark frame around the screen. */
internal fun Modifier.lcdBezel(): Modifier = this
    .background(Brush.verticalGradient(listOf(Color(0xFF26262A), Color(0xFF050506))), RoundedCornerShape(12.dp))
    .border(1.dp, Brush.verticalGradient(listOf(Color(0x40FFFFFF), Color(0x0DFFFFFF))), RoundedCornerShape(12.dp))

/** The face of a keycap: lit from above, a little darker at the foot. */
internal fun keyFace(face: Color): Brush = Brush.verticalGradient(
    0f to lighter(face, 0.06f),
    0.5f to face,
    1f to darker(face, 0.09f),
)

/** The solar strip: four dark cells behind glass with silver bus lines, a hint of blue, and a sheen. */
@Composable
internal fun SolarPanel(modifier: Modifier = Modifier) {
    Canvas(modifier.size(width = 92.dp, height = 26.dp)) {
        val w = size.width
        val h = size.height
        val r = 3.dp.toPx()
        drawRoundRect(Color(0xFF050608), cornerRadius = CornerRadius(r + 1.dp.toPx()))
        val pad = 2.dp.toPx()
        val cw = (w - pad * 2) / 4f
        for (i in 0 until 4) {
            val x = pad + cw * i
            val cell = Brush.verticalGradient(listOf(Color(0xFF232733), Color(0xFF141720), Color(0xFF0B0C11)), startY = pad, endY = h - pad)
            drawRoundRect(cell, Offset(x + 1.dp.toPx(), pad), Size(cw - 2.dp.toPx(), h - pad * 2), CornerRadius(1.5.dp.toPx()))
            // The thin metal lines across a cell.
            drawRect(Color(0x33C9CCE0), Offset(x + 3.dp.toPx(), pad + 3.dp.toPx()), Size(cw - 6.dp.toPx(), 0.7.dp.toPx()))
            drawRect(Color(0x33C9CCE0), Offset(x + 3.dp.toPx(), h - pad - 3.7.dp.toPx()), Size(cw - 6.dp.toPx(), 0.7.dp.toPx()))
        }
        drawRoundRect(
            Brush.linearGradient(listOf(Color(0x40FFFFFF), Color.Transparent, Color(0x14FFFFFF)), start = Offset(0f, 0f), end = Offset(w * 0.7f, h)),
            cornerRadius = CornerRadius(r + 1.dp.toPx()),
        )
        drawRoundRect(Color(0x33FFFFFF), cornerRadius = CornerRadius(r + 1.dp.toPx()), style = androidx.compose.ui.graphics.drawscope.Stroke(1.dp.toPx()))
    }
}

/** The wordmark and model line printed on the body, left of the solar strip. */
@Composable
internal fun CalcBrand(modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(
            "LOCKIN",
            style = com.godbless.lockin.ui.LockInText.Small.copy(
                color = CC.Ink, fontFamily = Fonts.Wordmark, fontSize = 17.sp, lineHeight = 20.sp, letterSpacing = 2.sp,
                shadow = Shadow(Color.Black.copy(alpha = 0.45f), Offset(0f, 1f), 0f),
            ),
            maxLines = 1,
        )
        Text(
            "SCIENTIFIC CALCULATOR",
            style = com.godbless.lockin.ui.LockInText.Small.copy(
                color = CC.Dim, fontSize = 8.5.sp, lineHeight = 11.sp, letterSpacing = 1.4.sp, fontWeight = FontWeight.SemiBold,
            ),
            maxLines = 1,
        )
    }
}

/** The line across the top of the device: brand on the left, solar strip on the right. */
@Composable
internal fun CalcBrandRow(modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        CalcBrand()
        SolarPanel()
    }
}
