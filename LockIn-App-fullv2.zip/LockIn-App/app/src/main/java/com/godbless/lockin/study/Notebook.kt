package com.godbless.lockin.study

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.godbless.lockin.home.Glyph
import com.godbless.lockin.home.GlyphIcon
import com.godbless.lockin.ui.BackButton
import com.godbless.lockin.ui.LockInColors
import com.godbless.lockin.ui.LockInText
import kotlinx.coroutines.delay

/**
 * Everything you marked while reading: highlights, notes and bookmarks, for one book ([onlyBook]) or all of them.
 * Tap an entry to open the book at that page. Deleting offers Undo for a few seconds.
 */
@Composable
internal fun NotebookScreen(
    store: StudyStore,
    onlyBook: String?,
    onBack: () -> Unit,
    onOpen: (book: String, page: Int) -> Unit,
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    // 0 everything, 1 highlights, 2 notes, 3 bookmarks
    var filter by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    var undo by remember { mutableStateOf<Mark?>(null) }
    LaunchedEffect(undo) {
        if (undo != null) {
            delay(5000)
            undo = null
        }
    }

    val shown by remember(onlyBook) {
        derivedStateOf {
            val q = query.trim().lowercase()
            store.marks
                .filter { onlyBook == null || it.book == onlyBook }
                .filter { store.book(it.book) != null }
                .filter {
                    when (filter) {
                        1 -> it.kind == MarkKind.Highlight
                        2 -> it.note.isNotBlank() || it.kind == MarkKind.Note
                        3 -> it.kind == MarkKind.Bookmark
                        else -> true
                    }
                }
                .filter { q.isEmpty() || it.text.lowercase().contains(q) || it.note.lowercase().contains(q) }
                .sortedWith(compareBy<Mark>({ store.book(it.book)?.title ?: "" }, { it.page }, { it.at }))
        }
    }
    val total = store.marks.count { (onlyBook == null || it.book == onlyBook) && store.book(it.book) != null }
    val title = if (onlyBook != null) store.book(onlyBook)?.title?.let { prettyTitle(it) } ?: "Notebook" else "Notebook"

    Box(
        Modifier
            .fillMaxSize()
            .background(LockInColors.Ink)
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                BackButton(onBack)
                Column(Modifier.weight(1f).padding(start = 14.dp)) {
                    Text("Notebook", style = LockInText.Title.copy(color = LockInColors.Snow, fontSize = 20.sp))
                    if (onlyBook != null) {
                        Text(title, style = LockInText.Small.copy(color = LockInColors.Mist), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .clickable(enabled = total > 0, role = Role.Button) {
                            val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(android.content.Intent.EXTRA_SUBJECT, "Notebook")
                                putExtra(android.content.Intent.EXTRA_TEXT, store.notebookMarkdown(onlyBook))
                            }
                            runCatching { context.startActivity(android.content.Intent.createChooser(send, "Share notebook")) }
                        },
                    contentAlignment = Alignment.Center,
                ) { GlyphIcon(Glyph.Share, if (total > 0) LockInColors.Silver else LockInColors.Graphite, boxSize = 22.dp) }
            }
            // Search
            val field = RoundedCornerShape(24.dp)
            Row(
                Modifier
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .fillMaxWidth()
                    .height(48.dp)
                    .clip(field)
                    .background(LockInColors.Slate)
                    .border(1.dp, LockInColors.Graphite, field)
                    .padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                GlyphIcon(Glyph.Search, LockInColors.Silver, boxSize = 20.dp)
                Box(Modifier.weight(1f).padding(start = 10.dp), contentAlignment = Alignment.CenterStart) {
                    if (query.isEmpty()) Text("Search your notes", style = LockInText.Input.copy(color = LockInColors.Mist, fontSize = 15.sp))
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it.take(80) },
                        singleLine = true,
                        textStyle = LockInText.Input.copy(fontSize = 15.sp),
                        cursorBrush = SolidColor(LockInColors.Lime),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
            ) {
                val labels = listOf("All", "Highlights", "Notes", "Bookmarks")
                items(labels.size) { i ->
                    Box(
                        Modifier
                            .height(44.dp)
                            .clip(CircleShape)
                            .background(if (filter == i) LockInColors.Lime else LockInColors.Slate)
                            .border(1.dp, if (filter == i) LockInColors.Lime else LockInColors.Graphite, CircleShape)
                            .clickable(role = Role.Button) { filter = i }
                            .padding(horizontal = 16.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(labels[i], style = LockInText.Label.copy(color = if (filter == i) LockInColors.OnLime else LockInColors.Snow, fontSize = 13.sp))
                    }
                }
            }

            if (shown.isEmpty()) {
                Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center) {
                    GlyphIcon(Glyph.Notes, LockInColors.Mist, boxSize = 36.dp)
                    Spacer(Modifier.height(12.dp))
                    Text(
                        if (total == 0) "Nothing here yet" else "Nothing matches",
                        style = LockInText.Label.copy(color = LockInColors.Snow, fontSize = 17.sp),
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        if (total == 0) "Select text in a book and tap Mark to highlight it, add a note, or bookmark a page from the top bar." else "Try another word, or another filter.",
                        style = LockInText.Small.copy(color = LockInColors.Mist),
                    )
                }
            } else {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 120.dp),
                ) {
                    shown.forEachIndexed { i, m ->
                        val newBook = onlyBook == null && m.book != (shown.getOrNull(i - 1)?.book ?: "")
                        item(key = m.id) {
                            if (newBook) {
                                Text(
                                    (store.book(m.book)?.title?.let { prettyTitle(it) } ?: "").uppercase(),
                                    style = LockInText.Small.copy(color = LockInColors.Mist, fontSize = 11.sp, letterSpacing = 1.2.sp),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(top = if (i == 0) 4.dp else 18.dp, bottom = 8.dp),
                                )
                            }
                            MarkRow(m, onClick = { onOpen(m.book, m.page) }, onDelete = {
                                store.removeMark(m.id)
                                undo = m
                            })
                        }
                    }
                }
            }
        }
        // Undo
        AnimatedVisibility(
            visible = undo != null,
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp),
            enter = slideInVertically { it * 2 },
            exit = slideOutVertically { it * 2 },
        ) {
            var kept by remember { mutableStateOf<Mark?>(null) }
            LaunchedEffect(undo) { if (undo != null) kept = undo }
            val shape = RoundedCornerShape(26.dp)
            Row(
                Modifier
                    .clip(shape)
                    .background(LockInColors.Slate)
                    .border(1.dp, LockInColors.Graphite, shape)
                    .padding(start = 20.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Deleted", style = LockInText.Label.copy(color = LockInColors.Snow, fontSize = 14.sp))
                Box(
                    Modifier
                        .heightIn(min = 48.dp)
                        .clip(CircleShape)
                        .clickable(role = Role.Button) {
                            (undo ?: kept)?.let { store.restoreMark(it) }
                            undo = null
                        }
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center,
                ) { Text("Undo", style = LockInText.Label.copy(color = LockInColors.Lime, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)) }
            }
        }
    }
}

@Composable
private fun MarkRow(m: Mark, onClick: () -> Unit, onDelete: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    val bar = when (m.kind) {
        MarkKind.Highlight -> MarkColors[m.color.coerceIn(0, 3)]
        MarkKind.Note -> MarkColors[0]
        MarkKind.Bookmark -> LockInColors.Lime
    }
    Row(
        Modifier
            .padding(bottom = 10.dp)
            .fillMaxWidth()
            .clip(shape)
            .background(LockInColors.Slate)
            .border(1.dp, LockInColors.Graphite, shape)
            .clickable(role = Role.Button, onClick = onClick)
            .height(androidx.compose.foundation.layout.IntrinsicSize.Min),
    ) {
        Box(Modifier.width(5.dp).fillMaxHeight().background(bar))
        Column(Modifier.weight(1f).padding(start = 14.dp, top = 12.dp, bottom = 12.dp)) {
            Text(
                "PAGE ${m.page + 1}" + when (m.kind) { MarkKind.Bookmark -> " · BOOKMARK"; MarkKind.Note -> " · NOTE"; else -> "" },
                style = LockInText.Small.copy(color = LockInColors.Mist, fontSize = 11.sp, letterSpacing = 1.1.sp),
            )
            if (m.text.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(m.text, style = LockInText.Sub.copy(color = LockInColors.Snow, fontSize = 15.sp), maxLines = 5, overflow = TextOverflow.Ellipsis)
            }
            if (m.note.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(m.note, style = LockInText.Sub.copy(color = LockInColors.Silver, fontSize = 14.sp), maxLines = 6, overflow = TextOverflow.Ellipsis)
            }
        }
        Box(
            Modifier.size(48.dp).clip(CircleShape).clickable(role = Role.Button, onClick = onDelete),
            contentAlignment = Alignment.Center,
        ) { GlyphIcon(Glyph.Close, LockInColors.Mist, boxSize = 12.dp, strokeWidth = 2.2f) }
    }
}
