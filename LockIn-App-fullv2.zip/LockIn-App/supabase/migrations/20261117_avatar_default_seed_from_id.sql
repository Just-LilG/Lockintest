-- Pulled from the live project (applied there as 20261117104818 avatar_default_seed_from_id).
-- Everyone gets a stable, unique avatar code derived from their account id when they have not shuffled one.
-- (Before, the app derived it from the first name, so two people called "Lil" looked identical.)
create or replace function public._avatar_of(p_user uuid)
returns jsonb
language sql
stable
security definer
set search_path to ''
as $$
  select jsonb_build_object(
    'style', p.avatar_style,
    'seed', coalesce(nullif(p.avatar_seed, ''), left(md5(p.id::text), 16)),
    'color', p.avatar_color,
    'glyph', p.avatar_glyph)
  from public.profiles p where p.id = p_user;
$$;
revoke all on function public._avatar_of(uuid) from public, anon, authenticated;
