-- Pulled from the live project (applied there as 20261117105250 avatar_look).
-- The "look" filter of an illustrated avatar: '' = any, 'm' or 'f'. Kept so a partner's phone draws exactly what you see.
alter table public.profiles
  add column if not exists avatar_look text not null default '';
alter table public.profiles
  add constraint profiles_avatar_look_chk check (avatar_look in ('', 'm', 'f'));

create or replace function public._avatar_of(p_user uuid)
returns jsonb
language sql
stable
security definer
set search_path to ''
as $$
  select jsonb_build_object(
    'style', p.avatar_style,
    'seed', coalesce(nullif(p.avatar_seed, ''), left(md5(p.id::text), 16)),
    'color', p.avatar_color,
    'glyph', p.avatar_glyph,
    'look', p.avatar_look)
  from public.profiles p where p.id = p_user;
$$;
revoke all on function public._avatar_of(uuid) from public, anon, authenticated;

-- Replace the 4-argument version (older app builds still send 4 values; p_look then takes its default).
drop function if exists public.set_avatar(text, text, integer, text);
create or replace function public.set_avatar(p_style text, p_seed text, p_color integer, p_glyph text, p_look text default '')
returns json
language plpgsql
security definer
set search_path to ''
as $$
begin
  if auth.uid() is null then raise exception 'Sign in first.'; end if;
  insert into public.profiles (id, avatar_style, avatar_seed, avatar_color, avatar_glyph, avatar_look)
  values (auth.uid(), p_style, coalesce(p_seed, ''), coalesce(p_color, -1), coalesce(p_glyph, ''), coalesce(p_look, ''))
  on conflict (id) do update
    set avatar_style = excluded.avatar_style,
        avatar_seed  = excluded.avatar_seed,
        avatar_color = excluded.avatar_color,
        avatar_glyph = excluded.avatar_glyph,
        avatar_look  = excluded.avatar_look;
  return json_build_object('ok', true);
end $$;
revoke all on function public.set_avatar(text, text, integer, text, text) from public, anon;
grant execute on function public.set_avatar(text, text, integer, text, text) to authenticated;
