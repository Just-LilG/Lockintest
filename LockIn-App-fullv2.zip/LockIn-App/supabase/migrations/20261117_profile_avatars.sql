-- Pulled from the live project (applied there as 20261117052049 profile_avatars); it was missing from the repo.
-- Avatars are stored on the profile so a partner or crew mate sees the avatar you picked.
-- avatar_style: null = never chosen (the app shows its default illustrated avatar), '' = classic colour/symbol,
--               otherwise a DiceBear style name.
alter table public.profiles
  add column if not exists avatar_style text,
  add column if not exists avatar_seed text not null default '',
  add column if not exists avatar_color integer not null default -1,
  add column if not exists avatar_glyph text not null default '';

alter table public.profiles
  add constraint profiles_avatar_style_chk check (avatar_style is null or avatar_style ~ '^[a-z0-9-]{0,24}$'),
  add constraint profiles_avatar_seed_chk  check (avatar_seed ~ '^[a-f0-9]{0,32}$'),
  add constraint profiles_avatar_color_chk check (avatar_color between -1 and 7),
  add constraint profiles_avatar_glyph_chk check (char_length(avatar_glyph) <= 8);

-- Internal helper: one person's avatar as json. Only other functions call it.
create or replace function public._avatar_of(p_user uuid)
returns jsonb
language sql
stable
security definer
set search_path to ''
as $$
  select jsonb_build_object('style', p.avatar_style, 'seed', p.avatar_seed, 'color', p.avatar_color, 'glyph', p.avatar_glyph)
  from public.profiles p where p.id = p_user;
$$;
revoke all on function public._avatar_of(uuid) from public, anon, authenticated;

-- Save your own avatar.
create or replace function public.set_avatar(p_style text, p_seed text, p_color integer, p_glyph text)
returns json
language plpgsql
security definer
set search_path to ''
as $$
begin
  if auth.uid() is null then raise exception 'Sign in first.'; end if;
  insert into public.profiles (id, avatar_style, avatar_seed, avatar_color, avatar_glyph)
  values (auth.uid(), p_style, coalesce(p_seed, ''), coalesce(p_color, -1), coalesce(p_glyph, ''))
  on conflict (id) do update
    set avatar_style = excluded.avatar_style,
        avatar_seed  = excluded.avatar_seed,
        avatar_color = excluded.avatar_color,
        avatar_glyph = excluded.avatar_glyph;
  return json_build_object('ok', true);
end $$;
revoke all on function public.set_avatar(text, text, integer, text) from public, anon;
grant execute on function public.set_avatar(text, text, integer, text) to authenticated;

-- Return avatars from the three places the app reads people. Each is patched from its live definition, so nothing
-- else in these functions is retyped; the patch fails loudly if the expected text isn't found.
do $patch$
declare d text;
begin
  select pg_get_functiondef('public.my_partnership()'::regprocedure) into d;
  d := replace(d, '''partner_id'', other,', '''partner_id'', other, ''partner_avatar'', public._avatar_of(other),');
  if d not like '%partner_avatar%' then raise exception 'my_partnership: pattern not found'; end if;
  execute d;

  select pg_get_functiondef('public.crew_state_v2(integer)'::regprocedure) into d;
  d := replace(d, '''name'', public._crew_name_of(m.user_id),', '''avatar'', public._avatar_of(m.user_id), ''name'', public._crew_name_of(m.user_id),');
  if d not like '%_avatar_of(m.user_id)%' then raise exception 'crew_state_v2: pattern not found'; end if;
  execute d;

  select pg_get_functiondef('public.profile_me()'::regprocedure) into d;
  d := replace(d, '''sound'', coalesce(p.message_sound, ''message'')', '''sound'', coalesce(p.message_sound, ''message''), ''avatar'', public._avatar_of(auth.uid())');
  if d not like '%_avatar_of(auth.uid())%' then raise exception 'profile_me: pattern not found'; end if;
  execute d;
end
$patch$;
