-- Applied to the live project as chat_event_guard_0_31_1.
-- A locked person could post a fake "asked_unlock" or "emergency_release" event straight into the chat, skipping the
-- server's own rules (no asking on a strict lock, no emergency release at all). The chat insert now refuses them
-- while a lock on that person is running: any ask on a strict lock, and the emergency release on any lock.
-- Phones with no server lock (an old local lock) can still post them, as before.
create or replace function public._lock_event_ok(p_user uuid, p_kind text, p_body text)
returns boolean language sql stable security definer set search_path to '' as $$
  select case
    when p_kind <> 'event' then true
    when p_body = 'asked_unlock' then not exists (
      select 1 from public.partner_locks l
       where l.target = p_user and l.ended_at is null and l.starts_at <= now() and l.ends_at > now() and l.strict)
    when p_body = 'emergency_release' then not exists (
      select 1 from public.partner_locks l
       where l.target = p_user and l.ended_at is null and l.starts_at <= now() and l.ends_at > now())
    else true
  end;
$$;
revoke all on function public._lock_event_ok(uuid, text, text) from public, anon;
grant execute on function public._lock_event_ok(uuid, text, text) to authenticated;

drop policy if exists "members send messages" on public.messages;
create policy "members send messages" on public.messages
  for insert to authenticated
  with check (
    sender = (select auth.uid())
    and (kind = 'text' or body = any (array['asked_unlock', 'emergency_release', 'nudge']))
    and public._lock_event_ok((select auth.uid()), kind, body)
    and exists (
      select 1 from public.partnerships p
       where p.id = messages.partnership_id and p.partner is not null
         and ((select auth.uid()) = p.owner or (select auth.uid()) = p.partner))
  );
