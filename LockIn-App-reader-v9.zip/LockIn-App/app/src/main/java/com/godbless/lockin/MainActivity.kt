package com.godbless.lockin

import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.util.DisplayMetrics
import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.fragment.app.FragmentActivity
import com.godbless.lockin.data.PairLink
import com.godbless.lockin.push.Push
import com.godbless.lockin.ui.LockInTheme

/** A FragmentActivity because the fingerprint prompt needs one. */
class MainActivity : FragmentActivity() {
    private val auth get() = (application as LockInApplication).auth

    override fun onCreate(savedInstanceState: Bundle?) {
        // The system splash is only ink-coloured, so there is no flash before the intro starts.
        // Removing it immediately (no exit animation) keeps the hand-off to our own first frame seamless.
        installSplashScreen().setOnExitAnimationListener { it.remove() }
        super.onCreate(savedInstanceState)
        // The app process can start before first unlock (Application.onCreate skips these then); the user is unlocked now.
        com.godbless.lockin.data.VoiceDir.init(applicationContext)
        com.godbless.lockin.data.MediaDir.init(applicationContext)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        handleLink(intent)
        setContent {
            LockInTheme {
                androidx.compose.foundation.layout.Box {
                    LockInApp(auth)
                    // After a crash: the reason, ready to copy.
                    CrashNotice()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Battery saver or the animation setting may have changed while LockIn was in the background.
        com.godbless.lockin.ui.MotionState.refresh(this)
        // Smoothest the screen can do (90 or 120 Hz where there is such a panel).
        com.godbless.lockin.ui.PeakRefresh.request(this)
        leaveSmallWindowSoon()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) leaveSmallWindowSoon()
    }

    /**
     * LockIn does not support split screen or a floating window, but some phone makers (HyperOS "small window", freeform)
     * force an app into one anyway. When that happens LockIn starts itself again as a normal full-screen task, which
     * opens full screen. Looks once the window has settled, and gives up after three tries a minute so a phone that keeps
     * floating it can't make it flicker (the lock cover handles that case).
     */
    private fun leaveSmallWindowSoon() {
        window.decorView.postDelayed({
            if (isFinishing || isDestroyed || !isSmallWindow()) return@postDelayed
            val now = android.os.SystemClock.elapsedRealtime()
            relaunches.removeAll { now - it > 60_000L }
            if (relaunches.size >= 3) return@postDelayed
            relaunches.add(now)
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        }, 500L)
    }

    /** True when LockIn's window is clearly smaller than the screen: split, floating, freeform, small window. */
    @Suppress("DEPRECATION")
    private fun isSmallWindow(): Boolean {
        if (isInMultiWindowMode) return true
        val d = window.decorView
        if (d.width == 0 || d.height == 0) return false
        val (sw, sh) = if (Build.VERSION.SDK_INT >= 30) {
            windowManager.maximumWindowMetrics.bounds.let { it.width() to it.height() }
        } else {
            val m = DisplayMetrics()
            windowManager.defaultDisplay.getRealMetrics(m)
            m.widthPixels to m.heightPixels
        }
        return d.width < sw * 0.85 || d.height < sh * 0.8
    }

    private companion object {
        val relaunches = ArrayDeque<Long>()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleLink(intent)
    }

    /** The PDF in an "Open with" or Share intent, or null. */
    private fun pdfFrom(intent: Intent?): android.net.Uri? {
        if (intent == null || intent.type != "application/pdf") return null
        return when (intent.action) {
            Intent.ACTION_VIEW -> intent.data
            Intent.ACTION_SEND ->
                if (android.os.Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, android.net.Uri::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra<android.net.Uri>(Intent.EXTRA_STREAM)
                }
            else -> null
        }
    }

    private fun handleLink(intent: Intent?) {
        // A tapped notification carries no link, only a note of what to open.
        when (val open = intent?.getStringExtra(Push.ExtraOpen)) {
            Push.OpenChat -> (application as LockInApplication).openChat.value = true
            Push.OpenLock, Push.OpenPartner, Push.OpenCrew, Push.OpenCrewChat, Push.OpenParty, Push.OpenStart, Push.OpenClimbs -> (application as LockInApplication).openTarget.value = open
        }
        pdfFrom(intent)?.let { pdf ->
            (application as LockInApplication).incomingPdf.value = pdf
            // So turning the phone (which rebuilds this screen) doesn't add the same file again.
            setIntent(Intent())
            return
        }
        val uri = intent?.data ?: return
        if (auth.handleLink(uri)) return
        // Not a sign-in link, so it may be a pairing link.
        PairLink.parse(uri.toString())?.let { (application as LockInApplication).incomingPairCode.value = it }
    }
}
