package com.godbless.lockin.lock

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.SystemClock
import android.provider.Settings
import androidx.core.app.NotificationCompat
import com.godbless.lockin.R

/**
 * Keeps the guard (the accessibility service) running. Android only starts it after a restart if the phone maker lets
 * it, and many (HyperOS, ColorOS, One UI with battery limits) leave it listed as "on" but never start it, or stop it
 * later; and switching it off is one tap in Accessibility settings.
 *
 * With the one-time permission WRITE_SECURE_SETTINGS (granted once from a computer:
 * `adb shell pm grant com.godbless.lockin android.permission.WRITE_SECURE_SETTINGS`) LockIn can switch its own guard
 * back on, and does, during every lock. Without it this does nothing and the guard has to be switched on by hand.
 */
object GuardKeeper {
    fun canWrite(context: Context): Boolean =
        context.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED

    private var last = 0L
    private var lastNote = 0L

    /**
     * Gets the guard running again. Called every few seconds from the watch (and during a lock). Three ways, in order:
     *  1. a device-owner LockIn gives itself the permission (no computer needed);
     *  2. with the permission, switch the guard off and on in the accessibility list (a listed-but-dead service only
     *     restarts on a change);
     *  3. without it, nothing can be done silently: a notification says so, one tap from the right screen.
     * Waits 45 s after a restart (Android starts the guard itself then) and at least 8 s between tries. True if it tried.
     */
    fun ensure(context: Context): Boolean {
        if (SettingsGuardService.running()) return false
        val now = SystemClock.elapsedRealtime()
        if (now < 45_000L || now - last < 8_000L) return false
        last = now
        if (!canWrite(context)) LockGuard(context).grantSecureSettings()
        if (!canWrite(context)) {
            remind(context, now)
            return false
        }
        val me = ComponentName(context, SettingsGuardService::class.java)
        return runCatching {
            val cr = context.contentResolver
            val others = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
                .split(':').filter { it.isNotBlank() && ComponentName.unflattenFromString(it) != me }
            Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, others.joinToString(":"))
            Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, (others + me.flattenToString()).joinToString(":"))
            Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
            true
        }.getOrDefault(false)
    }

    /** The guard was on before and is not running, and LockIn can't restart it by itself: tell the person, every 10 minutes. */
    private fun remind(context: Context, now: Long) {
        if (!Protection.on(context) || !Protection.guardSeen(context)) return
        if (lastNote != 0L && now - lastNote < 10 * 60_000L) return
        lastNote = now
        runCatching {
            val nm = context.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(Channel) == null) {
                nm.createNotificationChannel(NotificationChannel(Channel, "Guard stopped", NotificationManager.IMPORTANCE_HIGH))
            }
            val open = PendingIntent.getActivity(
                context, 77, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            val n = NotificationCompat.Builder(context, Channel)
                .setSmallIcon(R.drawable.ic_stat_lockin)
                .setContentTitle("LockIn's guard stopped")
                .setContentText("Tap to switch LockIn protection back on in Accessibility.")
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            nm.notify(1090, n)
        }
    }

    private const val Channel = "guard_stopped"
}
