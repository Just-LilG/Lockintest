package com.godbless.lockin.lock

import android.content.Context
import android.content.Intent

/**
 * What may be on screen during a lock without being stopped: the home screen(s), the phone app and the call screen,
 * the system's own UI, and the emergency dialer. Shared by the lock service and the guard's second line
 * ([SettingsGuardService]'s "strike"), so the two never disagree about what counts as "another app".
 */
internal fun lockExemptPackages(context: Context): Set<String> {
    val out = HashSet<String>()
    val pm = context.packageManager
    // Every home screen the phone has, not just the default: Recents lives in the launcher on most phones.
    runCatching {
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
            .mapNotNullTo(out) { it.activityInfo?.packageName }
    }
    runCatching {
        pm.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
            ?.activityInfo?.packageName?.let { out.add(it) }
    }
    runCatching { context.getSystemService(android.telecom.TelecomManager::class.java)?.defaultDialerPackage?.let { out.add(it) } }
    out.add("com.android.systemui")
    // The call screen is a separate app on many phones (and the emergency dialer another): with the stricter
    // "step aside only while nothing else is up" rule, a call must never be taken for "another app".
    out.addAll(listOf(
        "com.android.incallui", "com.android.phone", "com.android.server.telecom", "com.android.emergency",
        "com.google.android.dialer", "com.android.dialer", "com.samsung.android.incallui", "com.samsung.android.dialer",
    ))
    return out
}

/**
 * How firmly the guard answers another app that keeps coming back. Each time it sends the person Home counts as one hit;
 * enough hits in a short time (an app that relaunches itself, or a person who keeps trying) and the screen is switched
 * off, which also stops whatever was running behind it. Kept apart from Android so it can be tested on its own.
 */
internal class StrikeLadder(
    private val windowMs: Long = 20_000L,
    private val screenOffAt: Int = 4,
    private val screenOffGapMs: Long = 20_000L,
) {
    private val hits = ArrayDeque<Long>()
    private var lastScreenOff = Long.MIN_VALUE / 2

    /** One more time another app was sent away. Returns how many that is within the window. */
    fun hit(now: Long): Int {
        hits.addLast(now)
        while (hits.isNotEmpty() && now - hits.first() > windowMs) hits.removeFirst()
        return hits.size
    }

    /** True when it is time to switch the screen off (at most once per gap). */
    fun shouldLockScreen(now: Long): Boolean {
        if (hits.size < screenOffAt || now - lastScreenOff <= screenOffGapMs) return false
        lastScreenOff = now
        return true
    }

    fun reset() = hits.clear()
}
