package com.godbless.lockin.lock

import android.app.ActivityManager
import android.app.NotificationManager
import android.app.NotificationManager.Policy
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings

/**
 * Strict do-not-disturb for the length of a lock: nothing buzzes, lights up, peeks in or sits in the shade. Only alarms,
 * and calls from starred contacts (or someone ringing twice), get through, so a lock never cuts the person off from a real
 * emergency. Needs "Do Not Disturb access" for LockIn (Settings, or once from a computer:
 * `adb shell cmd notification allow_dnd com.godbless.lockin`). What was set before is put back when the lock ends.
 * It is set again every few seconds, so switching it off in Quick Settings doesn't last.
 */
object LockDnd {
    private const val K_ON = "dnd_on"
    private const val K_FILTER = "dnd_filter"
    private const val K_CATS = "dnd_cats"
    private const val K_CALLS = "dnd_calls"
    private const val K_MSGS = "dnd_msgs"
    private const val K_VIS = "dnd_vis"

    private fun nm(c: Context) = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun granted(c: Context): Boolean = nm(c).isNotificationPolicyAccessGranted

    fun settingsIntent(): Intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    @Suppress("DEPRECATION")
    private fun strict(): NotificationManager.Policy {
        var cats = Policy.PRIORITY_CATEGORY_CALLS or Policy.PRIORITY_CATEGORY_REPEAT_CALLERS
        var vis = Policy.SUPPRESSED_EFFECT_SCREEN_ON or Policy.SUPPRESSED_EFFECT_SCREEN_OFF
        if (Build.VERSION.SDK_INT >= 28) {
            cats = cats or Policy.PRIORITY_CATEGORY_ALARMS
            vis = vis or Policy.SUPPRESSED_EFFECT_FULL_SCREEN_INTENT or Policy.SUPPRESSED_EFFECT_LIGHTS or Policy.SUPPRESSED_EFFECT_PEEK or
                Policy.SUPPRESSED_EFFECT_STATUS_BAR or Policy.SUPPRESSED_EFFECT_BADGE or Policy.SUPPRESSED_EFFECT_AMBIENT or
                Policy.SUPPRESSED_EFFECT_NOTIFICATION_LIST
        }
        return NotificationManager.Policy(cats, Policy.PRIORITY_SENDERS_STARRED, Policy.PRIORITY_SENDERS_STARRED, vis)
    }

    /** Switches strict DND on (and keeps it on). False when LockIn has no Do Not Disturb access. */
    fun engage(c: Context): Boolean {
        if (!granted(c)) return false
        val n = nm(c)
        val p = lockDevicePrefs(c)
        runCatching {
            if (!p.getBoolean(K_ON, false)) {
                val before = n.notificationPolicy
                p.edit().putBoolean(K_ON, true).putInt(K_FILTER, n.currentInterruptionFilter)
                    .putInt(K_CATS, before.priorityCategories).putInt(K_CALLS, before.priorityCallSenders)
                    .putInt(K_MSGS, before.priorityMessageSenders).putInt(K_VIS, before.suppressedVisualEffects).apply()
            }
            val want = strict()
            if (n.notificationPolicy != want) n.notificationPolicy = want
            if (n.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_PRIORITY) {
                n.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            }
        }
        return true
    }

    /** Puts back what was set before the lock. Safe to call when it was never switched on. */
    fun restore(c: Context) {
        val p = lockDevicePrefs(c)
        if (!p.getBoolean(K_ON, false)) return
        if (granted(c)) {
            runCatching {
                val n = nm(c)
                n.notificationPolicy = NotificationManager.Policy(
                    p.getInt(K_CATS, 0), p.getInt(K_CALLS, 0), p.getInt(K_MSGS, 0), p.getInt(K_VIS, 0),
                )
                n.setInterruptionFilter(p.getInt(K_FILTER, NotificationManager.INTERRUPTION_FILTER_ALL))
            }
        }
        p.edit().remove(K_ON).apply()
    }
}

/**
 * The closest thing to "force stop" an app can do to other apps without being the system: asks Android to kill their
 * background processes, as it does itself when memory runs low. It cannot reach an app that is on screen or running a
 * foreground service (music, navigation) and it is not the "stopped" state; a real force stop needs the system, or LockIn as
 * device owner (see [LockGuard.holdOthers], which suspends the app and so stops it for good).
 */
object LockKill {
    @Suppress("DEPRECATION")
    private fun launchable(c: Context): Set<String> = runCatching {
        c.packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName }.toSet()
    }.getOrDefault(emptySet())

    fun kill(c: Context, pkgs: Collection<String>) {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        for (pkg in pkgs) runCatching { if (pkg != c.packageName) am.killBackgroundProcesses(pkg) }
    }

    /** Every app with a launcher icon except [keep]. */
    fun sweep(c: Context, keep: Set<String>) = kill(c, launchable(c) - keep)
}
