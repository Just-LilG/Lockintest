package com.godbless.lockin.study

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Canvas as GfxCanvas
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.CanvasDrawScope
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.godbless.lockin.ui.Fonts
import com.godbless.lockin.ui.LockInColors
import com.godbless.lockin.ui.LockInText
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.random.Random

// How the calculator looks, kept apart from how it works.
//
// The look is clay with real materials: soft, puffed-up keys that stand out of the body with a light shadow on the lit
// side and a dark one on the other (light comes from the top left), a screen cut into the body behind real glass, glossy
// spheres for SHIFT/ALPHA/MODE/2nd, a round pad. It comes in two bodies, a pale "porcelain" and a dark "graphite", and
// follows the app's theme unless the person picks one (the Look pill in the toolbar).
//
// Everything is drawn with shapes and gradients, no images. A shadow is a stack of shapes, each a little bigger and
// fainter than the last, spaced the way a gaussian blur is spread, so it is soft on any phone and any Android version.
// Keys and buttons paint their body once into a small bitmap (two, resting and pressed), share it between keys of the
// same size and colour, and just draw that bitmap, so the keypad costs almost nothing per frame.

/** Mix [c] towards white by [f]. */
internal fun lighter(c: Color, f: Float): Color = lerp(c, Color.White, f)

/** Mix [c] towards black by [f]. */
internal fun darker(c: Color, f: Float): Color = lerp(c, Color.Black, f)

// ---- The two bodies -------------------------------------------------------------------------

internal class ClayPalette(
    val dark: Boolean,
    // body, sheets
    val bodyTop: Color, val bodyBot: Color, val panel: Color, val raised: Color, val line: Color,
    // text
    val ink: Color, val dim: Color, val shift: Color, val alpha: Color, val accent: Color, val onAccent: Color, val good: Color, val bad: Color,
    // keys
    val num: Color, val numInk: Color, val fn: Color, val fnInk: Color, val op: Color, val opInk: Color,
    val del: Color, val delInk: Color, val ac: Color, val acInk: Color, val eq: Color, val eqInk: Color,
    val sShift: Color, val sAlpha: Color, val sPearl: Color,
    // the screen's well and glass, the graph page
    val well: Color, val glass0: Color, val glass1: Color,
    val plotBg: Color, val plotGrid: Color, val plotAxis: Color,
    // light and shadow: the dark side shadow, the lit side highlight, the tight contact shadow, and the inner shading
    val shDark: Color, val shDarkA: Float, val shLight: Color, val shLightA: Float, val ao: Color, val aoA: Float,
    val inDark: Color, val inDarkA: Float, val inLight: Color, val inLightA: Float,
) {
    companion object {
        val Light = ClayPalette(
            dark = false,
            bodyTop = Color(0xFFEFEDF8), bodyBot = Color(0xFFE1DEF0), panel = Color(0xFFF1F0FA), raised = Color(0xFFE3E1F1), line = Color(0xFFCDCAE2),
            ink = Color(0xFF2A2C45), dim = Color(0xFF7E819D), shift = Color(0xFFB36B00), alpha = Color(0xFFC42A66),
            accent = Color(0xFF7B6BF2), onAccent = Color.White, good = Color(0xFF1F9D6B), bad = Color(0xFFD2453A),
            num = Color(0xFFF7F6FC), numInk = Color(0xFF2A2C45), fn = Color(0xFFDADBEE), fnInk = Color(0xFF34375A),
            op = Color(0xFFD0C9F7), opInk = Color(0xFF4A3FB5), del = Color(0xFFBDEBD3), delInk = Color(0xFF17684A),
            ac = Color(0xFFFFCABD), acInk = Color(0xFFA23D26), eq = Color(0xFF7B6BF2), eqInk = Color.White,
            sShift = Color(0xFFFFD27D), sAlpha = Color(0xFFFF9FC0), sPearl = Color(0xFFE7E8F5),
            well = Color(0xFFDAD7EC), glass0 = Color(0xFF2B2D3A), glass1 = Color(0xFF0D0E14),
            plotBg = Color(0xFFFBFAFF), plotGrid = Color(0xFFE3E1F0), plotAxis = Color(0xFF9A9DB8),
            shDark = Color(0xFF6E65A8), shDarkA = 0.34f, shLight = Color.White, shLightA = 0.95f, ao = Color(0xFF4A4380), aoA = 0.16f,
            inDark = Color(0xFF6E65A8), inDarkA = 0.40f, inLight = Color.White, inLightA = 0.95f,
        )
        val Dark = ClayPalette(
            dark = true,
            bodyTop = Color(0xFF2C2F38), bodyBot = Color(0xFF1A1C22), panel = Color(0xFF23252D), raised = Color(0xFF2E313B), line = Color(0xFF3B3F4B),
            ink = Color(0xFFECEDF4), dim = Color(0xFF8D91A3), shift = Color(0xFFE8B04A), alpha = Color(0xFFF0679E),
            accent = Color(0xFFF5A524), onAccent = Color(0xFF2A1A00), good = Color(0xFF5FC98F), bad = Color(0xFFE0726B),
            num = Color(0xFF3A3E4B), numInk = Color(0xFFF1F2F8), fn = Color(0xFF2E313B), fnInk = Color(0xFFD5D8E4),
            op = Color(0xFF3C4064), opInk = Color(0xFFC9C4FF), del = Color(0xFF2B6048), delInk = Color(0xFFBDF3D8),
            ac = Color(0xFF74372B), acInk = Color(0xFFFFD0C4), eq = Color(0xFFF5A524), eqInk = Color(0xFF2A1A00),
            sShift = Color(0xFFE9B04B), sAlpha = Color(0xFFE5598F), sPearl = Color(0xFF4A4E5C),
            well = Color(0xFF16181D), glass0 = Color(0xFF34363F), glass1 = Color(0xFF08090C),
            plotBg = Color(0xFF14161B), plotGrid = Color(0xFF262932), plotAxis = Color(0xFF5A5D6B),
            shDark = Color.Black, shDarkA = 0.70f, shLight = Color.White, shLightA = 0.075f, ao = Color.Black, aoA = 0.45f,
            inDark = Color.Black, inDarkA = 0.55f, inLight = Color.White, inLightA = 0.10f,
        )
    }
}

/** Which body the calculator wears: with the app (0), always light (1), always dark (2). Saved on the phone. */
internal object ClayLook {
    private const val KEY = "look"
    var mode: Int by mutableStateOf(0)
        private set

    private var prefs: android.content.SharedPreferences? = null

    fun load(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("lockin_calc", Context.MODE_PRIVATE)
        prefs = p
        mode = p.getInt(KEY, 0).coerceIn(0, 2)
    }

    fun next() {
        mode = (mode + 1) % 3
        prefs?.edit()?.putInt(KEY, mode)?.apply()
    }

    val label: String get() = when (mode) { 1 -> "Light"; 2 -> "Dark"; else -> "Auto" }

    val dark: Boolean get() = when (mode) { 1 -> false; 2 -> true; else -> LockInColors.isDark }

    /** Read while composing or drawing, so everything repaints the moment the body changes. */
    val pal: ClayPalette get() = if (dark) ClayPalette.Dark else ClayPalette.Light
}

// ---- Soft shadows ---------------------------------------------------------------------------

// Where the layers of a shadow sit, in standard deviations: the middles of eight equal slices of a bell curve.
private val Zq = floatArrayOf(-1.534f, -0.887f, -0.489f, -0.157f, 0.157f, 0.489f, 0.887f, 1.534f)

private fun mixf(a: Float, b: Float, t: Float) = a + (b - a) * t

/**
 * The canvas to blur on, when it can: a bitmap's canvas (which is where keys are painted, once) supports a true gaussian blur on
 * every Android version, which is smooth to the pixel. A screen canvas does not on older versions, so big shapes drawn straight
 * to the screen use the stacked-layers shadows below instead; there the blur is so wide that the layers cannot be told apart.
 */
private fun DrawScope.bitmapCanvas(): android.graphics.Canvas? {
    val c = drawContext.canvas.nativeCanvas
    return if (c.isHardwareAccelerated) null else c
}

private fun blurPaint(color: Color, alpha: Float, blur: Float): android.graphics.Paint =
    android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color.copy(alpha = alpha.coerceIn(0f, 0.98f)).toArgb()
        val sigma = blur / 2f // the same "blur" as CSS: its standard deviation is half of it
        if (sigma > 0.4f) maskFilter = android.graphics.BlurMaskFilter(((sigma - 0.5f) / 0.57735f).coerceAtLeast(0.5f), android.graphics.BlurMaskFilter.Blur.NORMAL)
    }

/** A soft shadow of a rounded rectangle: [blur] is the width of the soft edge, [dx]/[dy] move it, [alpha] is its strongest part. */
internal fun DrawScope.softShadow(x: Float, y: Float, w: Float, h: Float, r: Float, dx: Float, dy: Float, blur: Float, color: Color, alpha: Float, spread: Float = 0f) {
    if (alpha <= 0.002f) return
    val nc = bitmapCanvas()
    if (nc != null) {
        val rr = (r + spread).coerceAtLeast(0f)
        nc.drawRoundRect(x + dx - spread, y + dy - spread, x + dx + w + spread, y + dy + h + spread, rr, rr, blurPaint(color, alpha, blur))
        return
    }
    val per = 1f - (1f - alpha.coerceAtMost(0.98f)).pow(1f / Zq.size)
    val c = color.copy(alpha = per)
    val sg = blur / 2f
    for (z in Zq) {
        val e = spread + sg * z
        val ww = w + 2f * e
        val hh = h + 2f * e
        if (ww <= 0f || hh <= 0f) continue
        drawRoundRect(c, Offset(x + dx - e, y + dy - e), Size(ww, hh), CornerRadius((r + e).coerceAtLeast(0f)))
    }
}

/** The same shadow cast on the inside: the edge of the shape shades the surface, as if it were cut into it. */
internal fun DrawScope.insetShadow(x: Float, y: Float, w: Float, h: Float, r: Float, dx: Float, dy: Float, blur: Float, color: Color, alpha: Float) {
    if (alpha <= 0.002f) return
    val shape = Path().apply { addRoundRect(RoundRect(Rect(x, y, x + w, y + h), CornerRadius(r))) }
    val nc = bitmapCanvas()
    if (nc != null) {
        val pad = 4f * blur + abs(dx) + abs(dy) + 8f
        val ring = Path().apply {
            fillType = PathFillType.EvenOdd
            addRect(Rect(x - pad, y - pad, x + w + pad, y + h + pad))
            addRoundRect(RoundRect(Rect(x + dx, y + dy, x + dx + w, y + dy + h), CornerRadius(r)))
        }
        val paint = blurPaint(color, alpha, blur)
        clipPath(shape) { nc.drawPath(ring.asAndroidPath(), paint) }
        return
    }
    val per = 1f - (1f - alpha.coerceAtMost(0.98f)).pow(1f / Zq.size)
    val c = color.copy(alpha = per)
    val sg = blur / 2f
    val pad = w + h
    clipPath(shape) {
        for (z in Zq) {
            val e = sg * z
            val hw = w - 2f * e
            val hh = h - 2f * e
            val p = Path().apply {
                fillType = PathFillType.EvenOdd
                addRect(Rect(x - pad, y - pad, x + w + pad, y + h + pad))
                if (hw > 0f && hh > 0f) {
                    addRoundRect(RoundRect(Rect(x + dx + e, y + dy + e, x + dx + e + hw, y + dy + e + hh), CornerRadius((r - e).coerceAtLeast(0f))))
                }
            }
            drawPath(p, c)
        }
    }
}

// ---- Clay bodies ----------------------------------------------------------------------------

private fun chromaOf(c: Color): Float = ((max(c.red, max(c.green, c.blue)) - min(c.red, min(c.green, c.blue))) * 255f - 12f).div(70f).coerceIn(0f, 1f)

private fun satColor(c: Color, t: Float): Color {
    val m = (c.red + c.green + c.blue) / 3f
    fun ch(v: Float) = (m + (v - m) * (1f + t)).coerceIn(0f, 1f)
    return Color(ch(c.red), ch(c.green), ch(c.blue), 1f)
}

/**
 * A key of puffed-up clay at ([x], [y]) of size [w] by [h]. From the outside in: a tight contact shadow, a soft cast shadow to
 * the lower right and a pale halo to the upper left; a face lit from the upper left; shade along the lower right edge and a
 * warm bounce of light inside the clay along the bottom; a soft sheen over the top third, a crisp rim light on the upper-left
 * edge, and a hairline round the whole edge. [p] is how far it is pressed in (0 resting, 1 all the way down): the shadows
 * collapse, the sheen and rim go out, and the shading flips so the key looks sunk into the body. [k] scales the shadows.
 */
internal fun DrawScope.drawClayBody(x: Float, y: Float, w: Float, h: Float, r: Float, base: Color, pal: ClayPalette, p: Float, k: Float = 1f) {
    val u = density
    val dk = pal.dark
    // Coloured keys (=, DEL, AC, operators) cast and shade in their own hue, not in grey, so they sit in the body instead of on it.
    val ch = chromaOf(base)
    val castC = lerp(pal.shDark, darker(satColor(base, 0.5f), if (dk) 0.55f else 0.38f), ch * 0.85f)
    val shadeC = lerp(pal.inDark, darker(satColor(base, 0.7f), if (dk) 0.62f else 0.5f), ch * 0.9f)
    val edgeC = lerp(pal.shDark, darker(base, 0.55f), ch)
    softShadow(x, y, w, h, r, 0f, mixf(1.4f, 0.4f, p) * u, 2.4f * u, pal.ao, pal.aoA * 1.15f * k)
    softShadow(x, y, w, h, r, mixf(2.6f, 0.5f, p) * u, mixf(4.2f, 1f, p) * u, mixf(9f, 2.4f, p) * u, castC, min(0.9f, pal.shDarkA * k * (1f - 0.35f * p) * (1f + (if (dk) 0.15f else 0.55f) * ch)))
    softShadow(x, y, w, h, r, mixf(-2.6f, -0.5f, p) * u, mixf(-2.8f, -0.5f, p) * u, mixf(6.5f, 2.4f, p) * u, pal.shLight, pal.shLightA * k * (1f - 0.8f * p) * (1f - 0.7f * ch))
    val face = darker(base, mixf(0f, if (dk) 0.10f else 0.045f, p))
    drawRoundRect(
        Brush.linearGradient(
            0f to lighter(face, mixf(if (dk) 0.13f else 0.5f, if (dk) 0.02f else 0.06f, p) * (1f - 0.35f * ch)),
            0.42f to lighter(face, mixf(if (dk) 0.03f else 0.08f, 0f, p)),
            1f to darker(face, if (dk) 0.26f else 0.10f),
            start = Offset(x + w * 0.15f, y), end = Offset(x + w * 0.7f, y + h),
        ),
        Offset(x, y), Size(w, h), CornerRadius(r),
    )
    insetShadow(x, y, w, h, r, mixf(-2f, 3f, p) * u, mixf(-3.2f, 3.6f, p) * u, mixf(7f, 6f, p) * u, shadeC, pal.inDarkA * mixf(if (dk) 0.9f else 0.6f, if (dk) 1f else 0.85f, p) * (1f - 0.25f * ch))
    if (p < 1f) {
        insetShadow(x, y, w, h, r, 0f, -2.6f * u, 5f * u, satColor(lighter(base, if (dk) 0.18f else 0.12f), if (dk) 0.5f else 0.8f), (if (dk) 0.22f else 0.30f) * (1f - p))
    }
    insetShadow(x, y, w, h, r, mixf(2.2f, -2f, p) * u, mixf(2.6f, -2.4f, p) * u, mixf(4.5f, 3.5f, p) * u, pal.inLight, pal.inLightA * mixf(if (dk) 0.8f else 0.85f, if (dk) 0.5f else 0.7f, p) * (1f - 0.5f * ch))
    if (p < 1f) {
        val a = 1f - p
        val body = Path().apply { addRoundRect(RoundRect(Rect(x, y, x + w, y + h), CornerRadius(r))) }
        clipPath(body) {
            // the sheen: a soft oval of light high on the upper left, so it has no edge to find
            val c = Offset(x + w * 0.36f, y + h * 0.2f)
            val rad = w * 0.44f
            withTransform({ scale(1f, 0.42f, c) }) {
                drawCircle(
                    Brush.radialGradient(
                        0f to Color.White.copy(alpha = (if (dk) 0.17f else 0.62f) * a),
                        0.55f to Color.White.copy(alpha = (if (dk) 0.07f else 0.24f) * a),
                        1f to Color.White.copy(alpha = 0f),
                        center = c, radius = rad,
                    ),
                    rad, c,
                )
            }
        }
        drawRoundRect(
            Brush.linearGradient(
                0f to Color.White.copy(alpha = (if (dk) 0.55f else 1f) * a), 0.5f to Color.White.copy(alpha = 0f),
                start = Offset(x, y), end = Offset(x + w * 0.55f, y + h * 0.8f),
            ),
            Offset(x + 0.6f * u, y + 0.6f * u), Size(w - 1.2f * u, h - 1.2f * u), CornerRadius(max(0f, r - 0.6f * u)), style = Stroke(1.1f * u),
        )
    }
    drawRoundRect(edgeC.copy(alpha = (if (dk) 0.30f else 0.06f) + ch * (if (dk) 0f else 0.07f)), Offset(x, y), Size(w, h), CornerRadius(r), style = Stroke(0.8f * u))
}

/** A glossy clay ball (SHIFT, ALPHA, MODE, 2nd): the same light, a rounder face and a bright reflection. */
internal fun DrawScope.drawClaySphere(x: Float, y: Float, d: Float, base: Color, pal: ClayPalette, p: Float) {
    val u = density
    val dk = pal.dark
    val c = Offset(x + d / 2f, y + d / 2f)
    softShadow(x, y, d, d, d / 2f, 0f, mixf(1.6f, 0.6f, p) * u, 3f * u, pal.ao, pal.aoA)
    softShadow(x, y, d, d, d / 2f, mixf(2.8f, 1f, p) * u, mixf(3.6f, 1.4f, p) * u, mixf(7.5f, 3.5f, p) * u, pal.shDark, pal.shDarkA)
    softShadow(x, y, d, d, d / 2f, mixf(-2.6f, -1f, p) * u, mixf(-2.6f, -1f, p) * u, mixf(6f, 3f, p) * u, pal.shLight, pal.shLightA * (1f - 0.7f * p))
    val face = darker(base, 0.06f * p)
    drawCircle(
        Brush.radialGradient(
            0f to lighter(face, if (dk) 0.28f else 0.55f), 0.45f to face, 1f to darker(face, if (dk) 0.35f else 0.16f),
            center = Offset(c.x - d * 0.18f, c.y - d * 0.22f), radius = d * 0.78f,
        ),
        d / 2f, c,
    )
    // a thin rim: lit on the top left, shaded on the bottom right
    drawCircle(
        Brush.linearGradient(
            0f to Color.White.copy(alpha = 0.85f), 0.45f to Color.White.copy(alpha = 0f), 0.6f to Color.Black.copy(alpha = 0f), 1f to pal.shDark.copy(alpha = 0.45f),
            start = Offset(x, y), end = Offset(x + d, y + d),
        ),
        d / 2f - 1.2f * u, c, style = Stroke(2.4f * u),
    )
    if (p < 1f) {
        drawCircle(
            Brush.radialGradient(
                0f to Color.White.copy(alpha = 0.9f * (1f - p)), 1f to Color.White.copy(alpha = 0f),
                center = Offset(c.x - d * 0.2f, c.y - d * 0.26f), radius = d * 0.3f,
            ),
            d / 2f, c,
        )
    }
}

/** The bodies already painted: one small bitmap per size, colour, body and state, shared by every key that looks the same. */
internal object ClayBitmaps {
    private val map = HashMap<String, ImageBitmap>()

    fun get(key: String, w: Int, h: Int, density: Density, draw: DrawScope.() -> Unit): ImageBitmap {
        map[key]?.let { return it }
        if (map.size > 200) map.clear()
        val bmp = ImageBitmap(max(w, 1), max(h, 1))
        CanvasDrawScope().draw(density, LayoutDirection.Ltr, GfxCanvas(bmp), Size(bmp.width.toFloat(), bmp.height.toFloat()), draw)
        map[key] = bmp
        return bmp
    }
}

/**
 * Makes whatever it is on a clay button: a pill, a key, a sphere (with [sphere]). [pressed] is read only while drawing, so the
 * press animation never makes anything compose again. Big shapes (cards) are drawn directly instead of through a bitmap.
 */
internal fun Modifier.clayShape(radius: Dp, base: Color, pal: ClayPalette, pressed: () -> Float = { 0f }, strength: Float = 1f, sphere: Boolean = false): Modifier =
    this.drawWithCache {
        val w = size.width
        val h = size.height
        val m = ceil(16.dp.toPx())
        val r = if (sphere) min(w, h) / 2f else min(radius.toPx(), min(w, h) / 2f)
        val direct = w * h > 90000f * density * density
        val bw = ceil(w + 2f * m).toInt()
        val bh = ceil(h + 2f * m).toInt()
        val id = "${base.value}|${pal.dark}|${w.toInt()}x${h.toInt()}|${r.toInt()}|$strength|$sphere|$density"
        val rest = if (direct) null else ClayBitmaps.get("$id|0", bw, bh, this) { paintClay(m, w, h, r, base, pal, 0f, strength, sphere) }
        var down: ImageBitmap? = null
        onDrawBehind {
            val p = pressed().coerceIn(0f, 1f)
            if (direct) {
                paintClay(0f, w, h, r, base, pal, p, strength, sphere)
            } else {
                if (p < 1f) drawImage(rest!!, Offset(-m, -m), alpha = 1f - p)
                if (p > 0f) {
                    val d = down ?: ClayBitmaps.get("$id|1", bw, bh, this@drawWithCache) { paintClay(m, w, h, r, base, pal, 1f, strength, sphere) }
                    down = d
                    drawImage(d, Offset(-m, -m), alpha = p)
                }
            }
        }
    }

private fun DrawScope.paintClay(m: Float, w: Float, h: Float, r: Float, base: Color, pal: ClayPalette, p: Float, k: Float, sphere: Boolean) {
    if (sphere) drawClaySphere(m, m, min(w, h), base, pal, p) else drawClayBody(m, m, w, h, r, base, pal, p, k)
}

// ---- The direction pad ----------------------------------------------------------------------

/** The pad's plate: a clay disc with a dished middle. */
internal fun DrawScope.drawPadPlate(x: Float, y: Float, d: Float, pal: ClayPalette) {
    val u = density
    val dk = pal.dark
    val rad = d / 2f
    val cx = x + rad
    val cy = y + rad
    drawClayBody(x, y, d, d, rad, pal.fn, pal, 0f, 1f)
    val r2 = rad * 0.70f
    softShadow(cx - r2, cy - r2, 2f * r2, 2f * r2, r2, 1.5f * u, 2f * u, 3f * u, pal.shLight, pal.shLightA * 0.9f)
    drawCircle(
        Brush.linearGradient(
            0f to darker(pal.fn, if (dk) 0.28f else 0.07f), 1f to lighter(pal.fn, if (dk) 0.04f else 0.35f),
            start = Offset(cx - r2, cy - r2), end = Offset(cx + r2 * 0.6f, cy + r2),
        ),
        r2, Offset(cx, cy),
    )
    insetShadow(cx - r2, cy - r2, 2f * r2, 2f * r2, r2, 2.2f * u, 3f * u, 6f * u, pal.shDark, pal.inDarkA * 0.95f)
}

/** Draws the pad in the middle of whatever it is on, with the arrow in [lit] (0 left, 1 right, 2 up, 3 down, -1 none) glowing. */
internal fun Modifier.clayPad(pal: ClayPalette, lit: () -> Int): Modifier = this.drawWithCache {
    val d = min(size.width, size.height)
    val m = ceil(16.dp.toPx())
    val ox = (size.width - d) / 2f
    val oy = (size.height - d) / 2f
    val bmp = ceil(d + 2f * m).toInt()
    val plate = ClayBitmaps.get("pad|${pal.dark}|${d.toInt()}|$density", bmp, bmp, this) { drawPadPlate(m, m, d, pal) }
    val rad = d / 2f
    val a = rad * 0.10f
    val dist = rad * 0.46f
    val c = Offset(ox + rad, oy + rad)
    val spots = listOf(Offset(c.x - dist, c.y), Offset(c.x + dist, c.y), Offset(c.x, c.y - dist), Offset(c.x, c.y + dist))
    val u = density
    onDrawBehind {
        drawImage(plate, Offset(ox - m, oy - m))
        val on = lit()
        spots.forEachIndexed { dir, pt ->
            if (dir == on) {
                drawCircle(Brush.radialGradient(0f to pal.accent.copy(alpha = 0.45f), 1f to pal.accent.copy(alpha = 0f), center = pt, radius = rad * 0.5f), rad * 0.5f, pt)
            }
            fun tri(ox2: Float, oy2: Float, color: Color) {
                val p = Path()
                val px = pt.x + ox2
                val py = pt.y + oy2
                when (dir) {
                    0 -> { p.moveTo(px - a, py); p.lineTo(px + a * 0.7f, py - a); p.lineTo(px + a * 0.7f, py + a) }
                    1 -> { p.moveTo(px + a, py); p.lineTo(px - a * 0.7f, py - a); p.lineTo(px - a * 0.7f, py + a) }
                    2 -> { p.moveTo(px, py - a); p.lineTo(px - a, py + a * 0.7f); p.lineTo(px + a, py + a * 0.7f) }
                    else -> { p.moveTo(px, py + a); p.lineTo(px - a, py - a * 0.7f); p.lineTo(px + a, py - a * 0.7f) }
                }
                p.close()
                drawPath(p, color)
            }
            tri(0f, 1.2f * u, Color.White.copy(alpha = if (pal.dark) 0.10f else 0.95f))
            tri(0f, 0f, if (dir == on) pal.accent else pal.fnInk)
        }
    }
}

/** A soft raised row or tile for the menus: a quieter clay than a key. */
internal fun Modifier.clayRaised(radius: Dp = 14.dp, strength: Float = 0.6f): Modifier {
    val pal = ClayLook.pal
    return this.clayShape(radius, pal.raised, pal, strength = strength).clip(androidx.compose.foundation.shape.RoundedCornerShape(radius))
}

/** A well cut into the body (text boxes): lit along its lower edge, shaded inside along its upper edge. */
internal fun Modifier.clayWell(radius: Dp, pal: ClayPalette): Modifier = this.drawBehind {
    val r = radius.toPx()
    val u = density
    softShadow(0f, 0f, size.width, size.height, r, 1.5f * u, 2f * u, 3.5f * u, pal.shLight, pal.shLightA)
    drawRoundRect(pal.well, Offset.Zero, size, CornerRadius(r))
    insetShadow(0f, 0f, size.width, size.height, r, 2f * u, 2.6f * u, 6f * u, pal.shDark, min(0.9f, pal.inDarkA + 0.25f))
}

// ---- The body, the screen, the little printed things ----------------------------------------

/** The device itself: a soft vertical gradient, light falling from the top left, and a fine grain like moulded clay. */
internal fun Modifier.calcChassis(): Modifier = this.drawWithCache {
    val pal = ClayLook.pal
    val rnd = Random(7)
    val specks = List(600) { Offset(rnd.nextFloat() * size.width, rnd.nextFloat() * size.height) to rnd.nextFloat() }
    val body = Brush.verticalGradient(listOf(pal.bodyTop, pal.bodyBot))
    val glow = Brush.radialGradient(
        0f to Color.White.copy(alpha = if (pal.dark) 0.06f else 0.65f), 1f to Color.White.copy(alpha = 0f),
        center = Offset(size.width * 0.17f, size.height * 0.05f), radius = size.width * 1.2f,
    )
    val lightSpeck = Color.White.copy(alpha = if (pal.dark) 0.03f else 0.35f)
    val darkSpeck = Color(0xFF3C3278).copy(alpha = if (pal.dark) 0f else 0.05f)
    onDrawBehind {
        drawRect(body)
        drawRect(glow)
        val s = 0.7.dp.toPx()
        specks.forEach { (pt, a) -> drawRect(if (a > 0.5f) lightSpeck else darkSpeck, pt, Size(s, s)) }
    }
}

/** The recess the screen sits in, and the dark glass frame inside it. Give the screen 11 dp of padding to sit inside this. */
internal fun Modifier.lcdWell(pal: ClayPalette): Modifier = this.drawBehind {
    val u = density
    val w = size.width
    val h = size.height
    val r = 22f * u
    softShadow(0f, 0f, w, h, r, 2f * u, 3f * u, 6f * u, pal.shLight, pal.shLightA)
    drawRoundRect(pal.well, Offset.Zero, size, CornerRadius(r))
    insetShadow(0f, 0f, w, h, r, 3f * u, 4f * u, 9f * u, pal.shDark, min(0.9f, pal.inDarkA + 0.3f))
    val b = 7f * u
    val fs = Size(w - 2f * b, h - 2f * b)
    drawRoundRect(Brush.verticalGradient(listOf(pal.glass0, pal.glass1)), Offset(b, b), fs, CornerRadius(16f * u))
    drawRoundRect(
        Brush.verticalGradient(0f to Color.White.copy(alpha = 0.35f), 0.5f to Color.White.copy(alpha = 0.05f), 1f to Color.White.copy(alpha = 0.18f)),
        Offset(b, b), fs, CornerRadius(16f * u), style = Stroke(1f * u),
    )
}

/**
 * Draws a screen under glass. Put it after the screen's own background and clip: it adds the faint rows of an LCD, the soft
 * shadow the frame throws on the top and sides, a diagonal reflection across the upper left and a dark lip round the edge.
 */
internal fun Modifier.lcdGlass(): Modifier = this.drawWithCache {
    val w = size.width
    val h = size.height
    val step = Math.round(3f * density).coerceAtLeast(3).toFloat() // whole pixels, so the rows never shimmer
    val top = Brush.verticalGradient(listOf(Color(0x4D000000), Color.Transparent), startY = 0f, endY = 12.dp.toPx())
    val left = Brush.horizontalGradient(listOf(Color(0x2E000000), Color.Transparent), startX = 0f, endX = 8.dp.toPx())
    val right = Brush.horizontalGradient(listOf(Color.Transparent, Color(0x1F000000)), startX = w - 8.dp.toPx(), endX = w)
    val glare = Path().apply {
        moveTo(0f, 0f); lineTo(w * 0.62f, 0f); lineTo(w * 0.30f, h * 0.58f); lineTo(0f, h * 0.58f); close()
    }
    val glareBrush = Brush.linearGradient(listOf(Color(0x57FFFFFF), Color(0x05FFFFFF)), start = Offset(0f, 0f), end = Offset(w * 0.5f, h * 0.58f))
    onDrawWithContent {
        drawContent()
        var y = step
        while (y < h) { drawRect(Color(0x07000000), Offset(0f, y), Size(w, 1f)); y += step }
        drawRect(top); drawRect(left); drawRect(right)
        drawPath(glare, glareBrush)
        drawRoundRect(Color(0x59000000), cornerRadius = CornerRadius(12.dp.toPx()), style = Stroke(1.dp.toPx()))
    }
}

/** The ink's shadow on an LCD: segments sit a hair above the back plate, so each glyph throws a faint offset shadow. */
internal fun lcdInkShadow(ink: Color) = Shadow(ink.copy(alpha = 0.14f), Offset(1.2f, 2f), 2f)

/** The soft pressed-in edge printed text gets on clay: a pale lower edge on the light body, a dark one on the dark body. */
internal fun embossShadow(pal: ClayPalette) = if (pal.dark) Shadow(Color.Black.copy(alpha = 0.55f), Offset(0f, 2f), 0f) else Shadow(Color.White.copy(alpha = 0.95f), Offset(0f, 2f), 0f)

/** The round clay Back button. */
@Composable
internal fun CalcBackButton(onClick: () -> Unit) {
    val pal = ClayLook.pal
    Box(
        Modifier
            .size(44.dp)
            .clayShape(22.dp, pal.sPearl, pal, sphere = true)
            .clip(CircleShape)
            .clickable(role = Role.Button, onClick = onClick)
            .semantics { contentDescription = "Back" },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(24.dp)) {
            val p = Path().apply {
                moveTo(size.width * 0.625f, size.height * 0.208f)
                lineTo(size.width * 0.333f, size.height * 0.5f)
                lineTo(size.width * 0.625f, size.height * 0.792f)
            }
            drawPath(p, pal.ink, style = Stroke(width = 2.2.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
        }
    }
}

/** The wordmark and model line printed on the body, on the left. */
@Composable
internal fun CalcBrand(modifier: Modifier = Modifier) {
    val pal = ClayLook.pal
    Column(modifier) {
        Text(
            "LOCKIN",
            style = LockInText.Small.copy(
                color = pal.ink, fontFamily = Fonts.Wordmark, fontSize = 18.sp, lineHeight = 22.sp, letterSpacing = 2.6.sp,
                shadow = embossShadow(pal),
            ),
            maxLines = 1,
        )
        Text(
            "SCIENTIFIC CALCULATOR",
            style = LockInText.Small.copy(color = pal.dim, fontSize = 8.5.sp, lineHeight = 11.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.SemiBold),
            maxLines = 1,
        )
    }
}

/** The line across the top of the device: brand on the left, the engraved model plate on the right. */
@Composable
internal fun CalcBrandRow(modifier: Modifier = Modifier) {
    val pal = ClayLook.pal
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        CalcBrand()
        Column(horizontalAlignment = Alignment.End) {
            Text(
                "LI-991",
                style = LockInText.Small.copy(
                    color = pal.ink, fontSize = 13.sp, lineHeight = 16.sp, letterSpacing = 1.6.sp, fontWeight = FontWeight.ExtraBold,
                    shadow = embossShadow(pal),
                ),
                maxLines = 1,
            )
            Text(
                "NATURAL DISPLAY",
                style = LockInText.Small.copy(color = pal.dim, fontSize = 8.5.sp, lineHeight = 11.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.SemiBold),
                maxLines = 1,
            )
        }
    }
}
