package com.godbless.lockin.study

import android.graphics.Bitmap
import android.util.LruCache
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

// =============================================================================================
// The words on a page
//
// The PDF is drawn as a picture, so the words on a page are found by reading that picture on this phone
// (ML Kit text recognition, no internet). Each word keeps its box as fractions of the page, so it is the same
// at any zoom. Pages are read as you reach them and kept in a file, so a page is only ever read once.
// =============================================================================================

/** One word and where it is on the page (fractions of the page's width and height). [line] numbers the printed lines in reading order. */
internal class Word(val text: String, val l: Float, val t: Float, val r: Float, val b: Float, val line: Int)

/** Every word on one page, in reading order. [ratio] is the page's height over its width. */
internal class PageWords(val words: List<Word>, val ratio: Float) {

    /** The word nearest the point (x, y), or -1 when nothing is within [maxDist] (a share of the page's width). */
    fun nearest(x: Float, y: Float, maxDist: Float = 0.12f): Int {
        var best = -1
        var bestD = Float.MAX_VALUE
        for (i in words.indices) {
            val w = words[i]
            val dx = if (x < w.l) w.l - x else if (x > w.r) x - w.r else 0f
            // A step down the page is longer than the same step across it.
            val dy = (if (y < w.t) w.t - y else if (y > w.b) y - w.b else 0f) * ratio
            val d = dx * dx + dy * dy
            if (d < bestD) {
                bestD = d
                best = i
            }
        }
        return if (best >= 0 && sqrt(bestD) <= maxDist) best else -1
    }

    /** The words from [a] to [b] (any order) as a selection: its box covers them all, and it remembers which words. */
    fun selection(page: Int, a: Int, b: Int): PageSel {
        val from = max(0, min(a, b))
        val to = min(words.lastIndex, max(a, b))
        var l = 1f; var t = 1f; var r = 0f; var bt = 0f
        for (i in from..to) {
            val w = words[i]
            l = min(l, w.l); t = min(t, w.t); r = max(r, w.r); bt = max(bt, w.b)
        }
        return PageSel(page, l, t, r, bt, from, to)
    }

    /** One box per printed line for the words [from] to [to]: what a highlight looks like. Each is [l, t, r, b]. */
    fun lineRects(from: Int, to: Int): List<FloatArray> {
        val out = ArrayList<FloatArray>()
        if (words.isEmpty() || from < 0) return out
        var cur: FloatArray? = null
        var curLine = -1
        for (i in from..min(to, words.lastIndex)) {
            val w = words[i]
            val c = cur
            if (c != null && w.line == curLine) {
                c[0] = min(c[0], w.l); c[1] = min(c[1], w.t); c[2] = max(c[2], w.r); c[3] = max(c[3], w.b)
            } else {
                cur = floatArrayOf(w.l, w.t, w.r, w.b)
                curLine = w.line
                out.add(cur)
            }
        }
        return out
    }

    /** Which words a selection holds: the range it remembers, or else the words whose middle is inside its box. */
    fun indicesFor(sel: PageSel): IntRange {
        if (sel.from >= 0 && sel.to >= sel.from && sel.to <= words.lastIndex) return sel.from..sel.to
        val inside = words.indices.filter { i ->
            val w = words[i]
            val cx = (w.l + w.r) / 2f
            val cy = (w.t + w.b) / 2f
            cx >= sel.l && cx <= sel.r && cy >= sel.t && cy <= sel.b
        }
        return if (inside.isEmpty()) IntRange.EMPTY else inside.first()..inside.last()
    }

    fun textOf(range: IntRange): String =
        if (range.isEmpty()) "" else range.joinToString(" ") { words[it].text }.replace(Regex("\\s+"), " ").trim()
}

/** A page ready to search: the words joined into one line of text, and where each word starts in it. */
private class Flat(val pw: PageWords, val shown: String, val lower: String, val starts: IntArray)

/** One place the search words were found. [snip] is a bit of the text around it; the match is [snipFrom] until [snipTo]. */
internal class Hit(val page: Int, val snip: String, val snipFrom: Int, val snipTo: Int, val rects: List<FloatArray>)

/**
 * The words of one book's pages. Pages are read for their text when you reach them (or all at once with [indexAll]),
 * kept in files under [dir], and searched from there. Reading a page takes about half a second on a phone.
 */
internal class PageTextIndex(private val dir: File) {
    private val mem = LruCache<Int, Flat>(400)
    private val readLock = Mutex()
    private val done = java.util.BitSet()
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    /** How many pages have been read for their words. A screen that shows it redraws as it grows. */
    var count by mutableIntStateOf(0)
        private set

    /** True while [indexAll] is working. */
    var indexing by mutableStateOf(false)
        private set

    init {
        dir.mkdirs()
        dir.list()?.forEach { n ->
            if (n.startsWith("p") && n.endsWith(".json")) n.substring(1, n.length - 5).toIntOrNull()?.let { synchronized(done) { done.set(it) } }
        }
        count = synchronized(done) { done.cardinality() }
    }

    fun has(page: Int): Boolean = synchronized(done) { done.get(page) }

    /** The words of [page] if they're ready in memory right now (never waits). */
    fun peek(page: Int): PageWords? = mem.get(page)?.pw

    /** The words of [page]: from memory, from the file, or by reading the page (the first time, about half a second). Null if it can't be read. */
    suspend fun words(doc: PdfDoc, page: Int): PageWords? = flat(doc, page)?.pw

    private suspend fun flat(doc: PdfDoc?, page: Int): Flat? {
        mem.get(page)?.let { return it }
        return withContext(Dispatchers.IO) {
            mem.get(page) ?: loadOrRead(doc, page)
        }
    }

    private suspend fun loadOrRead(doc: PdfDoc?, page: Int): Flat? {
        if (has(page)) readFile(page)?.let { f -> mem.put(page, f); return f }
        if (doc == null) return null
        return readLock.withLock {
            val again = mem.get(page)
            if (again != null) {
                again
            } else {
                val pw = runCatching { recognizePage(doc, page) }.getOrNull()
                if (pw == null) {
                    null
                } else {
                    runCatching { writeFile(page, pw) }
                    synchronized(done) { done.set(page); count = done.cardinality() }
                    makeFlat(pw).also { mem.put(page, it) }
                }
            }
        }
    }

    /** Reads every page that hasn't been read yet, one after another, pausing while [pause] says so (while you scroll). */
    suspend fun indexAll(doc: PdfDoc, pause: () -> Boolean) {
        if (indexing) return
        indexing = true
        try {
            for (p in 0 until doc.pageCount) {
                if (has(p)) continue
                while (pause()) delay(400)
                currentCoroutineContext().ensureActive()
                flat(doc, p)
                delay(30)
            }
        } finally {
            indexing = false
        }
    }

    /** Where [query] appears in the pages read so far, in page order. Nothing for less than two letters. */
    suspend fun search(query: String, limit: Int = 300): List<Hit> = withContext(Dispatchers.Default) {
        val q = query.trim().lowercase()
        if (q.length < 2) return@withContext emptyList<Hit>()
        val pages = ArrayList<Int>()
        synchronized(done) {
            var p = done.nextSetBit(0)
            while (p >= 0) { pages.add(p); p = done.nextSetBit(p + 1) }
        }
        val hits = ArrayList<Hit>()
        for (p in pages) {
            currentCoroutineContext().ensureActive()
            val f = mem.get(p) ?: readFile(p)?.also { mem.put(p, it) } ?: continue
            var at = f.lower.indexOf(q)
            while (at >= 0 && hits.size < limit) {
                val end = at + q.length - 1
                val a = wordAt(f.starts, at)
                val b = wordAt(f.starts, end)
                val s0 = max(0, at - 28)
                val s1 = min(f.shown.length, end + 1 + 52)
                val pre = if (s0 > 0) "…" else ""
                val snip = pre + f.shown.substring(s0, s1) + if (s1 < f.shown.length) "…" else ""
                hits.add(Hit(p, snip, pre.length + (at - s0), pre.length + (end + 1 - s0), f.pw.lineRects(a, b)))
                at = f.lower.indexOf(q, at + q.length)
            }
            if (hits.size >= limit) break
        }
        hits
    }

    /** Which word the character at [pos] belongs to. */
    private fun wordAt(starts: IntArray, pos: Int): Int {
        var lo = 0
        var hi = starts.lastIndex
        while (lo < hi) {
            val mid = (lo + hi + 1) / 2
            if (starts[mid] <= pos) lo = mid else hi = mid - 1
        }
        return lo
    }

    private fun makeFlat(pw: PageWords): Flat {
        val sb = StringBuilder()
        val starts = IntArray(pw.words.size)
        pw.words.forEachIndexed { i, w ->
            if (i > 0) sb.append(' ')
            starts[i] = sb.length
            sb.append(w.text)
        }
        val shown = sb.toString()
        val lower = shown.lowercase().let { if (it.length == shown.length) it else shown }
        return Flat(pw, shown, lower, starts)
    }

    private suspend fun recognizePage(doc: PdfDoc, page: Int): PageWords? {
        val bmp = doc.bitmapUncached(page, OcrWidth) ?: return null
        try {
            val result = suspendCancellableCoroutine<com.google.mlkit.vision.text.Text> { c ->
                recognizer.process(InputImage.fromBitmap(bmp, 0))
                    .addOnSuccessListener { c.resume(it) }
                    .addOnFailureListener { c.resumeWithException(it) }
            }
            val w = bmp.width.toFloat()
            val h = bmp.height.toFloat()
            val out = ArrayList<Word>()
            var line = 0
            for (block in result.textBlocks) {
                for (ln in block.lines) {
                    for (el in ln.elements) {
                        val bb = el.boundingBox ?: continue
                        val text = el.text.trim()
                        if (text.isEmpty()) continue
                        out.add(
                            Word(
                                text,
                                (bb.left / w).coerceIn(0f, 1f), (bb.top / h).coerceIn(0f, 1f),
                                (bb.right / w).coerceIn(0f, 1f), (bb.bottom / h).coerceIn(0f, 1f),
                                line,
                            ),
                        )
                    }
                    line++
                }
            }
            return PageWords(out, h / w)
        } finally {
            bmp.recycle()
        }
    }

    private fun file(page: Int) = File(dir, "p$page.json")

    private fun writeFile(page: Int, pw: PageWords) {
        val a = JSONArray()
        for (w in pw.words) {
            a.put(JSONArray().put(w.text).put(r4(w.l)).put(r4(w.t)).put(r4(w.r)).put(r4(w.b)).put(w.line))
        }
        val text = JSONObject().put("r", r4(pw.ratio)).put("w", a).toString()
        val tmp = File(dir, "p$page.tmp")
        tmp.writeText(text)
        if (!tmp.renameTo(file(page))) {
            file(page).delete()
            tmp.renameTo(file(page))
        }
    }

    private fun r4(f: Float): Double = (f * 10000f).roundToInt() / 10000.0

    private fun readFile(page: Int): Flat? = runCatching {
        val o = JSONObject(file(page).readText())
        val a = o.getJSONArray("w")
        val words = List(a.length()) {
            val x = a.getJSONArray(it)
            Word(x.getString(0), x.getDouble(1).toFloat(), x.getDouble(2).toFloat(), x.getDouble(3).toFloat(), x.getDouble(4).toFloat(), x.getInt(5))
        }
        makeFlat(PageWords(words, o.optDouble("r", 1.414).toFloat()))
    }.getOrNull()

    companion object {
        /** Pages are read at this width: small print stays readable, and a page still takes under a second. */
        private const val OcrWidth = 1500
    }
}

/** A bitmap that can be dropped as soon as it has been read. */
internal fun Bitmap.dispose() {
    if (!isRecycled) recycle()
}
