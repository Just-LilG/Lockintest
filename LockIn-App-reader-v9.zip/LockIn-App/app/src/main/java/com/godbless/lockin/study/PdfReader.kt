package com.godbless.lockin.study

import android.graphics.Bitmap
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.gestures.animateScrollBy
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.scrollable
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.coerceAtLeast
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.godbless.lockin.home.Glyph
import com.godbless.lockin.home.GlyphIcon
import com.godbless.lockin.ui.BackButton
import com.godbless.lockin.ui.RC
import com.godbless.lockin.ui.RT
import com.godbless.lockin.ui.UiGlide
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

/**
 * An open PDF. Android's renderer draws one page at a time and is not thread safe, so every draw goes
 * through one lock, and finished pages are kept in a cache sized in bytes.
 */
internal class PdfDoc(file: File) {
    private val fd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer = PdfRenderer(fd)
    private val lock = Any()
    private var closed = false

    val pageCount: Int = renderer.pageCount

    // height / width of each page. Everything starts as the first page's shape and is corrected as pages draw.
    private val ratios = FloatArray(pageCount) { 1.414f }

    init {
        synchronized(lock) {
            val first = renderer.openPage(0)
            try {
                val r = first.height.toFloat() / first.width
                ratios.fill(r)
            } finally {
                first.close()
            }
            // Every page's own shape, so a cover, a landscape insert or a fold-out does not change height (and move
            // the page you're on) when it is first drawn. Skipped for enormous books, where it would take too long.
            if (pageCount in 2..1500) {
                for (i in 1 until pageCount) {
                    val pg = runCatching { renderer.openPage(i) }.getOrNull() ?: continue
                    try {
                        if (pg.width > 0) ratios[i] = pg.height.toFloat() / pg.width
                    } finally {
                        pg.close()
                    }
                }
            }
        }
    }

    // Pages are drawn one at a time anyway (the renderer takes one lock), so they wait here in order. A page that was
    // scrolled past, or zoomed to another size, while it waited is dropped before it is drawn instead of after.
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    private val renderQueue = Dispatchers.IO.limitedParallelism(1)

    // A sixth of the app's memory, so a sharp zoomed page doesn't push out all the others.
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 6).toInt().coerceIn(32 shl 20, 128 shl 20)) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun ratio(index: Int): Float = ratios[index]

    fun peek(index: Int, widthPx: Int): Bitmap? = cache.get("$index@$widthPx")

    suspend fun bitmap(index: Int, widthPx: Int): Bitmap? = withContext(renderQueue) {
        val key = "$index@$widthPx"
        cache.get(key)?.let { return@withContext it }
        ensureActive()
        val bmp = synchronized(lock) {
            if (closed) null else renderPage(renderer, index, widthPx)
        } ?: return@withContext null
        ratios[index] = bmp.height.toFloat() / bmp.width
        cache.put(key, bmp)
        bmp
    }

    /** A page drawn once for reading its words (not kept in the cache). The caller recycles it. */
    suspend fun bitmapUncached(index: Int, widthPx: Int): Bitmap? = withContext(renderQueue) {
        ensureActive()
        synchronized(lock) {
            if (closed) null else renderPage(renderer, index, widthPx)
        }
    }

    /**
     * Just a part of a page, drawn as sharp as if the whole page were [fullW] pixels wide. [l], [t], [r], [b] are the part,
     * as fractions of the whole page. This is what keeps text crisp when zoomed in far: only what is on screen is drawn.
     */
    suspend fun tile(index: Int, fullW: Int, l: Float, t: Float, r: Float, b: Float): Bitmap? = withContext(renderQueue) {
        ensureActive()
        synchronized(lock) {
            if (closed) null else renderTile(renderer, index, fullW, l, t, r, b)
        }
    }

    fun close() {
        synchronized(lock) {
            if (closed) return
            closed = true
            renderer.close()
            fd.close()
        }
        cache.evictAll()
    }
}

private fun renderTile(renderer: PdfRenderer, index: Int, fullW: Int, l: Float, t: Float, r: Float, b: Float): Bitmap {
    val page = renderer.openPage(index)
    try {
        val scale = fullW.toFloat() / page.width
        val fullH = page.height * scale
        val w = ((r - l) * fullW).roundToInt().coerceIn(1, 4096)
        val h = ((b - t) * fullH).roundToInt().coerceIn(1, 4096)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(android.graphics.Color.WHITE)
        val m = android.graphics.Matrix()
        m.setScale(scale, scale)
        m.postTranslate(-l * fullW, -t * fullH)
        page.render(bmp, null, m, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        return bmp
    } finally {
        page.close()
    }
}

/** The widest a whole page is drawn. Beyond that (zoomed in far) the part on screen is drawn on its own, see [PdfDoc.tile]. */
private const val MaxBase = 2300

/**
 * Dark pages: black on white becomes white on black, and the colours in diagrams and photos keep their hue
 * (an invert followed by a half turn round the colour wheel), so a red line stays red-ish instead of going cyan.
 */
private val DarkFilter = ColorFilter.colorMatrix(
    ColorMatrix(
        floatArrayOf(
            0.574f, -1.430f, -0.144f, 0f, 255f,
            -0.426f, -0.430f, -0.144f, 0f, 255f,
            -0.426f, -1.430f, 0.856f, 0f, 255f,
            0f, 0f, 0f, 1f, 0f,
        ),
    ),
)

/** Sepia pages: white paper turns warm cream, easier on the eyes at night. */
private val SepiaFilter = ColorFilter.colorMatrix(
    ColorMatrix(
        floatArrayOf(
            0.98f, 0f, 0f, 0f, 0f,
            0f, 0.93f, 0f, 0f, 0f,
            0f, 0f, 0.78f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f,
        ),
    ),
)

private val ToneNames = listOf("Light", "Dark", "Sepia")

/** The reader's own settings that stay between books and visits. */
internal object ReaderPrefs {
    private const val PREFS = "reader_prefs"
    fun tone(context: android.content.Context): Int =
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).getInt("tone", 0).coerceIn(0, 2)
    fun setTone(context: android.content.Context, tone: Int) {
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).edit().putInt("tone", tone).apply()
    }

    /** The highlight colour a single tap uses (0 to 3). */
    fun markColor(context: android.content.Context): Int =
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).getInt("markColor", 0).coerceIn(0, 3)
    fun setMarkColor(context: android.content.Context, v: Int) {
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).edit().putInt("markColor", v).apply()
    }
    /** Dark paper whenever the phone is in dark mode. */
    fun autoTone(context: android.content.Context): Boolean =
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).getBoolean("autoTone", false)
    fun setAutoTone(context: android.content.Context, on: Boolean) {
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).edit().putBoolean("autoTone", on).apply()
    }

    /** Screen brightness while reading, 0 to 1, or -1 for the phone's own setting. */
    fun brightness(context: android.content.Context): Float =
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).getFloat("brightness", -1f)
    fun setBrightness(context: android.content.Context, v: Float) {
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).edit().putFloat("brightness", v).apply()
    }
    fun keepAwake(context: android.content.Context): Boolean =
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).getBoolean("awake", false)
    fun setKeepAwake(context: android.content.Context, on: Boolean) {
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).edit().putBoolean("awake", on).apply()
    }

    /** What is trimmed off the edges of this book's pages: left, top, right, bottom as fractions. Nothing by default. */
    fun trim(context: android.content.Context, book: String): FloatArray {
        val s = context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).getString("trim_$book", null)
            ?: return NoTrim.copyOf()
        val v = s.split(",").mapNotNull { it.toFloatOrNull() }
        return if (v.size == 4) FloatArray(4) { v[it].coerceIn(0f, 0.25f) } else NoTrim.copyOf()
    }
    fun setTrim(context: android.content.Context, book: String, t: FloatArray) {
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).edit().putString("trim_$book", t.joinToString(",")).apply()
    }
}

/** Keeps a selection across a rotation. */
private val SelSaver = Saver<PageSel?, ArrayList<Float>>(
    save = { s -> if (s == null) arrayListOf() else arrayListOf(s.page.toFloat(), s.l, s.t, s.r, s.b, s.from.toFloat(), s.to.toFloat()) },
    restore = { v -> if (v.size == 7) PageSel(v[0].toInt(), v[1], v[2], v[3], v[4], v[5].toInt(), v[6].toInt()) else null },
)

/** A slide or glide of [ms], or none at all when Reduce motion is on. */
private fun <T> glide(ms: Int): androidx.compose.animation.core.FiniteAnimationSpec<T> =
    if (com.godbless.lockin.ui.MotionState.reduced) androidx.compose.animation.core.snap() else tween(ms, easing = UiGlide)

/**
 * Reads a textbook. Pages scroll down the screen, pinch with two fingers to zoom (then slide sideways
 * to pan), and the bar at the bottom jumps to a page, flips the pages dark, or makes a flashcard from
 * the page you are on. Where you stopped is remembered.
 */
@Composable
internal fun ReaderScreen(
    store: StudyStore,
    bookId: String,
    startPage: Int,
    onBack: () -> Unit,
) {
    val book = store.book(bookId)
    var doc by remember(bookId) { mutableStateOf<PdfDoc?>(null) }
    var failed by remember(bookId) { mutableStateOf(false) }
    LaunchedEffect(bookId) {
        val opened = withContext(Dispatchers.IO) { runCatching { PdfDoc(store.pdfFile(bookId)) }.getOrNull() }
        if (opened == null) failed = true else doc = opened
    }
    DisposableEffect(bookId) { onDispose { doc?.close() } }

    var zoom by rememberSaveable { mutableFloatStateOf(1f) }
    // 0 light, 1 dark, 2 sepia. Remembered between books and visits.
    val prefsContext = androidx.compose.ui.platform.LocalContext.current
    var tone by rememberSaveable { mutableIntStateOf(ReaderPrefs.tone(prefsContext)) }
    val dark = tone == 1
    // The clock and battery icons turn dark on a light or sepia page and light on a dark one, whatever the app's theme is.
    val barView = androidx.compose.ui.platform.LocalView.current
    DisposableEffect(tone) {
        val window = (barView.context as? android.app.Activity)?.window
        val controller = window?.let { androidx.core.view.WindowCompat.getInsetsController(it, barView) }
        val before = controller?.isAppearanceLightStatusBars
        controller?.isAppearanceLightStatusBars = tone != 1
        onDispose { if (controller != null && before != null) controller.isAppearanceLightStatusBars = before }
    }
    // Dark paper when the phone is dark (if switched on), the colour a tap on Highlight uses, and a few small bits of feedback.
    var autoTone by remember { mutableStateOf(ReaderPrefs.autoTone(prefsContext)) }
    var markColor by remember { mutableIntStateOf(ReaderPrefs.markColor(prefsContext)) }
    val systemDark = androidx.compose.foundation.isSystemInDarkTheme()
    LaunchedEffect(autoTone, systemDark) {
        if (autoTone) tone = if (systemDark) 1 else if (tone == 1) 0 else tone
    }
    var undo by remember { mutableStateOf<MarkUndo?>(null) }
    LaunchedEffect(undo) {
        if (undo != null) {
            delay(4500)
            undo = null
        }
    }
    var brightHud by remember { mutableStateOf(false) }
    // 0 not near an edge, -1 the finger is near the top, 1 near the bottom: the page scrolls while a selection is dragged there.
    var edgeDir by remember { mutableIntStateOf(0) }
    val dragHolder = remember { arrayOfNulls<() -> Unit>(1) }
    // The reader's own buttons, bars and sheets follow the paper (light, dark or sepia), whatever the app's theme is.
    // Only the reader reads this look, so the app behind it never changes. It is set while composing, so the first frame is right.
    val look = remember(tone) { com.godbless.lockin.ui.ReaderLook.forTone(com.godbless.lockin.ui.ThemeState.accent, tone) }
    com.godbless.lockin.ui.ReaderLook.palette = look
    DisposableEffect(Unit) { onDispose { com.godbless.lockin.ui.ReaderLook.palette = null } }
    // Display settings that stay: brightness, keep awake, and what is trimmed off the page edges for this book.
    var brightness by remember { mutableFloatStateOf(ReaderPrefs.brightness(prefsContext)) }
    var keepAwake by remember { mutableStateOf(ReaderPrefs.keepAwake(prefsContext)) }
    var trim by remember(bookId) { mutableStateOf(ReaderPrefs.trim(prefsContext, bookId)) }
    DisposableEffect(brightness) {
        val window = (barView.context as? android.app.Activity)?.window
        if (window != null) {
            val a = window.attributes
            a.screenBrightness = if (brightness < 0f) android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE else brightness
            window.attributes = a
        }
        onDispose {
            if (window != null) {
                val a = window.attributes
                a.screenBrightness = android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                window.attributes = a
            }
        }
    }
    DisposableEffect(keepAwake) {
        barView.keepScreenOn = keepAwake
        onDispose { barView.keepScreenOn = false }
    }
    // Bars hide while you read down the page and come back when you read up, or tap.
    var chrome by remember { mutableStateOf(true) }
    var chip by remember { mutableStateOf(false) }
    var scrollPos by remember { mutableIntStateOf(0) }
    val aiDrag = remember { Animatable(0f) }
    var jump by remember { mutableStateOf(false) }
    var making by remember { mutableStateOf(false) }
    var aiOpen by remember { mutableStateOf(false) }
    var aiQuiz by remember { mutableStateOf(false) }
    // Set when the quiz was asked for in words from the selection panel ("quiz me on osmosis"): what it asked for.
    var quizAsk by remember { mutableStateOf<QuizAsk?>(null) }
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    // Explaining a word or sentence: what's selected on the page, whether a finger is still dragging it, select mode
    // (from the Select button: one finger draws a selection instead of scrolling), and the open explanation.
    var sel by rememberSaveable(bookId, stateSaver = SelSaver) { mutableStateOf<PageSel?>(null) }
    var selecting by remember { mutableStateOf(false) }
    var armed by remember { mutableStateOf(false) }
    var preparing by remember { mutableStateOf(false) }
    var passage by remember(bookId) { mutableStateOf<PassageArgs?>(null) }
    var showTip by remember { mutableStateOf(!ReaderTips.seen(context)) }
    // The words on each page (read on this phone), search, and the side panels: 0 none, 1 display, 2 more, 3 search.
    val ptx = remember(bookId) { PageTextIndex(store.ocrDir(bookId)) }
    var panel by remember { mutableIntStateOf(0) }
    var detecting by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<String?>(null) }
    var notebook by remember { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var hits by remember { mutableStateOf<List<Hit>>(emptyList()) }
    var hitIdx by remember { mutableIntStateOf(0) }
    var searching by remember { mutableStateOf(false) }
    val searchActive = panel == 3 || searching

    val last = ((book?.pages ?: 1) - 1).coerceAtLeast(0)
    val list = rememberLazyListState(initialFirstVisibleItemIndex = (if (startPage >= 0) startPage else (book?.lastPage ?: 0)).coerceIn(0, last))
    // The page you're looking at: the one under the upper-middle of the screen, not the sliver still showing at the top.
    val page by remember {
        derivedStateOf {
            val info = list.layoutInfo
            val at = info.viewportStartOffset + (info.viewportEndOffset - info.viewportStartOffset) * 2 / 5
            info.visibleItemsInfo.firstOrNull { at >= it.offset && at < it.offset + it.size }?.index ?: list.firstVisibleItemIndex
        }
    }
    // Read the words of the page you stay on, and the next one, so selecting and copying are ready when you reach for them.
    LaunchedEffect(page, doc) {
        val d = doc ?: return@LaunchedEffect
        delay(450)
        ptx.words(d, page)
        if (page + 1 <= last) ptx.words(d, page + 1)
    }
    // While search is open, read the rest of the book in the background (pausing while you scroll), and search again as pages arrive.
    LaunchedEffect(searchActive, doc) {
        val d = doc ?: return@LaunchedEffect
        if (searchActive) ptx.indexAll(d) { list.isScrollInProgress }
    }
    // Searches again as you type, and every few pages read (not after every single one), and once when all are read.
    LaunchedEffect(query, ptx.count / 8, ptx.count >= (book?.pages ?: 0), searchActive) {
        if (!searchActive) return@LaunchedEffect
        delay(250)
        val r = ptx.search(query)
        hits = r
        if (hitIdx >= r.size) hitIdx = 0
    }
    LaunchedEffect(list) {
        var prev = list.firstVisibleItemIndex * 100_000 + list.firstVisibleItemScrollOffset
        snapshotFlow { list.firstVisibleItemIndex * 100_000 + list.firstVisibleItemScrollOffset }.collect { pos ->
            val d = pos - prev
            prev = pos
            if (d > 24) chrome = false else if (d < -24) chrome = true
            scrollPos = pos
        }
    }
    // A small "12 / 240" shows while you scroll with the bars away.
    LaunchedEffect(scrollPos) { chip = true; delay(900); chip = false }
    LaunchedEffect(aiOpen) { if (!aiOpen) { delay(380); aiDrag.snapTo(0f) } }
    // The AI sheet explains the page you opened it on, even if you scroll behind it.
    var aiPage by remember { mutableStateOf(0) }
    // Back closes whatever is on top of the page before it leaves the book.
    androidx.activity.compose.BackHandler(enabled = notebook || editing != null || panel != 0 || searching || aiQuiz || aiOpen || making || jump || passage != null || sel != null || armed) {
        when {
            notebook -> notebook = false
            editing != null -> editing = null
            panel != 0 -> panel = 0
            searching -> { searching = false; query = ""; hits = emptyList() }
            passage != null -> passage = null
            sel != null -> sel = null
            armed -> armed = false
            aiQuiz -> aiQuiz = false
            aiOpen -> aiOpen = false
            making -> making = false
            else -> jump = false
        }
    }

    // Remember where you stopped, a moment after you stop moving. A page that stays up 8 seconds counts as read
    // (it's what the AI quiz asks about).
    LaunchedEffect(page) {
        delay(1500)
        store.setLastPage(bookId, page)
        delay(6500)
        store.markRead(bookId, page)
    }
    DisposableEffect(bookId) { onDispose { store.setLastPage(bookId, page) } }

    val topPad = WindowInsets.statusBars.asPaddingValues().calculateTopPadding().coerceAtLeast(36.dp)
    val readerDensity = LocalDensity.current
    // Cut the selection out of a sharp drawing of its page and open the explanation.
    fun openPassage(ask: Boolean, preset: String = "") {
        val s = sel?.norm() ?: return
        val d = doc ?: return
        if (preparing) return
        preparing = true
        scope.launch {
            val cut = d.bitmap(s.page, 1600)?.let { snipForAi(it, s.l, s.t, s.r, s.b) }
            preparing = false
            if (cut == null) {
                android.widget.Toast.makeText(context, "Couldn't read that part. Try selecting it again.", android.widget.Toast.LENGTH_SHORT).show()
                return@launch
            }
            sel = s
            passage = PassageArgs(s, cut.first, cut.second, ask, preset)
            chrome = false
            if (showTip) { showTip = false; ReaderTips.markSeen(context) }
            // On a phone the explanation rises over the lower part of the screen: bring the selection up near the top.
            if (context.resources.configuration.screenWidthDp < 600) {
                val info = list.layoutInfo
                info.visibleItemsInfo.firstOrNull { it.index == s.page }?.let { item ->
                    val y = item.offset - info.viewportStartOffset + s.t * item.size
                    val target = with(readerDensity) { (topPad + 20.dp).toPx() }
                    runCatching { list.animateScrollBy(y - target, glide(380)) }
                }
            }
        }
    }

    fun setTrim(t: FloatArray) {
        trim = t
        ReaderPrefs.setTrim(context, bookId, t)
    }
    // Copy what is selected as text.
    fun copySelection() {
        val s = sel?.norm() ?: return
        val d = doc ?: return
        scope.launch {
            val pw = ptx.words(d, s.page)
            val text = pw?.let { it.textOf(it.indicesFor(s)) }.orEmpty()
            if (text.isBlank()) {
                android.widget.Toast.makeText(context, "No text found there", android.widget.Toast.LENGTH_SHORT).show()
            } else {
                copyText(context, text)
                android.widget.Toast.makeText(context, "Copied", android.widget.Toast.LENGTH_SHORT).show()
                sel = null
            }
        }
    }
    // Highlight what is selected, in one of the four colours, one band per line of text.
    fun highlightSelection(color: Int, withNote: Boolean) {
        val s = sel?.norm() ?: return
        val d = doc ?: return
        scope.launch {
            val pw = ptx.words(d, s.page)
            val range = pw?.indicesFor(s) ?: IntRange.EMPTY
            val rects = if (pw != null && !range.isEmpty()) pw.lineRects(range.first, range.last).map { it.toList() } else listOf(listOf(s.l, s.t, s.r, s.b))
            val text = if (pw != null) pw.textOf(range) else ""
            val m = store.addHighlight(bookId, s.page, rects, text, color)
            markColor = color
            ReaderPrefs.setMarkColor(prefsContext, color)
            sel = null
            if (withNote) editing = m.id else undo = MarkUndo("Highlighted", m, true)
        }
    }
    // Jump to a search match and put it about a third of the way down the screen.
    fun goToHit(i: Int) {
        val h = hits.getOrNull(i) ?: return
        hitIdx = i
        scope.launch {
            list.scrollToItem(h.page.coerceIn(0, last))
            val q = h.rects.firstOrNull() ?: return@launch
            val item = list.layoutInfo.visibleItemsInfo.firstOrNull { it.index == h.page } ?: return@launch
            val sh = (1f - trim[1] - trim[3]).coerceAtLeast(0.2f)
            val y = ((q[1] - trim[1]) / sh) * item.size
            val dy = y - list.layoutInfo.viewportSize.height * 0.33f
            if (dy > 0f) list.scrollBy(dy)
        }
    }

    // What shows between the pages: a soft grey (or a deeper cream, or a dim grey) so the gap reads as paper edges, not a black bar.
    androidx.compose.material3.MaterialTheme(colorScheme = com.godbless.lockin.ui.readerScheme(look)) {
    Box(Modifier.fillMaxSize().background(if (doc == null) RC.Ink else if (dark) Color(0xFF1B1B1B) else if (tone == 2) Color(0xFFD9CBA8) else Color(0xFFD6D6D6))) {
        val d = doc
        when {
            failed || book == null -> Message("Couldn't open this book.", onBack)
            d == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = RC.Lime, strokeWidth = 2.dp)
            }
            else -> BoxWithConstraints(Modifier.fillMaxSize()) {
                val density = LocalDensity.current
                // On a wide screen pages are read at a comfortable width (not stretched across a tablet), centred, and
                // the explanation panel takes the right side instead of covering the page.
                val wideScreen = maxWidth >= 600.dp
                val panelW = if (wideScreen && (passage != null || notebook)) 440.dp else 0.dp
                val avail = maxWidth - panelW
                val screenW = if (wideScreen) minOf(avail, 820.dp) else avail
                val pageW = screenW * zoom
                val leftPad = ((avail - pageW) / 2).coerceAtLeast(0.dp)
                // Pages are drawn in steps of 128 px so zooming does not redraw them on every frame.
                val trimW = (1f - trim[0] - trim[2]).coerceAtLeast(0.2f)
                val trimH = (1f - trim[1] - trim[3]).coerceAtLeast(0.2f)
                // The whole sheet is wider than what shows when margins are trimmed, so it is drawn that much wider.
                // While you pinch, the pages just stretch; they are drawn again at the new size once the zoom has been still a moment.
                var renderZoom by remember { mutableFloatStateOf(zoom) }
                LaunchedEffect(zoom) {
                    delay(200)
                    renderZoom = zoom
                }
                val needW = with(density) { (screenW * renderZoom).toPx() / trimW }.toInt() / 128 * 128
                val renderW = needW.coerceIn(256, MaxBase)
                val viewWpx = with(density) { maxWidth.toPx() }
                val dpx = density.density
                val viewWNow by androidx.compose.runtime.rememberUpdatedState(viewWpx)
                val hs = rememberScrollState()
                var pendX by remember { mutableFloatStateOf(0f) }
                var pendY by remember { mutableFloatStateOf(0f) }
                // Zooms about a point on the screen: the bit of page under it stays under it.
                fun zoomTo(target: Float, cx: Float, cy: Float) {
                    val z0 = zoom
                    val z1 = target.coerceIn(1f, 3.5f)
                    if (z1 == z0) return
                    val r = z1 / z0
                    pendX += (hs.value + cx) * (r - 1f)
                    pendY += (list.firstVisibleItemScrollOffset + cy) * (r - 1f)
                    zoom = z1
                }
                // Where the pages are, for turning a touch into a spot on a page (and back, to draw the selection).
                val pageWpx by androidx.compose.runtime.rememberUpdatedState(with(density) { pageW.toPx() })
                val leftPx by androidx.compose.runtime.rememberUpdatedState(with(density) { leftPad.toPx() })
                val grabPx = with(density) { 30.dp.toPx() }
                fun pageAt(p: androidx.compose.ui.geometry.Offset): Int? {
                    val info = list.layoutInfo
                    return info.visibleItemsInfo.firstOrNull {
                        val top = it.offset - info.viewportStartOffset
                        p.y >= top && p.y < top + it.size
                    }?.index
                }
                fun fractions(page: Int, p: androidx.compose.ui.geometry.Offset): Pair<Float, Float>? {
                    val info = list.layoutInfo
                    val item = info.visibleItemsInfo.firstOrNull { it.index == page } ?: return null
                    val top = item.offset - info.viewportStartOffset
                    // A spot on the screen, as a share of the whole sheet (what is trimmed off the edges counts too).
                    val fx = ((p.x + hs.value - leftPx) / pageWpx).coerceIn(0f, 1f)
                    val fy = ((p.y - top) / item.size.toFloat()).coerceIn(0f, 1f)
                    // Read the trim now, not when this function was made: the touch handlers keep the first copy of it.
                    val tw = (1f - trim[0] - trim[2]).coerceAtLeast(0.2f)
                    val th = (1f - trim[1] - trim[3]).coerceAtLeast(0.2f)
                    return (trim[0] + fx * tw) to (trim[1] + fy * th)
                }
                fun shownRect(): androidx.compose.ui.geometry.Rect? = sel?.let { selRect(it.norm(), list, hs.value, leftPx, pageWpx, trim) }
                // One band per printed line when the selection follows the page's words.
                fun shownLines(): List<androidx.compose.ui.geometry.Rect> {
                    val s = sel ?: return emptyList()
                    if (s.from < 0) return emptyList()
                    val pw = ptx.peek(s.page) ?: return emptyList()
                    return pw.lineRects(s.from, s.to).mapNotNull { q -> fracRect(s.page, q[0], q[1], q[2], q[3], trim, list, hs.value, leftPx, pageWpx) }
                }
                // 1 = the handle at the start of the selection, 2 = the one at its end, 0 = neither.
                fun handleAt(p: androidx.compose.ui.geometry.Offset): Int {
                    if (passage != null) return 0
                    val r = shownRect() ?: return 0
                    val ls = shownLines()
                    val a = if (ls.isEmpty()) r.topLeft else ls.first().topLeft
                    val b = if (ls.isEmpty()) r.bottomRight else ls.last().bottomRight
                    return when {
                        (p - a).getDistance() < grabPx -> 1
                        (p - b).getDistance() < grabPx -> 2
                        else -> 0
                    }
                }
                fun pinch(ev: androidx.compose.ui.input.pointer.PointerEvent) {
                    if (ev.changes.size > 1) {
                        val z = ev.calculateZoom()
                        if (z != 1f) {
                            val c = ev.calculateCentroid()
                            zoomTo(zoom * z, c.x, c.y)
                            ev.changes.forEach { it.consume() }
                        }
                    }
                }
                // A finger that picks out words: from a word-sized box where it went down to wherever it goes.
                suspend fun androidx.compose.ui.input.pointer.AwaitPointerEventScope.dragSelect(start: androidx.compose.ui.geometry.Offset) {
                    val page = pageAt(start) ?: return
                    val (ax, ay) = fractions(page, start) ?: return
                    // Snap to the page's words when they have been read; otherwise a word-sized box, and read them for next time.
                    val pw = ptx.peek(page)
                    val ai = pw?.nearest(ax, ay) ?: -1
                    val anchor = if (pw != null && ai >= 0) pw.selection(page, ai, ai) else wordAt(page, ax, ay)
                    if (pw == null) scope.launch { doc?.let { ptx.words(it, page) } }
                    haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                    selecting = true
                    armed = false
                    chrome = false
                    jump = false
                    sel = anchor
                    var lastPos = start
                    val follow = {
                        if ((lastPos - start).getDistance() > viewConfiguration.touchSlop) {
                            fractions(page, lastPos)?.let { (fx, fy) ->
                                if (pw != null && ai >= 0) {
                                    val j = pw.nearest(fx, fy, 0.5f)
                                    if (j >= 0) sel = pw.selection(page, ai, j)
                                } else {
                                    sel = spanTo(anchor, fx, fy)
                                }
                            }
                        }
                    }
                    dragHolder[0] = follow
                    val edge = 88.dp.toPx()
                    do {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        ev.changes.forEach { it.consume() }
                        val c = ev.changes.first()
                        if (c.pressed) {
                            lastPos = c.position
                            follow()
                            edgeDir = if (c.position.y < edge) -1 else if (c.position.y > size.height - edge) 1 else 0
                        }
                    } while (ev.changes.any { it.pressed })
                    edgeDir = 0
                    dragHolder[0] = null
                    selecting = false
                }
                // Double tap: zoom so the column of text under the finger fills the screen width, or back out.
                suspend fun smartZoom(p: androidx.compose.ui.geometry.Offset) {
                    val from = zoom
                    if (from > 1.2f) {
                        animate(from, 1f, animationSpec = glide(280)) { v, _ -> zoomTo(v, p.x, p.y) }
                        return
                    }
                    var to = 2.5f
                    var fx = p.x
                    val pg = pageAt(p)
                    val pw = pg?.let { ptx.peek(it) }
                    val fr = pg?.let { fractions(it, p) }
                    val b = if (pw != null && fr != null) columnBounds(pw, fr.first, fr.second) else null
                    if (b != null) {
                        val tw = (1f - trim[0] - trim[2]).coerceAtLeast(0.2f)
                        val blockFrac = ((b[1] - b[0]) / tw).coerceIn(0.2f, 1f)
                        val page1 = with(density) { screenW.toPx() }
                        to = (viewWNow * 0.94f / (blockFrac * page1)).coerceIn(1.3f, 3.5f)
                        // Keep the column centred: the point of the screen that stays put while zooming.
                        val x0 = leftPx - hs.value + (((b[0] + b[1]) / 2f - trim[0]) / tw) * pageWpx
                        val r = to / from
                        if (r > 1.01f) fx = ((viewWNow / 2f) - x0 * r) / (1f - r)
                    }
                    animate(from, to, animationSpec = glide(280)) { v, _ -> zoomTo(v, fx, p.y) }
                }
                // While a selection is dragged near the top or bottom of the screen, the page scrolls and the selection follows.
                LaunchedEffect(edgeDir) {
                    while (edgeDir != 0) {
                        list.scrollBy(edgeDir * 14f * dpx)
                        dragHolder[0]?.invoke()
                        withFrameNanos { }
                    }
                }
                // The pages only have their new size a frame after the zoom changes; then slide to keep the point put.
                LaunchedEffect(Unit) {
                    while (true) {
                        // Asleep until a zoom leaves something to correct (no frame is asked for in the meantime).
                        snapshotFlow { pendX != 0f || pendY != 0f }.first { it }
                        withFrameNanos { }
                        val dx = pendX
                        val dy = pendY
                        if (dx != 0f || dy != 0f) {
                            pendX -= dx
                            pendY -= dy
                            withFrameNanos { }
                            if (dx != 0f) hs.scrollTo((hs.value + dx).roundToInt().coerceAtLeast(0))
                            if (dy != 0f) list.scrollBy(dy)
                        }
                    }
                }
                Box(
                    Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            // Watch first, and only take the touch when it is ours: two fingers (zoom), a finger held still
                            // (select words), a selection handle, or select mode. Ordinary one-finger scrolling still works.
                            awaitEachGesture {
                                val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                                // A finger put down to stop a fling and left there is not a long press.
                                val stopping = list.isScrollInProgress
                                val grab = handleAt(down.position)
                                if (grab != 0) {
                                    // Drag a handle to grow or shrink the selection.
                                    down.consume()
                                    selecting = true
                                    val page = sel?.page ?: return@awaitEachGesture
                                    val hw = ptx.peek(page)
                                    var handlePos = down.position
                                    val follow = {
                                        val cur = sel
                                        if (cur != null) {
                                            fractions(page, handlePos)?.let { (fx, fy) ->
                                                if (cur.from >= 0 && hw != null) {
                                                    val i = hw.nearest(fx, fy, 0.5f)
                                                    if (i >= 0) sel = if (grab == 1) hw.selection(page, i, cur.to) else hw.selection(page, cur.from, i)
                                                } else {
                                                    sel = if (grab == 1) PageSel(page, fx, fy, cur.r, cur.b) else PageSel(page, cur.l, cur.t, fx, fy)
                                                }
                                            }
                                        }
                                    }
                                    dragHolder[0] = follow
                                    val edge = 88.dp.toPx()
                                    do {
                                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                                        ev.changes.forEach { it.consume() }
                                        val c = ev.changes.first()
                                        if (c.pressed) {
                                            handlePos = c.position
                                            follow()
                                            edgeDir = if (c.position.y < edge) -1 else if (c.position.y > size.height - edge) 1 else 0
                                        }
                                    } while (ev.changes.any { it.pressed })
                                    edgeDir = 0
                                    dragHolder[0] = null
                                    sel = sel?.norm()
                                    selecting = false
                                    return@awaitEachGesture
                                }
                                if (armed && passage == null) {
                                    down.consume()
                                    dragSelect(down.position)
                                    return@awaitEachGesture
                                }
                                // A vertical drag along the very left edge changes the brightness.
                                if (down.position.x < 24.dp.toPx() && sel == null && passage == null) {
                                    var started = false
                                    val startB = if (brightness < 0f) 0.5f else brightness
                                    var now = startB
                                    val y0 = down.position.y
                                    do {
                                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                                        val c = ev.changes.first()
                                        if (!started && c.pressed && kotlin.math.abs(c.position.y - y0) > viewConfiguration.touchSlop * 2f) started = true
                                        if (started) {
                                            ev.changes.forEach { it.consume() }
                                            now = (startB + (y0 - c.position.y) / (size.height * 0.6f)).coerceIn(0.02f, 1f)
                                            brightness = now
                                            brightHud = true
                                        }
                                    } while (ev.changes.any { it.pressed })
                                    if (started) {
                                        ReaderPrefs.setBrightness(prefsContext, now)
                                        brightHud = false
                                    }
                                    return@awaitEachGesture
                                }
                                // 0 still watching, 1 it moved or a second finger came (scroll or zoom), 2 it lifted (a tap).
                                val outcome = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                                    var o = 0
                                    while (o == 0) {
                                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                                        o = if (ev.changes.size > 1) {
                                            1
                                        } else {
                                            val c = ev.changes.first()
                                            if (!c.pressed) 2 else if ((c.position - down.position).getDistance() > viewConfiguration.touchSlop) 1 else 0
                                        }
                                    }
                                    o
                                }
                                when (outcome) {
                                    // Held still: pick out the word under the finger, then follow it.
                                    null -> if (!stopping && passage == null && !aiOpen && !making && !aiQuiz) dragSelect(down.position)
                                    1 -> do {
                                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                                        pinch(ev)
                                    } while (ev.changes.any { it.pressed })
                                    else -> Unit
                                }
                            }
                        }
                        .pointerInput(Unit) {
                            detectTapGestures(
                                // Double tap zooms in on that spot, or back out.
                                onDoubleTap = { p -> scope.launch { smartZoom(p) } },
                                onTap = { tp ->
                                    val hit = if (passage == null && sel == null) {
                                        markAt(tp, store.marks, bookId, list, hs.value, leftPx, pageWpx, trim, viewWNow, dpx)
                                    } else {
                                        null
                                    }
                                    when {
                                        passage != null -> passage = null
                                        sel != null -> sel = null
                                        hit != null -> { editing = hit.id; chrome = false }
                                        // On a tablet, a tap in the empty margin beside the page turns it (a screen at a time).
                                        wideScreen && zoom < 1.1f && (tp.x < leftPx || tp.x > leftPx + pageWpx) -> {
                                            val dist = list.layoutInfo.viewportSize.height * 0.88f
                                            scope.launch { list.animateScrollBy(if (tp.x > leftPx) dist else -dist, glide(320)) }
                                        }
                                        else -> chrome = !chrome
                                    }
                                },
                            )
                        }
                        // Swiping up and down in the blank margins beside the page scrolls it too (on a tablet they are wide).
                        .scrollable(list, androidx.compose.foundation.gestures.Orientation.Vertical)
                        .horizontalScroll(hs),
                ) {
                    LazyColumn(
                        state = list,
                        modifier = Modifier.padding(start = leftPad).width(pageW),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(top = topPad + 64.dp, bottom = 140.dp),
                    ) {
                        items(d.pageCount) { index ->
                            PageView(d, index, renderW, needW, tone, trim)
                        }
                    }
                }
                // The selection, drawn over the page it is on (it follows the page as you scroll), and its bar.
                MarksLayer(
                    marks = store.marks,
                    bookId = bookId,
                    hits = if (searchActive) hits else emptyList(),
                    active = hitIdx,
                    list = list,
                    scrollX = { hs.value },
                    left = { leftPx },
                    pageW = { pageWpx },
                    trim = { trim },
                    modifier = Modifier.fillMaxSize(),
                )
                if (sel != null) {
                    SelectionOverlay(rect = { shownRect() }, lines = { shownLines() }, showHandles = !selecting && passage == null)
                }
                androidx.compose.animation.AnimatedVisibility(
                    visible = sel != null && !selecting && passage == null,
                    enter = androidx.compose.animation.scaleIn(spring(dampingRatio = 0.7f, stiffness = 500f), initialScale = 0.6f),
                    exit = androidx.compose.animation.scaleOut(glide(140), targetScale = 0.6f),
                ) {
                    SelectionBar(
                        rect = { shownRect() },
                        preparing = preparing,
                        onExplain = { openPassage(false) },
                        onAsk = { openPassage(true) },
                        single = sel?.let { it.from >= 0 && it.from == it.to } == true,
                        onDefine = { openPassage(true, "What does this word mean here? Define it in simple words and give one short example.") },
                        lastColor = markColor,
                        onCopy = { copySelection() },
                        onHighlight = { c, withNote -> highlightSelection(c, withNote) },
                        onClear = { sel = null },
                        topLimit = with(density) { (topPad + 8.dp).toPx() },
                    )
                }
            }
        }

        // Top bar. Its fade takes the paper colour, so it blends into the page instead of a black smear.
        val fade = when (tone) { 1 -> Color.Black; 2 -> Color(0xFFF4EBD6); else -> Color.White }
        val titleColor = if (tone == 1) Color(0xFFF2F2F2) else Color(0xFF1C1A16)
        AnimatedVisibility(
            visible = chrome || doc == null,
            enter = slideInVertically(glide(240)) { -it },
            exit = slideOutVertically(glide(220)) { -it },
        ) {
        // A solid bar in the paper's colour with a hairline under it: nothing from the page shows through the title.
        Column(Modifier.fillMaxWidth().background(fade)) {
        // On a tablet the bar's contents stay as wide as the page instead of running from one edge of the screen to the other.
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
        Row(
            Modifier
                .widthIn(max = 820.dp)
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = topPad, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BackButton(onBack, container = RC.Slate, arrow = RC.Snow)
            Text(
                book?.title ?: "",
                style = RT.Label.copy(color = titleColor, fontSize = 16.sp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f).padding(start = 14.dp),
            )
            val marked = store.isBookmarked(bookId, page)
            TopIcon(Glyph.Search, RC.Silver, "Search this book") { sel = null; panel = 3; chrome = false }
            TopIcon(Glyph.Bookmark, if (marked) RC.Lime else RC.Silver, if (marked) "Remove bookmark" else "Bookmark this page") {
                store.toggleBookmark(bookId, page)
                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
            }
        }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(if (tone == 1) Color(0x33FFFFFF) else Color(0x1F000000)))
        }
        }

        // The page number, while you scroll and the bars are away.
        AnimatedVisibility(
            visible = chip && !chrome && !jump && doc != null,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = topPad),
            enter = slideInVertically(glide(200)) { -it * 2 },
            exit = slideOutVertically(glide(200)) { -it * 2 },
        ) {
            Text(
                "${page + 1} / ${book?.pages ?: 0}",
                style = RT.Label.copy(color = RC.Snow, fontSize = 13.sp),
                modifier = Modifier
                    .clip(CircleShape)
                    .background(RC.Slate)
                    .border(1.dp, RC.Graphite, CircleShape)
                    .padding(horizontal = 14.dp, vertical = 7.dp),
            )
        }

        // Left-edge brightness drag, and Undo after a highlight or a delete.
        AnimatedVisibility(
            visible = brightHud,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = topPad + 70.dp),
            enter = slideInVertically(glide(180)) { -it * 2 },
            exit = slideOutVertically(glide(180)) { -it * 2 },
        ) { BrightnessHud(if (brightness < 0f) 0.5f else brightness) }
        AnimatedVisibility(
            visible = undo != null && panel == 0 && editing == null && !notebook,
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 96.dp),
            enter = slideInVertically(glide(240)) { it * 2 },
            exit = slideOutVertically(glide(200)) { it * 2 },
        ) {
            var shown by remember { mutableStateOf<MarkUndo?>(null) }
            LaunchedEffect(undo) { if (undo != null) shown = undo }
            val u = undo ?: shown
            if (u != null) {
                UndoPill(u.text, onUndo = {
                    if (u.wasAdded) store.removeMark(u.mark.id) else store.restoreMark(u.mark)
                    undo = null
                })
            }
        }

        // The page slider's thumb while it is held (the preview above it follows it).
        var scrub by remember { mutableStateOf<Float?>(null) }
        // Bottom bar
        if (doc != null && book != null) {
            AnimatedVisibility(
                visible = (chrome || jump) && sel == null && !armed && panel == 0 && editing == null && !notebook,
                modifier = Modifier.align(Alignment.BottomCenter),
                enter = slideInVertically(glide(240)) { it },
                exit = slideOutVertically(glide(220)) { it },
            ) {
            // On a tablet the bar is a compact pill in the middle, not a strip across the whole screen.
            Column(
                Modifier.widthIn(max = 560.dp).fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp),
            ) {
                AnimatedVisibility(
                    visible = jump && scrub != null,
                    enter = slideInVertically(glide(180)) { it },
                    exit = slideOutVertically(glide(160)) { it },
                ) {
                    val sp = (scrub?.toInt() ?: page).coerceIn(0, last)
                    ScrubPreview(sp, book.pages, sp.toFloat() / last.coerceAtLeast(1), doc!!, tone, Modifier.padding(bottom = 8.dp))
                }
                AnimatedVisibility(
                    visible = jump,
                    enter = slideInVertically(glide(260)) { it },
                    exit = slideOutVertically(glide(220)) { it },
                ) {
                    val shape = RoundedCornerShape(24.dp)
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                            .clip(shape)
                            .background(RC.Slate)
                            .border(1.dp, RC.Graphite, shape)
                            .padding(horizontal = 18.dp, vertical = 10.dp),
                    ) {
                        // While the thumb is held it follows the finger, not the list (the list catches up a frame or more
                        // later, and a slider that reads it back snaps to the old page when the finger lets go).
                        val left = remember(page, store.reads.size) { readingLeft(store, bookId, last - page) }
                        Text(
                            "Page ${(scrub?.toInt() ?: page) + 1} of ${book.pages}" + (left?.let { " · $it" } ?: ""),
                            style = RT.Small.copy(color = RC.Silver),
                        )
                        Slider(
                            value = scrub ?: page.toFloat(),
                            onValueChange = { v ->
                                val target = v.toInt().coerceIn(0, last)
                                // A small tick under the finger for each page it passes.
                                if (target != (scrub?.toInt() ?: page)) haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                                scrub = v
                                // Asks for the jump on the next layout, so many moves in a row don't pile up.
                                if (target != list.firstVisibleItemIndex) list.requestScrollToItem(target)
                            },
                            onValueChangeFinished = { scrub = null },
                            modifier = Modifier.semantics {
                                contentDescription = "Page"
                                stateDescription = "Page ${(scrub?.toInt() ?: page) + 1} of ${book.pages}"
                            },
                            valueRange = 0f..last.coerceAtLeast(1).toFloat(),
                            colors = SliderDefaults.colors(
                                thumbColor = RC.Lime,
                                activeTrackColor = RC.Lime,
                                inactiveTrackColor = RC.Graphite,
                            ),
                        )
                        // Under the slider: what you have read (lit), bookmarks (lines) and highlights or notes (dots).
                        JumpMarks(store, book)
                    }
                }
                val bar = RoundedCornerShape(32.dp)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .clip(bar)
                        .background(RC.Slate)
                        .border(1.dp, RC.Graphite, bar)
                        .padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier
                            .height(44.dp)
                            .clip(CircleShape)
                            .clickable(role = Role.Button) { jump = !jump }
                            .padding(horizontal = 16.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("${page + 1} / ${book.pages}", style = RT.Label.copy(color = RC.Snow, fontSize = 15.sp))
                    }
                    Spacer(Modifier.weight(1f))
                    val compact = context.resources.configuration.screenWidthDp < 400
                    if (context.resources.configuration.screenWidthDp >= 600) {
                        BarButton("Select", Glyph.Select, onClick = { sel = null; armed = true; jump = false; chrome = false }, showLabel = true)
                    }
                    BarButton("AI", Glyph.Target, onClick = { aiPage = page; aiOpen = true }, showLabel = !compact)
                    BarButton("Display", Glyph.Display, onClick = { sel = null; panel = 1; jump = false }, showLabel = false)
                    BarButton("Card", Glyph.Cards, onClick = { making = true }, accent = true)
                    BarButton("More", Glyph.More, onClick = { panel = 2; jump = false }, showLabel = false)
                }
            }
            }
        }

        // Select mode: what to do now, and a way out. And, once, a tip that long-pressing explains.
        AnimatedVisibility(
            visible = armed,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = topPad + 8.dp),
            enter = slideInVertically(glide(240)) { -it * 2 },
            exit = slideOutVertically(glide(200)) { -it * 2 },
        ) {
            SelectHint("Drag over a word or sentence", onCancel = { armed = false })
        }
        AnimatedVisibility(
            visible = showTip && doc != null && chrome && !armed && sel == null && passage == null && !aiOpen && !making,
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(start = 16.dp, end = 16.dp, bottom = 92.dp),
            enter = slideInVertically(glide(300)) { it * 2 },
            exit = slideOutVertically(glide(220)) { it * 2 },
        ) {
            val shape = RoundedCornerShape(22.dp)
            Row(
                Modifier
                    .widthIn(max = 520.dp)
                    .clip(shape)
                    .background(RC.Slate)
                    .border(1.dp, RC.Lime.copy(alpha = 0.5f), shape)
                    .padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                GlyphIcon(Glyph.Select, RC.Lime, boxSize = 22.dp)
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text("New: explain any part", style = RT.Label.copy(color = RC.Snow, fontSize = 14.sp))
                    Text("Press and hold a word, then drag over a sentence. AI explains it as this book uses it.", style = RT.Small.copy(color = RC.Mist))
                }
                Text(
                    "Got it",
                    style = RT.Label.copy(color = RC.Lime, fontSize = 14.sp),
                    modifier = Modifier.clip(CircleShape).clickable(role = Role.Button) { showTip = false; ReaderTips.markSeen(context) }.padding(horizontal = 12.dp, vertical = 10.dp),
                )
            }
        }

        // The explanation of a selection: up from the bottom on a phone, a panel down the right on a wide screen.
        val wideReader = com.godbless.lockin.ui.isWide()
        AnimatedVisibility(
            visible = passage != null,
            modifier = Modifier.align(if (wideReader) Alignment.CenterEnd else Alignment.BottomCenter),
            enter = if (wideReader) androidx.compose.animation.slideInHorizontally(glide(320)) { it } else slideInVertically(glide(320)) { it },
            exit = if (wideReader) androidx.compose.animation.slideOutHorizontally(glide(260)) { it } else slideOutVertically(glide(260)) { it },
        ) {
            // Keeps showing the last one while it slides away.
            var shown by remember { mutableStateOf<PassageArgs?>(null) }
            LaunchedEffect(passage) { if (passage != null) shown = passage }
            val a = passage ?: shown
            if (a != null) {
                PassageSheet(
                    store = store,
                    bookId = bookId,
                    args = a,
                    wide = wideReader,
                    onClose = { passage = null; sel = null },
                    onQuiz = { ask -> quizAsk = ask; passage = null; sel = null; aiQuiz = true },
                )
            }
        }

        // The page dims behind the sheets, and a tap on the dim closes them.
        val dim by animateFloatAsState(
            if (aiOpen || making || panel == 1 || panel == 2 || editing != null) 1f else 0f,
            glide(260),
            label = "dim",
        )
        if (dim > 0.01f) {
            val pulled = if (aiOpen) (aiDrag.value / 900f).coerceIn(0f, 1f) else 0f
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.55f * dim * (1f - pulled)))
                    .pointerInput(Unit) {
                        detectTapGestures {
                            when {
                                editing != null -> editing = null
                                panel != 0 -> panel = 0
                                aiOpen -> aiOpen = false
                                else -> making = false
                            }
                        }
                    },
            )
        }

        // Display settings, the "more" menu, search, and a highlight's editor, up from the bottom.
        AnimatedVisibility(
            visible = panel == 1,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(glide(300)) { it },
            exit = slideOutVertically(glide(240)) { it },
        ) {
            DisplaySheet(
                tone = tone,
                onTone = { tone = it; ReaderPrefs.setTone(prefsContext, it) },
                autoTone = autoTone,
                onAutoTone = { autoTone = it; ReaderPrefs.setAutoTone(prefsContext, it) },
                brightness = brightness,
                onBrightness = { brightness = it; ReaderPrefs.setBrightness(prefsContext, it) },
                keepAwake = keepAwake,
                onKeepAwake = { keepAwake = it; ReaderPrefs.setKeepAwake(prefsContext, it) },
                trim = trim,
                onTrimOff = { setTrim(NoTrim.copyOf()) },
                onTrimAuto = {
                    val dd = doc
                    if (dd != null && !detecting) {
                        scope.launch {
                            detecting = true
                            val t = runCatching { detectTrim(dd) }.getOrNull()
                            detecting = false
                            if (t != null) setTrim(t)
                        }
                    }
                },
                onTrimAmount = { v -> setTrim(floatArrayOf(v, v, v, v)) },
                detecting = detecting,
                onClose = { panel = 0 },
            )
        }
        AnimatedVisibility(
            visible = panel == 2,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(glide(300)) { it },
            exit = slideOutVertically(glide(240)) { it },
        ) {
            ReaderMoreSheet(
                marksHere = store.marks.count { it.book == bookId },
                onSelect = { panel = 0; sel = null; armed = true; jump = false; chrome = false },
                onNotebook = { panel = 0; notebook = true },
                onNote = {
                    panel = 0
                    val existing = store.marks.firstOrNull { it.book == bookId && it.page == page && it.kind == MarkKind.Note }
                    editing = (existing ?: store.addPageNote(bookId, page)).id
                },
                onShare = {
                    panel = 0
                    if (store.marks.none { it.book == bookId }) {
                        android.widget.Toast.makeText(context, "Nothing in the notebook yet", android.widget.Toast.LENGTH_SHORT).show()
                    } else {
                        val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(android.content.Intent.EXTRA_SUBJECT, "Notes: ${book?.title ?: "Notebook"}")
                            putExtra(android.content.Intent.EXTRA_TEXT, store.notebookMarkdown(bookId))
                        }
                        runCatching { context.startActivity(android.content.Intent.createChooser(send, "Share notebook")) }
                    }
                },
                onClose = { panel = 0 },
            )
        }
        AnimatedVisibility(
            visible = panel == 3,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(glide(300)) { it },
            exit = slideOutVertically(glide(240)) { it },
        ) {
            SearchSheet(
                query = query,
                onQuery = { query = it; hitIdx = 0 },
                hits = hits,
                read = ptx.count,
                total = book?.pages ?: 0,
                indexing = ptx.indexing,
                onPick = { i -> panel = 0; searching = true; goToHit(i) },
                onClose = { panel = 0; if (hits.isEmpty()) { searching = false; query = "" } else searching = true },
            )
        }
        // Once the list is closed, step through the matches from a small bar.
        AnimatedVisibility(
            visible = searching && panel == 0 && hits.isNotEmpty() && sel == null && editing == null && !notebook,
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 18.dp),
            enter = slideInVertically(glide(260)) { it * 2 },
            exit = slideOutVertically(glide(220)) { it * 2 },
        ) {
            SearchPill(
                index = hitIdx.coerceIn(0, (hits.size - 1).coerceAtLeast(0)),
                total = hits.size,
                onPrev = { goToHit(if (hitIdx <= 0) hits.size - 1 else hitIdx - 1) },
                onNext = { goToHit(if (hitIdx >= hits.size - 1) 0 else hitIdx + 1) },
                onList = { panel = 3 },
                onClose = { searching = false; query = ""; hits = emptyList() },
            )
        }
        AnimatedVisibility(
            visible = editing != null,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(glide(300)) { it },
            exit = slideOutVertically(glide(240)) { it },
        ) {
            // Keeps the last one while it slides away.
            var shownMark by remember { mutableStateOf<String?>(null) }
            LaunchedEffect(editing) { if (editing != null) shownMark = editing }
            val markId = editing ?: shownMark
            if (markId != null) {
                MarkEditor(
                    store = store,
                    markId = markId,
                    onClose = { editing = null },
                    onDeleted = { m -> undo = MarkUndo("Deleted", m, false) },
                )
            }
        }
        // The notebook for this book, over the reader.
        // On a tablet it sits beside the page (the page moves over) and stays open while you jump around in it.
        val sideNotebook = context.resources.configuration.screenWidthDp >= 600
        AnimatedVisibility(
            visible = notebook,
            modifier = if (sideNotebook) Modifier.align(Alignment.CenterEnd).width(440.dp).fillMaxHeight() else Modifier,
            enter = if (sideNotebook) androidx.compose.animation.slideInHorizontally(glide(320)) { it } else slideInVertically(glide(320)) { it },
            exit = if (sideNotebook) androidx.compose.animation.slideOutHorizontally(glide(260)) { it } else slideOutVertically(glide(280)) { it },
        ) {
            NotebookScreen(
                store = store,
                onlyBook = bookId,
                onBack = { notebook = false },
                onOpen = { _, p ->
                    if (!sideNotebook) notebook = false
                    scope.launch { list.scrollToItem(p.coerceIn(0, last)) }
                },
            )
        }

        // The AI sheet slides up over the page: explain it, make cards, or quiz on what you read.
        AnimatedVisibility(
            visible = aiOpen,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(glide(320)) { it },
            exit = slideOutVertically(glide(280)) { it },
        ) {
            ReaderAiSheet(
                store = store,
                bookId = bookId,
                page = aiPage,
                drag = aiDrag,
                onQuiz = { aiOpen = false; quizAsk = null; aiQuiz = true },
                onClose = { aiOpen = false },
                onGoToPage = { p -> scope.launch { list.scrollToItem(p.coerceIn(0, last)) } },
                onSelect = { aiOpen = false; sel = null; armed = true; chrome = false },
            )
        }
        // The quiz on what you read in this book (this page included), over the reader.
        AnimatedVisibility(
            visible = aiQuiz,
            enter = slideInVertically(glide(320)) { it },
            exit = slideOutVertically(glide(280)) { it },
        ) {
            // Asked for in words about "this" (no topic, not "the chapter"): just the page they were on. Otherwise the pages read.
            val ask = quizAsk
            val onePage = ask != null && !ask.wide && ask.focus.isEmpty()
            val source = remember(ask) {
                val read = store.reads.filter { it.book == bookId }.map { it.page }
                (if (onePage) listOf(ask?.page ?: page) else (read + (ask?.page ?: page)).distinct().takeLast(12)).map { bookId to it }
            }
            AiQuizScreen(
                store = store,
                source = source,
                title = when {
                    ask != null && ask.focus.isNotEmpty() -> "On ${ask.focus}"
                    onePage -> "On page ${(ask?.page ?: page) + 1} of ${book?.title ?: "this book"}"
                    else -> "On ${source.size} pages you read in ${book?.title ?: "this book"}"
                },
                onBack = { aiQuiz = false },
                onOpenPage = { _, p -> aiQuiz = false; scope.launch { list.scrollToItem(p.coerceIn(0, last)) } },
                focus = ask?.focus.orEmpty(),
                count = ask?.count,
                difficulty = ask?.difficulty.orEmpty(),
            )
        }

        // Card editor slides up over the page you are reading.
        AnimatedVisibility(
            visible = making,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(glide(320)) { it },
            exit = slideOutVertically(glide(280)) { it },
        ) {
            CardEditor(
                store = store,
                startBook = bookId,
                startPage = page + 1,
                onClose = { making = false },
            )
        }
    }
    }
}

@Composable
private fun BarButton(label: String, glyph: Glyph, onClick: () -> Unit, accent: Boolean = false, showLabel: Boolean = true) {
    Row(
        Modifier
            .height(44.dp)
            .clip(CircleShape)
            .background(if (accent) RC.Lime else RC.Slate)
            .semantics { contentDescription = label }
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = if (showLabel) 14.dp else 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        GlyphIcon(glyph, if (accent) RC.OnLime else RC.Silver, boxSize = 18.dp)
        if (showLabel) {
            Text(
                label,
                style = RT.Label.copy(color = if (accent) RC.OnLime else RC.Snow, fontSize = 13.sp),
                maxLines = 1,
                softWrap = false,
                modifier = Modifier.padding(start = 6.dp),
            )
        }
    }
}

/** A round button in the top bar. */
@Composable
private fun TopIcon(glyph: Glyph, tint: Color, description: String, onClick: () -> Unit) {
    Box(
        Modifier
            .padding(start = 6.dp)
            .size(44.dp)
            .clip(CircleShape)
            .background(RC.Slate)
            .border(1.dp, RC.Graphite, CircleShape)
            .semantics { contentDescription = description }
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { GlyphIcon(glyph, tint, boxSize = 20.dp) }
}

@Composable
private fun Message(text: String, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(text, style = RT.Sub.copy(color = RC.Snow))
        Spacer(Modifier.height(16.dp))
        Box(
            Modifier.height(44.dp).clip(CircleShape).border(1.5.dp, RC.Rim, CircleShape).clickable(role = Role.Button, onClick = onBack).padding(horizontal = 20.dp),
            contentAlignment = Alignment.Center,
        ) { Text("Back", style = RT.Label.copy(color = RC.Snow)) }
    }
}

/** A highlight or note just added or deleted, so Undo can reverse it for a few seconds. */
private class MarkUndo(val text: String, val mark: Mark, val wasAdded: Boolean)

/** The part of a page drawn on its own, sharp, and where it sits on the page (fractions of the whole page). */
private class Tile(val bmp: Bitmap, val l: Float, val t: Float, val r: Float, val b: Float)

/** Which piece of the page is on screen, in 32nds of the whole page: it only changes when you move a good way. */
private data class TileCell(val l: Int, val t: Int, val r: Int, val b: Int)

/**
 * One page. It keeps showing the last drawing (a little soft) while a sharper one is made after a zoom. [trim] is what is
 * cut off the edges. When zoomed in beyond what a whole page can be drawn at ([needW] wider than [MaxBase]), the part on
 * screen is also drawn on its own at full sharpness and laid over the page.
 */
@Composable
private fun PageView(doc: PdfDoc, index: Int, renderW: Int, needW: Int, tone: Int, trim: FloatArray) {
    var bitmap by remember(doc, index) { mutableStateOf(doc.peek(index, renderW)) }
    LaunchedEffect(doc, index, renderW) {
        val b = doc.bitmap(index, renderW)
        if (b != null) bitmap = b
    }
    val b = bitmap
    val sw = (1f - trim[0] - trim[2]).coerceAtLeast(0.2f)
    val sh = (1f - trim[1] - trim[3]).coerceAtLeast(0.2f)
    val full = if (b != null) b.height.toFloat() / b.width else doc.ratio(index)
    val ratio = full * sh / sw
    val image = remember(b) { b?.asImageBitmap() }
    val filter = when (tone) { 1 -> DarkFilter; 2 -> SepiaFilter; else -> null }

    val tiled = needW > MaxBase
    val view = androidx.compose.ui.platform.LocalView.current
    var cell by remember(index) { mutableStateOf<TileCell?>(null) }
    var tile by remember(doc, index) { mutableStateOf<Tile?>(null) }
    LaunchedEffect(doc, index, cell, needW, tiled) {
        val c = cell
        if (!tiled || c == null) {
            tile = null
            return@LaunchedEffect
        }
        delay(140)
        val l = c.l / 32f; val t = c.t / 32f; val r = c.r / 32f; val bt = c.b / 32f
        // Keep the piece within 4096 px each way, so it is never squeezed (it is just a little less sharp then).
        val spanW = (r - l).coerceAtLeast(0.03f)
        val spanH = ((bt - t) * full).coerceAtLeast(0.03f)
        var fullW = minOf(needW, 9000, (4096f / spanW).toInt(), (4096f / spanH).toInt())
        // And no more than about 6 million pixels (24 MB) for one piece, so zooming doesn't churn memory.
        val px = spanW.toDouble() * fullW * spanH * fullW
        if (px > 6_000_000.0) fullW = (fullW * Math.sqrt(6_000_000.0 / px)).toInt().coerceAtLeast(256)
        val bmp = doc.tile(index, fullW, l, t, r, bt)
        if (bmp != null) tile = Tile(bmp, l, t, r, bt)
    }
    val timage = remember(tile) { tile?.bmp?.asImageBitmap() }

    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(1f / ratio)
            .clipToBounds()
            .background(if (tone == 1) Color.Black else if (tone == 2) Color(0xFFF4EBD6) else Color.White)
            .onGloballyPositioned { co ->
                if (!tiled) return@onGloballyPositioned
                val w = co.size.width.toFloat()
                val h = co.size.height.toFloat()
                if (w <= 0f || h <= 0f) return@onGloballyPositioned
                val pos = co.positionInWindow()
                val x0 = ((0f - pos.x) / w).coerceIn(0f, 1f)
                val x1 = ((view.width - pos.x) / w).coerceIn(0f, 1f)
                val y0 = ((0f - pos.y) / h).coerceIn(0f, 1f)
                val y1 = ((view.height - pos.y) / h).coerceIn(0f, 1f)
                if (x1 - x0 < 0.01f || y1 - y0 < 0.01f) return@onGloballyPositioned
                // The piece already made still covers what is on screen: keep it (no new piece for every little scroll).
                val cur = cell
                if (cur != null) {
                    val vl = trim[0] + x0 * sw; val vr = trim[0] + x1 * sw
                    val vt = trim[1] + y0 * sh; val vb = trim[1] + y1 * sh
                    if (vl >= cur.l / 32f - 0.002f && vr <= cur.r / 32f + 0.002f && vt >= cur.t / 32f - 0.002f && vb <= cur.b / 32f + 0.002f) {
                        return@onGloballyPositioned
                    }
                }
                // Otherwise a good deal more on each side, so the next stretch of scrolling doesn't need another, then onto the 32nds grid.
                val px = (x1 - x0) * 0.4f
                val py = (y1 - y0) * 0.4f
                val fl = trim[0] + (x0 - px).coerceAtLeast(0f) * sw
                val fr = trim[0] + (x1 + px).coerceAtMost(1f) * sw
                val ft = trim[1] + (y0 - py).coerceAtLeast(0f) * sh
                val fb = trim[1] + (y1 + py).coerceAtMost(1f) * sh
                val next = TileCell(
                    kotlin.math.floor(fl * 32f).toInt().coerceIn(0, 31),
                    kotlin.math.floor(ft * 32f).toInt().coerceIn(0, 31),
                    kotlin.math.ceil(fr * 32f).toInt().coerceIn(1, 32),
                    kotlin.math.ceil(fb * 32f).toInt().coerceIn(1, 32),
                )
                if (next != cell) cell = next
            },
    ) {
        Canvas(Modifier.fillMaxSize().semantics { contentDescription = "Page ${index + 1}" }) {
            val dw = size.width.roundToInt().coerceAtLeast(1)
            val dh = size.height.roundToInt().coerceAtLeast(1)
            if (image != null && b != null) {
                drawImage(
                    image,
                    srcOffset = IntOffset((trim[0] * b.width).roundToInt(), (trim[1] * b.height).roundToInt()),
                    srcSize = IntSize((sw * b.width).roundToInt().coerceAtLeast(1), (sh * b.height).roundToInt().coerceAtLeast(1)),
                    dstSize = IntSize(dw, dh),
                    colorFilter = filter,
                    filterQuality = FilterQuality.Low,
                )
            }
            val tl = tile
            if (tl != null && timage != null && tiled) {
                val x0 = ((tl.l - trim[0]) / sw * size.width).roundToInt()
                val y0 = ((tl.t - trim[1]) / sh * size.height).roundToInt()
                val x1 = ((tl.r - trim[0]) / sw * size.width).roundToInt()
                val y1 = ((tl.b - trim[1]) / sh * size.height).roundToInt()
                if (x1 > x0 && y1 > y0) {
                    drawImage(
                        timage,
                        dstOffset = IntOffset(x0, y0),
                        dstSize = IntSize(x1 - x0, y1 - y0),
                        colorFilter = filter,
                        filterQuality = FilterQuality.Low,
                    )
                }
            }
        }
    }
}
