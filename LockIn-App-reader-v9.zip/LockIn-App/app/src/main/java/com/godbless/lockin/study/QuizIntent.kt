package com.godbless.lockin.study

/*
 * Typing "quiz me on photosynthesis, 5 hard questions" in the reader's ask box should open the app's own quiz, not get a
 * list of questions written out as text. This reads such a message: is it a request to be quizzed, and for what.
 * Pure Kotlin (no Android): see QuizIntentTest. The patterns are one per line on purpose, so a test can read them.
 */

/**
 * What a typed quiz request asks for. [count] is how many questions when the student said (3 to 10), [focus] a topic they
 * named ("" means what they selected or read), [difficulty] "easy", "hard" or "" for a mix, [wide] true when they meant
 * more than this page ("the chapter", "everything I've read"). [page] (0-based) is where they were reading.
 */
internal data class QuizAsk(
    val count: Int? = null,
    val focus: String = "",
    val difficulty: String = "",
    val wide: Boolean = false,
    val page: Int? = null,
)

internal object QuizIntent {
    // Is it a request for a quiz at all?
    private val ABOUT = Regex("""^\W*(?:(?:what|why|who|when|where|how)\s+(?:is|are|was|were|does|do|did|can|could|would|should|to)\b|explain\b|define\b|describe\b|tell me about\b)""", RegexOption.IGNORE_CASE)
    private val ME = Regex("""\b(?:quiz|test|exam|examine|drill|grill)\s+(?:me|us)\b""", RegexOption.IGNORE_CASE)
    private val OFFER = Regex("""\b(?:how|what)\s+about\s+(?:a\s+|an\s+)?(?:quick\s+)?(?:quiz|test)\b""", RegexOption.IGNORE_CASE)
    private val KNOW = Regex("""\b(?:check|test|assess|try)\s+(?:my|our)\s+(?:knowledge|understanding|learning|memory|skills)\b""", RegexOption.IGNORE_CASE)
    private val MAKE = Regex("""\b(?:make|create|generate|write|give|build|set|prepare|do|start|run|need|want|get)\b[^.?!]{0,40}?\b(?:quiz(?:zes)?|mcqs?|multiple[- ]choice|practice\s+(?:test|quiz)|(?:a|an|the)\s+(?:\w+\s+){0,2}(?:test|exam))\b""", RegexOption.IGNORE_CASE)
    private val QS = Regex("""\b(?:give|make|create|generate|write|set|ask|prepare)\b\s+(?:me\s+|us\s+)?(?:(?:\d+|one|two|three|four|five|six|seven|eight|nine|ten|a\s+few|some|several|more|few|another|new|different|hard|harder|easy|easier|tricky|tough|practice|quick|short|mcq|multiple[- ]choice)\s+){0,4}(?:questions|mcqs?)\b""", RegexOption.IGNORE_CASE)
    private val BARE = Regex("""^\W*(?:a\s+|an\s+|the\s+)?(?:(?:quick|short|hard|easy|pop|practice|multiple[- ]choice)\s+)*(?:quiz|mcqs?|practice\s+(?:test|questions?)|multiple[- ]choice(?:\s+questions?)?)(?:\s+(?:please|pls))?\W*$""", RegexOption.IGNORE_CASE)

    // How many, how hard, how wide, on what.
    private val COUNT = Regex("""\b(\d{1,2}|one|two|three|four|five|six|seven|eight|nine|ten)[\s-]+(?:multiple[- ]choice\s+|practice\s+|quick\s+|short\s+|mcq\s+)*(?:questions?|mcqs?|problems?)\b""", RegexOption.IGNORE_CASE)
    private val EASY_NOT_HARD = Regex("""\b(?:not|isn'?t|nothing|no)\s+(?:too\s+|very\s+|that\s+|so\s+)?(?:hard|difficult|tough)\b""", RegexOption.IGNORE_CASE)
    private val HARD = Regex("""\b(?:hard|harder|difficult|challenging|tough)\s+(?:\w+\s+)?(?:quiz|test|questions?|mcqs?|problems?)\b|\bmake\s+(?:it|them)\s+(?:a\s+bit\s+|a\s+little\s+)?(?:hard|harder|tougher|difficult)\b|\b(?:quiz|questions?)\s+(?:that\s+(?:is|are)\s+)?(?:hard|harder|difficult)\b""", RegexOption.IGNORE_CASE)
    private val EASY = Regex("""\b(?:easy|easier|beginner|beginners)\s+(?:\w+\s+)?(?:quiz|test|questions?|mcqs?|problems?)\b|\bmake\s+(?:it|them)\s+(?:a\s+bit\s+|a\s+little\s+)?(?:easy|easier)\b|\b(?:quiz|questions?)\s+(?:that\s+(?:is|are)\s+)?(?:easy|easier)\b""", RegexOption.IGNORE_CASE)
    private val WIDE = Regex("""\b(?:chapter|whole book|entire book|the book|everything|all i(?:'ve| have)?\s+(?:read|covered)|what i(?:'ve| have)?\s+(?:read|covered)|so far|pages i(?:'ve| have)?\s+read|all the pages|these pages)\b""", RegexOption.IGNORE_CASE)
    private val TOPIC = Regex("""\b(?:on|about|covering|regarding)\s+(.+)$""", RegexOption.IGNORE_CASE)
    private val TOPIC_END = Regex("""\s*[,.;!?]|\s+(?:please|pls|thanks|thank you)\b|\s+with\s+\d|\s+(?:in|using|as)\s+(?:mcq|multiple)|\s+(?:and|but)\s+(?:make|give|use)\b""", RegexOption.IGNORE_CASE)
    private val TOPIC_LEAD = Regex("""^(?:the\s+)?(?:topic\s+of\s+|topic\s+|subject\s+of\s+)""", RegexOption.IGNORE_CASE)
    private val HERE = Regex("""^(?:this|that|it|these|those|here|(?:the|this|that)\s+(?:page|selection|selected\s+(?:part|text)|passage|paragraph|text|section|part|bit|equation|formula)|what\s+i\s+(?:selected|highlighted|read|just\s+read)|what\s+i(?:'ve| have)\s+(?:read|selected))\W*$""", RegexOption.IGNORE_CASE)
    private val BROAD = Regex("""^(?:the\s+|this\s+|my\s+)?(?:(?:chapter|unit|section)(?:\s+\w+)?|book|whole\s+book|entire\s+book|everything(?:\s+.*)?|pages?(?:\s+i.*)?|all\s+.*|what\s+i.*)\W*$""", RegexOption.IGNORE_CASE)

    private val SPACES = Regex("""\s+""")
    private val WORDS = mapOf("one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6, "seven" to 7, "eight" to 8, "nine" to 9, "ten" to 10)

    /** The request in [text], or null when it is an ordinary question (which goes to the AI as before). */
    fun parse(text: String): QuizAsk? {
        val t = SPACES.replace(text, " ").trim()
        if (t.length < 3 || t.length > 240) return null
        val named = ME.containsMatchIn(t)
        // "What is a quiz?", "how do I make a test": about quizzes, not a request for one.
        if (!named && ABOUT.containsMatchIn(t)) return null
        if (!(named || OFFER.containsMatchIn(t) || KNOW.containsMatchIn(t) || QS.containsMatchIn(t) || MAKE.containsMatchIn(t) || BARE.containsMatchIn(t))) return null
        val ask = lenient(t)
        // One question is not a quiz: that is the ordinary answer (or the Check me chip).
        val one = COUNT.find(t)?.groupValues?.get(1)?.let { number(it) } == 1
        return if (one) null else ask
    }

    /** What a message asks for, without deciding whether it is a quiz request (the AI already decided that). */
    fun lenient(text: String): QuizAsk {
        val t = SPACES.replace(text, " ").trim()
        val n = COUNT.find(t)?.groupValues?.get(1)?.let { number(it) }
        val difficulty = when {
            EASY_NOT_HARD.containsMatchIn(t) -> "easy"
            HARD.containsMatchIn(t) -> "hard"
            EASY.containsMatchIn(t) -> "easy"
            else -> ""
        }
        var focus = TOPIC.find(t)?.groupValues?.get(1).orEmpty()
        TOPIC_END.find(focus)?.let { focus = focus.substring(0, it.range.first) }
        focus = TOPIC_LEAD.replace(focus.trim(), "").trim().trim('"', '\'', '“', '”', ' ')
        var wide = WIDE.containsMatchIn(t)
        if (focus.isEmpty() || HERE.matches(focus)) focus = ""
        else if (BROAD.matches(focus)) { focus = ""; wide = true }
        return QuizAsk(count = n?.coerceIn(3, 10), focus = focus.take(120), difficulty = difficulty, wide = wide)
    }

    private fun number(s: String): Int? = s.toIntOrNull() ?: WORDS[s.lowercase()]
}
