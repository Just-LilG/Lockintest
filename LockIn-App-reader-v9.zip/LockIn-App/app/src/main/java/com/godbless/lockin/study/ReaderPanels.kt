package com.godbless.lockin.study

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.godbless.lockin.home.Glyph
import com.godbless.lockin.home.GlyphIcon
import com.godbless.lockin.ui.RC
import com.godbless.lockin.ui.RT
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min

// =============================================================================================
// The reader's side panels: search, a highlight's editor, display settings, the "more" menu, and
// the layer that draws highlights, bookmarks and search matches over the pages.
// =============================================================================================

/** The four highlight colours, in the order a [Mark.color] counts them. */
internal val MarkColors = listOf(Color(0xFFFFD84D), Color(0xFF6FD98C), Color(0xFF63B3FF), Color(0xFFFF7BAC))

internal fun copyText(context: Context, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return
    cm.setPrimaryClip(ClipData.newPlainText("LockIn", text))
}

// ---------------------------------------------------------------------------------------------
// Trim margins
// ---------------------------------------------------------------------------------------------

/**
 * How much blank margin a book's pages have: looks at a few pages spread through the book and returns the smallest
 * margin seen on each side ([left, top, right, bottom], as fractions of the page), less a little breathing room.
 * One answer for the whole book, so pages keep the same size and the scroll never jumps.
 */
internal suspend fun detectTrim(doc: PdfDoc): FloatArray {
    val n = doc.pageCount
    val picks = if (n <= 8) (0 until n).toList() else List(8) { 1 + it * (n - 2) / 8 }
    var l = 1f; var t = 1f; var r = 1f; var b = 1f
    var seen = 0
    for (p in picks) {
        val bmp = doc.bitmapUncached(p, 360) ?: continue
        val m = withContext(Dispatchers.Default) { contentMargins(bmp) }
        bmp.recycle()
        if (m != null) {
            l = min(l, m[0]); t = min(t, m[1]); r = min(r, m[2]); b = min(b, m[3])
            seen++
        }
    }
    if (seen == 0) return NoTrim.copyOf()
    fun pad(x: Float) = (x - 0.012f).coerceIn(0f, 0.25f)
    return floatArrayOf(pad(l), pad(t), pad(r), pad(b))
}

/** The blank border of one picture, as fractions, or null if the page is empty. Specks smaller than two pixels don't count. */
private fun contentMargins(bmp: Bitmap): FloatArray? {
    val w = bmp.width
    val h = bmp.height
    if (w < 8 || h < 8) return null
    val px = IntArray(w * h)
    bmp.getPixels(px, 0, w, 0, 0, w, h)
    val cols = IntArray(w)
    val rows = IntArray(h)
    for (y in 0 until h) {
        for (x in 0 until w) {
            val c = px[y * w + x]
            val rr = (c shr 16) and 0xFF
            val gg = (c shr 8) and 0xFF
            val bb = c and 0xFF
            if (rr < 225 || gg < 225 || bb < 225) { cols[x]++; rows[y]++ }
        }
    }
    var x0 = 0; while (x0 < w && cols[x0] < 2) x0++
    var x1 = w - 1; while (x1 > x0 && cols[x1] < 2) x1--
    var y0 = 0; while (y0 < h && rows[y0] < 2) y0++
    var y1 = h - 1; while (y1 > y0 && rows[y1] < 2) y1--
    if (x0 >= x1 || y0 >= y1) return null
    return floatArrayOf(x0.toFloat() / w, y0.toFloat() / h, (w - 1 - x1).toFloat() / w, (h - 1 - y1).toFloat() / h)
}

// ---------------------------------------------------------------------------------------------
// What is drawn over the pages
// ---------------------------------------------------------------------------------------------

/** Where the small tabs at a page's top-right corner sit: slot 0 is the bookmark ribbon, slot 1 the page note. */
internal fun tabSpot(pageRect: Rect, viewW: Float, d: Float, slot: Int): Offset =
    Offset(min(pageRect.right, viewW) - (24f + slot * 40f) * d, pageRect.top + 22f * d)

/**
 * Highlights, bookmark ribbons, page-note tabs and search matches, drawn over the pages they belong to. It follows the
 * pages as they scroll and zoom because it asks the list where each page is every time it draws.
 */
@Composable
internal fun MarksLayer(
    marks: List<Mark>,
    bookId: String,
    hits: List<Hit>,
    active: Int,
    list: LazyListState,
    scrollX: () -> Int,
    left: () -> Float,
    pageW: () -> Float,
    trim: () -> FloatArray,
    modifier: Modifier = Modifier,
) {
    val lime = RC.Lime
    Canvas(modifier) {
        val sx = scrollX()
        val lf = left()
        val pw = pageW()
        val tr = trim()
        val d = density
        val visible = list.layoutInfo.visibleItemsInfo.map { it.index }
        if (visible.isEmpty()) return@Canvas
        val radius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
        // Search matches first, so a highlight sits over them.
        for (h in hits) {
            if (h.page !in visible) continue
            for (q in h.rects) {
                val r = fracRect(h.page, q[0], q[1], q[2], q[3], tr, list, sx, lf, pw) ?: continue
                drawRoundRect(lime.copy(alpha = 0.34f), r.topLeft, r.size, radius)
            }
        }
        hits.getOrNull(active)?.let { h ->
            if (h.page in visible) for (q in h.rects) {
                val r = fracRect(h.page, q[0], q[1], q[2], q[3], tr, list, sx, lf, pw) ?: continue
                drawRoundRect(lime, r.topLeft, r.size, radius, style = Stroke(2.dp.toPx()))
            }
        }
        for (m in marks) {
            if (m.book != bookId || m.page !in visible) continue
            when (m.kind) {
                MarkKind.Highlight -> {
                    val c = MarkColors[m.color.coerceIn(0, 3)]
                    var first: Rect? = null
                    for (q in m.rects) {
                        if (q.size < 4) continue
                        val r = fracRect(m.page, q[0], q[1], q[2], q[3], tr, list, sx, lf, pw) ?: continue
                        if (first == null) first = r
                        drawRoundRect(c.copy(alpha = 0.40f), r.topLeft, r.size, radius)
                    }
                    if (m.note.isNotBlank() && first != null) {
                        val at = Offset(first.right + 2.dp.toPx(), first.top + 2.dp.toPx())
                        drawCircle(c, 6.dp.toPx(), at)
                        drawCircle(Color.Black.copy(alpha = 0.55f), 2.2.dp.toPx(), at)
                    }
                }
                MarkKind.Bookmark -> {
                    // The page as it is shown (cropped), not the whole sheet.
                    val pr = fracRect(m.page, tr[0], tr[1], 1f - tr[2], 1f - tr[3], tr, list, sx, lf, pw) ?: continue
                    val c = tabSpot(pr, size.width, d, 0)
                    val path = Path().apply {
                        moveTo(c.x - 9 * d, pr.top)
                        lineTo(c.x + 9 * d, pr.top)
                        lineTo(c.x + 9 * d, pr.top + 36 * d)
                        lineTo(c.x, pr.top + 28 * d)
                        lineTo(c.x - 9 * d, pr.top + 36 * d)
                        close()
                    }
                    drawPath(path, lime)
                }
                MarkKind.Note -> {
                    val pr = fracRect(m.page, tr[0], tr[1], 1f - tr[2], 1f - tr[3], tr, list, sx, lf, pw) ?: continue
                    val c = tabSpot(pr, size.width, d, 1)
                    drawCircle(Color(0xFFFFD84D), 12 * d, c)
                    drawCircle(Color.Black.copy(alpha = 0.7f), 2 * d, c.copy(x = c.x - 5 * d))
                    drawCircle(Color.Black.copy(alpha = 0.7f), 2 * d, c)
                    drawCircle(Color.Black.copy(alpha = 0.7f), 2 * d, c.copy(x = c.x + 5 * d))
                }
            }
        }
    }
}

/** The mark under a touch at [p]: a page-note tab, or a highlight (a little generously). Null if none. */
internal fun markAt(
    p: Offset,
    marks: List<Mark>,
    bookId: String,
    list: LazyListState,
    scrollX: Int,
    left: Float,
    pageW: Float,
    trim: FloatArray,
    viewW: Float,
    d: Float,
): Mark? {
    val visible = list.layoutInfo.visibleItemsInfo.map { it.index }
    for (m in marks.asReversed()) {
        if (m.book != bookId || m.page !in visible) continue
        when (m.kind) {
            MarkKind.Note -> {
                val pr = fracRect(m.page, trim[0], trim[1], 1f - trim[2], 1f - trim[3], trim, list, scrollX, left, pageW) ?: continue
                if ((p - tabSpot(pr, viewW, d, 1)).getDistance() < 24f * d) return m
            }
            MarkKind.Highlight -> {
                for (q in m.rects) {
                    if (q.size < 4) continue
                    val r = fracRect(m.page, q[0], q[1], q[2], q[3], trim, list, scrollX, left, pageW) ?: continue
                    if (r.inflate(6f * d).contains(p)) return m
                }
            }
            MarkKind.Bookmark -> Unit
        }
    }
    return null
}

// ---------------------------------------------------------------------------------------------
// Search
// ---------------------------------------------------------------------------------------------

@Composable
internal fun SearchSheet(
    query: String,
    onQuery: (String) -> Unit,
    hits: List<Hit>,
    read: Int,
    total: Int,
    indexing: Boolean,
    onPick: (Int) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    val field = RoundedCornerShape(24.dp)
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { delay(260); runCatching { focus.requestFocus() } }
    val covered = read >= total
    val q = query.trim()
    val status = when {
        q.length < 2 -> if (covered) "Type at least two letters" else "Type at least two letters · $read of $total pages read so far"
        hits.isEmpty() -> if (covered) "No matches" else "No matches yet · $read of $total pages read"
        else -> "${hits.size}${if (hits.size >= 300) "+" else ""} matches" + if (covered) "" else " so far · $read of $total pages read"
    }
    Column(
        modifier
            .fillMaxWidth()
            .heightIn(max = 520.dp)
            .clip(shape)
            .background(RC.Slate)
            .border(1.dp, RC.Graphite, shape)
            .navigationBarsPadding()
            .imePadding()
            .padding(top = 14.dp),
    ) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(
                Modifier
                    .weight(1f)
                    .height(48.dp)
                    .clip(field)
                    .background(RC.Ink)
                    .border(1.dp, RC.Graphite, field)
                    .padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                GlyphIcon(Glyph.Search, RC.Silver, boxSize = 20.dp)
                Box(Modifier.weight(1f).padding(start = 10.dp), contentAlignment = Alignment.CenterStart) {
                    if (query.isEmpty()) Text("Search this book", style = RT.Input.copy(color = RC.Mist, fontSize = 15.sp))
                    BasicTextField(
                        value = query,
                        onValueChange = { onQuery(it.take(80)) },
                        singleLine = true,
                        textStyle = RT.Input.copy(fontSize = 15.sp),
                        cursorBrush = SolidColor(RC.Lime),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { if (hits.isNotEmpty()) onPick(0) }),
                        modifier = Modifier.fillMaxWidth().focusRequester(focus),
                    )
                }
            }
            Box(
                Modifier.size(48.dp).clip(CircleShape).clickable(role = Role.Button, onClick = onClose),
                contentAlignment = Alignment.Center,
            ) { GlyphIcon(Glyph.Close, RC.Silver, boxSize = 14.dp, strokeWidth = 2.2f) }
        }
        Text(
            status,
            style = RT.Small.copy(color = RC.Mist),
            modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 6.dp),
        )
        if (!covered) {
            Box(
                Modifier.padding(horizontal = 20.dp).fillMaxWidth().height(3.dp).clip(CircleShape).background(RC.Graphite),
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(if (total > 0) (read.toFloat() / total).coerceIn(0f, 1f) else 0f)
                        .height(3.dp)
                        .background(if (indexing) RC.Lime else RC.Mist),
                )
            }
            Spacer(Modifier.height(6.dp))
        }
        LazyColumn(Modifier.fillMaxWidth(), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 12.dp)) {
            itemsIndexed(hits) { i, h ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(min = 56.dp)
                        .clickable(role = Role.Button) { onPick(i) }
                        .padding(horizontal = 20.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "p. ${h.page + 1}",
                        style = RT.Label.copy(color = RC.Lime, fontSize = 13.sp),
                        modifier = Modifier.width(52.dp),
                    )
                    val from = h.snipFrom.coerceIn(0, h.snip.length)
                    val to = h.snipTo.coerceIn(from, h.snip.length)
                    Text(
                        buildAnnotatedString {
                            append(h.snip.substring(0, from))
                            withStyle(SpanStyle(color = RC.Lime, fontWeight = FontWeight.SemiBold)) { append(h.snip.substring(from, to)) }
                            append(h.snip.substring(to))
                        },
                        style = RT.Sub.copy(color = RC.Snow, fontSize = 14.sp),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

/** Steps through the matches once the list is closed. */
@Composable
internal fun SearchPill(
    index: Int,
    total: Int,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onList: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(30.dp)
    Row(
        modifier
            .height(52.dp)
            .clip(shape)
            .background(RC.Slate)
            .border(1.dp, RC.Graphite, shape)
            .padding(horizontal = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(48.dp).clip(CircleShape).clickable(role = Role.Button, onClick = onPrev), contentAlignment = Alignment.Center) {
            Text("‹", style = RT.Title.copy(color = RC.Snow, fontSize = 26.sp))
        }
        Box(
            Modifier.height(48.dp).clip(CircleShape).clickable(role = Role.Button, onClick = onList).padding(horizontal = 10.dp),
            contentAlignment = Alignment.Center,
        ) { Text("${index + 1} / $total", style = RT.Label.copy(color = RC.Snow, fontSize = 14.sp)) }
        Box(Modifier.size(48.dp).clip(CircleShape).clickable(role = Role.Button, onClick = onNext), contentAlignment = Alignment.Center) {
            Text("›", style = RT.Title.copy(color = RC.Snow, fontSize = 26.sp))
        }
        Box(Modifier.width(1.dp).height(20.dp).background(RC.Graphite))
        Box(Modifier.size(48.dp).clip(CircleShape).clickable(role = Role.Button, onClick = onClose), contentAlignment = Alignment.Center) {
            GlyphIcon(Glyph.Close, RC.Silver, boxSize = 12.dp, strokeWidth = 2.2f)
        }
    }
}

// ---------------------------------------------------------------------------------------------
// A highlight, bookmark or note: edit it
// ---------------------------------------------------------------------------------------------

@Composable
internal fun MarkEditor(
    store: StudyStore,
    markId: String,
    onClose: () -> Unit,
    /** Called with the mark just deleted, so the reader can offer Undo. */
    onDeleted: (Mark) -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val m = store.mark(markId)
    if (m == null) {
        LaunchedEffect(markId) { onClose() }
        return
    }
    val context = androidx.compose.ui.platform.LocalContext.current
    var note by remember(markId) { mutableStateOf(m.note) }
    // Saved when the sheet goes, so each key press doesn't rewrite the file.
    DisposableEffect(markId) {
        onDispose {
            store.setMarkNote(markId, note)
            store.dropIfEmptyNote(markId)
        }
    }
    val shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    val field = RoundedCornerShape(16.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(RC.Slate)
            .border(1.dp, RC.Graphite, shape)
            .navigationBarsPadding()
            .imePadding()
            .padding(horizontal = 20.dp, vertical = 18.dp),
    ) {
        Text(
            (if (m.kind == MarkKind.Note) "NOTE" else "HIGHLIGHT") + " · PAGE ${m.page + 1}",
            style = RT.Small.copy(color = RC.Mist, fontSize = 11.sp, letterSpacing = 1.2.sp),
        )
        if (m.text.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(
                m.text,
                style = RT.Sub.copy(color = RC.Snow, fontSize = 15.sp),
                maxLines = 6,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (m.kind == MarkKind.Highlight) {
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                MarkColors.forEachIndexed { i, c ->
                    Box(
                        Modifier.size(48.dp).clip(CircleShape).clickable(role = Role.RadioButton) { store.setMarkColor(markId, i) },
                        contentAlignment = Alignment.Center,
                    ) {
                        Box(
                            Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(c)
                                .border(if (m.color == i) 3.dp else 0.dp, RC.Snow, CircleShape),
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 76.dp)
                .clip(field)
                .background(RC.Ink)
                .border(1.dp, RC.Graphite, field)
                .padding(horizontal = 14.dp, vertical = 12.dp),
        ) {
            if (note.isEmpty()) Text("Add a note…", style = RT.Input.copy(color = RC.Mist, fontSize = 15.sp))
            BasicTextField(
                value = note,
                onValueChange = { note = it.take(2000) },
                textStyle = RT.Input.copy(fontSize = 15.sp),
                cursorBrush = SolidColor(RC.Lime),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (m.text.isNotBlank()) {
                SheetButton("Copy") {
                    copyText(context, m.text)
                    android.widget.Toast.makeText(context, "Copied", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
            SheetButton("Delete") {
                val saved = m
                store.removeMark(markId)
                onDeleted(saved)
                onClose()
            }
            Spacer(Modifier.weight(1f))
            Box(
                Modifier
                    .height(48.dp)
                    .clip(CircleShape)
                    .background(RC.Lime)
                    .clickable(role = Role.Button) { onClose() }
                    .padding(horizontal = 24.dp),
                contentAlignment = Alignment.Center,
            ) { Text("Done", style = RT.Label.copy(color = RC.OnLime, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)) }
        }
    }
}

@Composable
private fun SheetButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier.height(48.dp).clip(CircleShape).clickable(role = Role.Button, onClick = onClick).padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, style = RT.Label.copy(color = RC.Silver, fontSize = 15.sp)) }
}

// ---------------------------------------------------------------------------------------------
// Display ("Aa"): paper, brightness, keep awake, trim margins
// ---------------------------------------------------------------------------------------------

@Composable
internal fun DisplaySheet(
    tone: Int,
    onTone: (Int) -> Unit,
    autoTone: Boolean,
    onAutoTone: (Boolean) -> Unit,
    brightness: Float,
    onBrightness: (Float) -> Unit,
    keepAwake: Boolean,
    onKeepAwake: (Boolean) -> Unit,
    trim: FloatArray,
    onTrimOff: () -> Unit,
    onTrimAuto: () -> Unit,
    onTrimAmount: (Float) -> Unit,
    detecting: Boolean,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    val trimmed = trim.any { it > 0.001f }
    val sliderColors = SliderDefaults.colors(
        thumbColor = RC.Lime,
        activeTrackColor = RC.Lime,
        inactiveTrackColor = RC.Graphite,
    )
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(RC.Slate)
            .border(1.dp, RC.Graphite, shape)
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 18.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Display", style = RT.Title.copy(color = RC.Snow, fontSize = 20.sp), modifier = Modifier.weight(1f))
            Box(Modifier.size(48.dp).clip(CircleShape).clickable(role = Role.Button, onClick = onClose), contentAlignment = Alignment.Center) {
                GlyphIcon(Glyph.Close, RC.Silver, boxSize = 14.dp, strokeWidth = 2.2f)
            }
        }
        Text("PAPER", style = RT.Small.copy(color = RC.Mist, fontSize = 11.sp, letterSpacing = 1.2.sp))
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Light" to Color.White, "Dark" to Color.Black, "Sepia" to Color(0xFFF4EBD6)).forEachIndexed { i, (name, swatch) ->
                Row(
                    Modifier
                        .weight(1f)
                        .height(48.dp)
                        .clip(CircleShape)
                        .background(if (tone == i) RC.Lime else RC.Ink)
                        .border(1.dp, if (tone == i) RC.Lime else RC.Graphite, CircleShape)
                        .clickable(role = Role.RadioButton) { onTone(i) },
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(16.dp).clip(CircleShape).background(swatch).border(1.dp, RC.Rim, CircleShape))
                    Text(
                        name,
                        style = RT.Label.copy(color = if (tone == i) RC.OnLime else RC.Snow, fontSize = 14.sp),
                        modifier = Modifier.padding(start = 8.dp),
                    )
                }
            }
        }
        ToggleRow("Dark paper when the phone is dark", autoTone, onAutoTone)
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("BRIGHTNESS", style = RT.Small.copy(color = RC.Mist, fontSize = 11.sp, letterSpacing = 1.2.sp), modifier = Modifier.weight(1f))
            Chip("Match phone", selected = brightness < 0f) { onBrightness(if (brightness < 0f) 0.6f else -1f) }
        }
        Slider(
            value = if (brightness < 0f) 0.6f else brightness,
            onValueChange = { onBrightness(it.coerceIn(0.02f, 1f)) },
            valueRange = 0.02f..1f,
            colors = sliderColors,
        )
        ToggleRow("Keep screen on", keepAwake, onKeepAwake)
        Spacer(Modifier.height(10.dp))
        Text("MARGINS", style = RT.Small.copy(color = RC.Mist, fontSize = 11.sp, letterSpacing = 1.2.sp))
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Chip("Full page", selected = !trimmed && !detecting) { onTrimOff() }
            Chip(if (detecting) "Measuring…" else "Trim to text", selected = trimmed || detecting) { if (!detecting) onTrimAuto() }
        }
        if (trimmed) {
            Slider(
                value = trim.max().coerceIn(0f, 0.2f),
                onValueChange = { onTrimAmount(it.coerceIn(0f, 0.2f)) },
                valueRange = 0f..0.2f,
                colors = sliderColors,
            )
            Text("Pages keep their text sharp and fill more of the screen. Drag to cut the same amount from every side.", style = RT.Small.copy(color = RC.Mist))
        }
    }
}

@Composable
private fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .height(44.dp)
            .clip(CircleShape)
            .background(if (selected) RC.Lime else RC.Ink)
            .border(1.dp, if (selected) RC.Lime else RC.Graphite, CircleShape)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = RT.Label.copy(color = if (selected) RC.OnLime else RC.Snow, fontSize = 13.sp), maxLines = 1)
    }
}

@Composable
private fun ToggleRow(label: String, on: Boolean, onChange: (Boolean) -> Unit) {
    val x by animateDpAsState(
        if (on) 22.dp else 3.dp,
        if (com.godbless.lockin.ui.MotionState.reduced) snap() else spring(stiffness = 700f),
        label = "toggle",
    )
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 52.dp)
            .clip(RoundedCornerShape(14.dp))
            .clickable(role = Role.Switch) { onChange(!on) },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, style = RT.Label.copy(color = RC.Snow, fontSize = 15.sp), modifier = Modifier.weight(1f))
        Box(
            Modifier
                .width(48.dp)
                .height(28.dp)
                .clip(CircleShape)
                .background(if (on) RC.Lime else RC.Graphite),
        ) {
            Box(
                Modifier
                    .offset(x = x, y = 3.dp)
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(if (on) RC.OnLime else RC.Silver),
            )
        }
    }
}

// ---------------------------------------------------------------------------------------------
// More
// ---------------------------------------------------------------------------------------------

@Composable
internal fun ReaderMoreSheet(
    marksHere: Int,
    onSelect: () -> Unit,
    onNotebook: () -> Unit,
    onNote: () -> Unit,
    onShare: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(RC.Slate)
            .border(1.dp, RC.Graphite, shape)
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 12.dp),
    ) {
        MoreRow(Glyph.Select, "Select text", "Drag over a word or a sentence") { onSelect() }
        MoreRow(Glyph.Notes, "Notebook", if (marksHere > 0) "$marksHere in this book" else "Highlights, notes and bookmarks") { onNotebook() }
        MoreRow(Glyph.Plus, "Note on this page", "A thought you want to find again") { onNote() }
        MoreRow(Glyph.Share, "Share notebook", "Everything from this book as Markdown") { onShare() }
        Box(
            Modifier.fillMaxWidth().height(48.dp).clip(CircleShape).clickable(role = Role.Button, onClick = onClose),
            contentAlignment = Alignment.Center,
        ) { Text("Close", style = RT.Label.copy(color = RC.Mist, fontSize = 14.sp)) }
    }
}

@Composable
private fun MoreRow(glyph: Glyph, title: String, sub: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 60.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(RC.Ink), contentAlignment = Alignment.Center) {
            GlyphIcon(glyph, RC.Lime, boxSize = 20.dp)
        }
        Column(Modifier.weight(1f).padding(start = 14.dp)) {
            Text(title, style = RT.Label.copy(color = RC.Snow, fontSize = 15.sp))
            Text(sub, style = RT.Small.copy(color = RC.Mist))
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Reading pace, the page preview while scrubbing, marks on the slider, small toasts
// ---------------------------------------------------------------------------------------------

/**
 * "about 2 h 10 min left" from how long you have been taking per page: the middle of the gaps between pages you read in
 * this book (gaps over ten minutes are breaks and don't count). Null until there are enough pages to go on.
 */
internal fun readingLeft(store: StudyStore, bookId: String, pagesLeft: Int): String? {
    if (pagesLeft <= 0) return null
    val times = store.reads.filter { it.book == bookId }.map { it.at }.sorted()
    val gaps = times.zipWithNext { a, b -> (b - a) / 1000L }.filter { it in 4..600 }.sorted()
    if (gaps.size < 6) return null
    val perPage = gaps[gaps.size / 2]
    val minutes = (perPage * pagesLeft / 60L).toInt()
    return when {
        minutes < 2 -> "about a minute left"
        minutes < 60 -> "about $minutes min left"
        else -> "about ${minutes / 60} h ${if (minutes % 60 >= 5) "${minutes % 60} min " else ""}left".replace("  ", " ")
    }
}

/**
 * A small picture of the page you are scrubbing to, floating above the slider and following the thumb. [fraction] is where
 * the thumb is along the track (0 to 1).
 */
@Composable
internal fun ScrubPreview(page: Int, total: Int, fraction: Float, doc: PdfDoc, tone: Int, modifier: Modifier = Modifier) {
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(page, doc) {
        delay(70)
        val b = doc.bitmap(page, 240)
        if (b != null) bmp = b
    }
    val image = remember(bmp) { bmp?.asImageBitmap() }
    val shape = RoundedCornerShape(12.dp)
    val w = 96.dp
    androidx.compose.foundation.layout.BoxWithConstraints(modifier.fillMaxWidth().padding(horizontal = 18.dp)) {
        val x = ((maxWidth - w) * fraction.coerceIn(0f, 1f))
        val h = bmp?.let { (w.value * it.height / it.width).dp } ?: 130.dp
        Column(
            Modifier
                .offset(x = x)
                .width(w)
                .clip(shape)
                .background(RC.Slate)
                .border(1.dp, RC.Graphite, shape),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(Modifier.fillMaxWidth().height(h.coerceIn(80.dp, 160.dp)).background(if (tone == 1) Color.Black else Color.White)) {
                if (image != null) {
                    androidx.compose.foundation.Image(
                        image,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = androidx.compose.ui.layout.ContentScale.FillBounds,
                        colorFilter = if (tone == 1) androidx.compose.ui.graphics.ColorFilter.colorMatrix(
                            androidx.compose.ui.graphics.ColorMatrix(
                                floatArrayOf(
                                    -1f, 0f, 0f, 0f, 255f,
                                    0f, -1f, 0f, 0f, 255f,
                                    0f, 0f, -1f, 0f, 255f,
                                    0f, 0f, 0f, 1f, 0f,
                                ),
                            ),
                        ) else null,
                    )
                }
            }
            Text(
                "${page + 1}",
                style = RT.Label.copy(color = RC.Snow, fontSize = 13.sp),
                modifier = Modifier.padding(vertical = 4.dp),
            )
        }
    }
}

/** A thin map under the page slider: pages you have read, bookmarks, and where you have highlighted. */
@Composable
internal fun JumpMarks(store: StudyStore, book: Textbook, modifier: Modifier = Modifier) {
    val read = store.readPagesOf(book.id)
    val bookmarks = store.marks.filter { it.book == book.id && it.kind == MarkKind.Bookmark }.map { it.page }
    val marked = store.marks.filter { it.book == book.id && it.kind != MarkKind.Bookmark }.map { it.page }
    val lit = RC.Lime
    val off = RC.Graphite
    Canvas(modifier.fillMaxWidth().height(14.dp)) {
        val n = book.pages.coerceAtLeast(1)
        val inset = 12.dp.toPx()
        val w = size.width - 2 * inset
        val cells = n.coerceAtMost(80)
        val cw = w / cells
        for (c in 0 until cells) {
            val from = c * n / cells
            val to = ((c + 1) * n / cells).coerceAtLeast(from + 1).coerceAtMost(n)
            val any = read.nextSetBit(from).let { it in 0 until to }
            drawRect(if (any) lit.copy(alpha = 0.55f) else off, Offset(inset + c * cw, size.height - 4.dp.toPx()), Size(cw - 1f, 3.dp.toPx()))
        }
        val denom = (n - 1).coerceAtLeast(1)
        for (p in marked) {
            drawCircle(MarkColors[0], 2.dp.toPx(), Offset(inset + w * p / denom, 3.dp.toPx()))
        }
        for (p in bookmarks) {
            val x = inset + w * p / denom
            drawRect(lit, Offset(x - 1.dp.toPx(), 0f), Size(2.dp.toPx(), size.height - 5.dp.toPx()))
        }
    }
}

/** A line of feedback with one action, for a moment: "Highlighted · Undo". */
@Composable
internal fun UndoPill(text: String, onUndo: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(26.dp)
    Row(
        modifier
            .clip(shape)
            .background(RC.Slate)
            .border(1.dp, RC.Graphite, shape)
            .padding(start = 20.dp, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, style = RT.Label.copy(color = RC.Snow, fontSize = 14.sp))
        Box(
            Modifier.heightIn(min = 48.dp).clip(CircleShape).clickable(role = Role.Button, onClick = onUndo).padding(horizontal = 16.dp),
            contentAlignment = Alignment.Center,
        ) { Text("Undo", style = RT.Label.copy(color = RC.Lime, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)) }
    }
}

/** Shown while the left edge is dragged to change brightness. */
@Composable
internal fun BrightnessHud(value: Float, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(24.dp)
    Row(
        modifier
            .clip(shape)
            .background(RC.Slate)
            .border(1.dp, RC.Graphite, shape)
            .padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("Brightness", style = RT.Label.copy(color = RC.Silver, fontSize = 13.sp))
        Box(Modifier.padding(start = 12.dp).width(90.dp).height(6.dp).clip(CircleShape).background(RC.Graphite)) {
            Box(Modifier.fillMaxWidth(value.coerceIn(0f, 1f)).height(6.dp).background(RC.Lime))
        }
        Text("${(value * 100).toInt()}%", style = RT.Label.copy(color = RC.Snow, fontSize = 13.sp), modifier = Modifier.padding(start = 12.dp))
    }
}

/**
 * The left and right edge (as shares of the sheet's width) of the column of text around a spot on the page:
 * the words nearby are gathered, and the span grows across any word that starts within a small gap of it.
 * Null when there are no words close to the spot (a picture, or a page not read yet).
 */
internal fun columnBounds(pw: PageWords, fx: Float, fy: Float): FloatArray? {
    if (pw.words.isEmpty()) return null
    val i = pw.nearest(fx, fy, 0.15f)
    if (i < 0) return null
    val seed = pw.words[i]
    val band = pw.words.filter { it.b >= fy - 0.15f && it.t <= fy + 0.15f }.sortedBy { it.l }
    var l = seed.l
    var r = seed.r
    val gap = 0.04f
    var grew = true
    while (grew) {
        grew = false
        for (w in band) {
            if (w.l < l && w.r >= l - gap) { l = w.l; grew = true }
            if (w.r > r && w.l <= r + gap) { r = w.r; grew = true }
        }
    }
    if (r - l < 0.1f) return null
    return floatArrayOf(l, r)
}
