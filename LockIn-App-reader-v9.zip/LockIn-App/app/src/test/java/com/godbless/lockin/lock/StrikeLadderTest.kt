package com.godbless.lockin.lock

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class StrikeLadderTest {
    @Test
    fun oneOrTwoHitsOnlySendHome() {
        val l = StrikeLadder()
        assertEquals(1, l.hit(0L))
        assertFalse(l.shouldLockScreen(0L))
        assertEquals(2, l.hit(1_200L))
        assertFalse(l.shouldLockScreen(1_200L))
    }

    @Test
    fun fourHitsInTheWindowSwitchTheScreenOffOnce() {
        val l = StrikeLadder()
        for (i in 0..3) l.hit(i * 1_200L)
        assertTrue(l.shouldLockScreen(3_600L))
        // Not again straight away, however many more hits.
        l.hit(4_800L)
        assertFalse(l.shouldLockScreen(4_800L))
        // After the gap, if it keeps coming back, again.
        for (i in 0..3) l.hit(30_000L + i * 1_200L)
        assertTrue(l.shouldLockScreen(33_600L))
    }

    @Test
    fun hitsOlderThanTheWindowDoNotCount() {
        val l = StrikeLadder()
        l.hit(0L); l.hit(1_200L); l.hit(2_400L)
        // Much later: the old ones have aged out, so this is the first again.
        assertEquals(1, l.hit(60_000L))
        assertFalse(l.shouldLockScreen(60_000L))
    }

    @Test
    fun resetForgetsEverything() {
        val l = StrikeLadder()
        for (i in 0..3) l.hit(i * 1_000L)
        l.reset()
        assertEquals(1, l.hit(4_000L))
        assertFalse(l.shouldLockScreen(4_000L))
    }
}
