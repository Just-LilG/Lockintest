package com.godbless.lockin.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

/** The same phrases tools/quiz-intent.test.mjs checks (it runs these patterns without Android). */
class QuizIntentTest {
    private val requests = listOf(
        "quiz me",
        "Quiz me on this",
        "quiz me on photosynthesis",
        "test me",
        "test me on this page",
        "Test me on Newton's second law, 5 questions",
        "make a quiz",
        "make me a quiz on chapter 3",
        "create a quiz from this",
        "generate a quiz",
        "give me a quiz",
        "give me a hard quiz on this",
        "can you quiz me?",
        "could you test me on this please",
        "can u test my understanding of this",
        "check my understanding",
        "test my knowledge on cells",
        "give me 5 questions on this",
        "give me practice questions",
        "ask me some questions on this",
        "write 8 multiple choice questions",
        "make 6 mcq on algebra",
        "I want a quiz",
        "I need a test on this",
        "do a quick quiz",
        "start a quiz",
        "quiz",
        "a quiz",
        "pop quiz",
        "practice test",
        "mcq",
        "multiple choice quiz please",
        "how about a quiz?",
        "what about a quiz",
        "give me a practice test on photosynthesis",
        "make it a 10 question quiz",
        "quiz me, but make it hard",
        "drill me on this",
        "exam me on the chapter",
        "Quiz me on everything I've read",
        "test me on the whole book",
        "give me three questions on this",
        "make me an easy quiz on fractions",
        "I want a test on the cell cycle",
        "pls quiz me",
        "quiz me on the topic of osmosis",
    )
    private val ordinary = listOf(
        "what is a quiz",
        "why do teachers give a quiz",
        "how do I make a quiz",
        "explain this paragraph",
        "what does this mean",
        "define osmosis",
        "I need to test the formula",
        "why is the test important here",
        "what is the answer to question 3",
        "I want to understand this question",
        "who wrote the quiz",
        "describe the exam format",
        "how can I prepare for the exam",
        "Find the main idea of this paragraph",
        "give me one question on this",
        "ask me 1 question",
        "what is a multiple choice question",
        "tell me about the exam",
        "write a summary",
        "solve 2x + 3 = 11",
        "give me an example",
        "make this simpler",
        "why does this matter here",
        "ask my teacher about this",
        "hi",
        "ok",
        "what does mcq stand for",
        "is this on the test",
        "the test was hard",
        "thanks, that quiz was helpful",
        "can you explain the quiz question on page 3",
    )

    @Test fun quizRequestsAreRecognised() {
        requests.forEach { assertNotNull("missed: $it", QuizIntent.parse(it)) }
    }

    @Test fun ordinaryQuestionsAreLeftAlone() {
        ordinary.forEach { assertNull("false positive: $it", QuizIntent.parse(it)) }
    }

    @Test fun readsTopicCountAndDifficulty() {
        QuizIntent.parse("Test me on Newton's second law, 5 questions")!!.let {
            assertEquals("Newton's second law", it.focus); assertEquals(5, it.count)
        }
        QuizIntent.parse("give me a hard quiz on cell division please")!!.let {
            assertEquals("hard", it.difficulty); assertEquals("cell division", it.focus)
        }
        assertEquals("", QuizIntent.parse("quiz me on this")!!.focus)
        assertEquals("", QuizIntent.parse("quiz me on chapter 3")!!.focus)
        assertEquals(true, QuizIntent.parse("quiz me on everything I've read")!!.wide)
        assertEquals("", QuizIntent.parse("quiz me on hard water")!!.difficulty)
        assertEquals("easy", QuizIntent.parse("make a quiz that is not too hard")!!.difficulty)
        assertEquals(10, QuizIntent.parse("make a 20 question quiz")!!.count)
        assertEquals(3, QuizIntent.parse("give me two questions on this")!!.count)
    }
}
