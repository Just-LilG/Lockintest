/** Maths in the model's JSON replies: LaTeX is full of backslashes, and JSON treats some of them as escapes. */

// \n followed by one of these is LaTeX (\nu, \neq, \nabla...), not a line break.
const NEWLINE_LATEX = /^(?:u|eq|abla|otin|ewline|eg|e)(?![A-Za-z])/;

/**
 * Makes a raw model reply parseable without losing LaTeX. Models often write \frac with ONE backslash inside a JSON
 * string: \f is a valid JSON escape (form feed) so it would silently turn into a control character, and \s, \p, \a...
 * are invalid and make the whole reply unparseable. Any backslash that is not a real JSON escape is doubled. \b \f \r
 * \t followed by a letter are never real escapes in a reply like this (\theta, \frac, \right, \beta), so they are doubled
 * too; \n is doubled only when a LaTeX command that starts with n follows.
 */
export function repairJsonBackslashes(raw: string): string {
  return raw.replace(/\\(u[0-9a-fA-F]{4}|[\s\S])/g, (all, rest: string, offset: number) => {
    if (rest[0] === "u" && rest.length === 5) return all;
    if (rest === "\\" || rest === '"' || rest === "/") return all;
    const next = raw.slice(offset + 2);
    if ("bfrt".includes(rest)) return /^[A-Za-z]/.test(next) ? "\\\\" + rest : all;
    if (rest === "n") return NEWLINE_LATEX.test(next) ? "\\\\n" : all;
    return "\\\\" + rest;
  });
}

const CONTROL: Record<string, string> = { "\b": "\\b", "\f": "\\f", "\t": "\\t", "\r": "\\r" };

/** A string that was already parsed with a LaTeX command swallowed by an escape (formfeed + "rac"): put it back. */
export function unmangleMath(s: string): string {
  return s
    .replace(/[\b\f\t\r](?=[A-Za-z])/g, (c) => CONTROL[c])
    .replace(/\n(?=(?:u|eq|abla|otin|ewline|eg)(?![A-Za-z]))/g, "\\n");
}

/** Is this text safe to show as it is: no formula, display block, code fence, colour, highlight, bold or table row left open? */
export function isBalanced(s: string): boolean {
  const t = s.replace(/\\\$/g, "");
  const display = (t.match(/\$\$/g) ?? []).length;
  if (display % 2) return false;
  if ((t.replace(/\$\$/g, "").match(/\$/g) ?? []).length % 2) return false;
  if ((s.match(/```/g) ?? []).length % 2) return false;
  if (/\{(?:lime|sky|amber|flare)\|[^}]*$/.test(s)) return false;
  if ((s.match(/==/g) ?? []).length % 2) return false;
  if ((s.match(/\*\*/g) ?? []).length % 2) return false;
  const last = s.slice(s.lastIndexOf("\n") + 1).trim();
  if (last.startsWith("|") && !last.endsWith("|")) return false;
  return true;
}

const ELLIPSIS_OWN_LINE = (s: string) => {
  const last = s.slice(s.lastIndexOf("\n") + 1).trim();
  return last.startsWith("|") || last.endsWith("$$") || last.endsWith("```");
};
const withEllipsis = (s: string) => s + (ELLIPSIS_OWN_LINE(s) ? "\n\n…" : " …");

/**
 * Keeps a model's maths from breaking the app: unbalanced $ pairs are left alone (the app reads a lone $ as money). A
 * reply that is too long is cut back to the end of a line or sentence where nothing is left open (a formula, a display
 * block, a fence, a colour, a table row), and marked with an ellipsis, so it never ends mid-word or mid-formula.
 */
export function cleanMathText(v: unknown, max: number): string {
  let s = unmangleMath(String(v ?? "")).replace(/\u0000/g, "").trim();
  if (s.length <= max) return s;
  const room = Math.max(1, max - 2); // for the ellipsis
  const head = s.slice(0, room);
  // Where a cut would be clean, nearest the limit first: after a line, then after a sentence.
  const ends: number[] = [];
  for (const m of head.matchAll(/\n|[.!?](?=\s|$)/g)) ends.push(m.index! + (m[0] === "\n" ? 0 : 1));
  for (let i = ends.length - 1; i >= 0; i--) {
    if (ends[i] < room * 0.5) break;
    const cut = head.slice(0, ends[i]).trimEnd();
    if (isBalanced(cut)) return withEllipsis(cut);
  }
  // No clean end in the last half: cut at a space, then undo whatever is left open.
  let cut = head.slice(0, Math.max(head.lastIndexOf(" "), room * 0.5)).trimEnd();
  for (let guard = 0; guard < 8 && !isBalanced(cut); guard++) {
    const open = Math.max(cut.lastIndexOf("$"), cut.lastIndexOf("```"), cut.lastIndexOf("{"), cut.lastIndexOf("=="), cut.lastIndexOf("**"), cut.lastIndexOf("\n|"));
    cut = (open > 0 ? cut.slice(0, open) : cut.slice(0, cut.lastIndexOf(" "))).trimEnd();
  }
  return withEllipsis(cut);
}
