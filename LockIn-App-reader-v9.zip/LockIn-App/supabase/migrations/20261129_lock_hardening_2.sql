-- Lock hardening, round 2 (0.31.1).
--
--   1. Warnings that waited for a connection used to void a lock only if they arrived within an hour of it ending.
--      Keep the phone offline for that hour and a lock whose protection was switched off still counted as clean.
--      Now the phone says how long ago it happened (p_ago), the server finds the lock that was running THEN, and a
--      warning is still accepted up to 3 days late. If the time doesn't line up with any lock (say the clock was moved
--      to backdate it), it voids the most recent lock instead of none.
--   2. A repeating lock skipped because its owner turned locks off, or lowered the longest lock they allow, used to
--      vanish without a word. The partner now gets a note in the chat (lock_repeat_skipped|minutes|off or cap).

-- ---------------------------------------------------------------------------------------------------------------
-- 1. Voiding by when it happened

drop function if exists public._lock_void(uuid, text);

create or replace function public._lock_void(p_target uuid, k text, p_ago int default 0, p_window interval default interval '1 hour')
returns void language plpgsql security definer set search_path to '' as $$
declare
  r record;
  hit boolean := false;
  t timestamptz := now() - make_interval(secs => greatest(0, least(coalesce(p_ago, 0), 604800)));
begin
  -- The lock that was running when it happened.
  for r in
    update public.partner_locks
       set voided_at = coalesce(voided_at, now()), void_kind = coalesce(void_kind, k)
     where id = (
       select l.id from public.partner_locks l
        where l.target = p_target and l.voided_at is null
          and l.starts_at <= t and (l.ended_at is null or l.ended_at >= t)
        order by l.starts_at desc limit 1)
    returning id
  loop
    hit := true;
    delete from public.sessions where id = public._lock_session_id(r.id);
  end loop;
  if hit then return; end if;
  -- None lined up: the most recent lock that is running, or ended inside the window.
  for r in
    update public.partner_locks
       set voided_at = coalesce(voided_at, now()), void_kind = coalesce(void_kind, k)
     where id = (
       select l.id from public.partner_locks l
        where l.target = p_target and l.voided_at is null and l.starts_at <= now()
          and (l.ended_at is null or l.ended_at > now() - p_window)
        order by l.starts_at desc limit 1)
    returning id
  loop
    delete from public.sessions where id = public._lock_session_id(r.id);
  end loop;
end $$;

revoke all on function public._lock_void(uuid, text, int, interval) from public, anon, authenticated;

-- The locked phone's warning. p_ago: seconds since it happened (0 = just now); older apps send nothing.
drop function if exists public.lock_tamper(text, text);

create or replace function public.lock_tamper(p_kind text, p_detail text default '', p_ago int default 0)
returns bigint language plpgsql security definer set search_path to '' as $$
declare me uuid := auth.uid(); pid uuid; mid bigint; k text := left(coalesce(p_kind, ''), 20); d text := left(regexp_replace(coalesce(p_detail, ''), '[^0-9]', '', 'g'), 6);
begin
  if me is null then raise exception 'not_signed_in'; end if;
  if k not in ('stopped', 'overlay_off', 'admin_off', 'time_changed', 'emergency_dial', 'safe_mode', 'usage_off', 'guard_off', 'silent') then raise exception 'bad_kind'; end if;
  if not exists (select 1 from public.partner_locks where target = me and starts_at <= now()
                  and (ended_at is null or ended_at > now() - interval '3 days')) then
    return null;
  end if;
  select pr.pid into pid from public._pair_of(me) pr;
  if pid is null then return null; end if;
  if public._void_kind(k) then perform public._lock_void(me, k, p_ago, interval '3 days'); end if;
  insert into public.messages (partnership_id, sender, kind, body)
  values (pid, me, 'event', 'lock_tamper|' || k || case when d <> '' then '|' || d else '' end)
  returning id into mid;
  return mid;
end $$;

revoke all on function public.lock_tamper(text, text, int) from public, anon;
grant execute on function public.lock_tamper(text, text, int) to authenticated;

-- ---------------------------------------------------------------------------------------------------------------
-- 2. A repeating lock skipped because of the owner's own settings is told to the partner

create or replace function public._fire_due(p_target uuid)
returns void language plpgsql security definer set search_path to '' as $$
declare
  s record;
  local_now timestamp;
  d date;
  start_local timestamp;
  start_ts timestamptz;
  v_allowed boolean;
  v_max int;
  v_pid uuid;
  v_other uuid;
begin
  for s in select * from public.lock_schedules where target = p_target loop
    local_now := now() at time zone s.tz;
    -- Yesterday first: a late run of last night's lock comes before today's.
    foreach d in array array[local_now::date - 1, local_now::date] loop
      continue when (s.days & (1 << (extract(isodow from d)::int - 1))) = 0;
      continue when s.last_fired_on is not distinct from d;
      start_local := d + make_interval(mins => s.start_minute);
      continue when local_now < start_local or local_now >= start_local + make_interval(secs => s.seconds);
      -- Still the same two people.
      select pr.pid, pr.other into v_pid, v_other from public._pair_of(s.locker) pr;
      continue when v_other is distinct from s.target;
      select pf.lock_allowed, pf.lock_max_seconds into v_allowed, v_max from public.profiles pf where pf.id = s.target;
      -- Not allowed: skip this one without trying again every minute, and say so.
      if v_allowed is false or s.seconds > coalesce(v_max, 28800) then
        update public.lock_schedules set last_fired_on = d where id = s.id;
        s.last_fired_on := d;
        insert into public.messages (partnership_id, sender, kind, body)
        values (v_pid, s.target, 'event',
                'lock_repeat_skipped|' || (s.seconds / 60)::text || '|' || case when v_allowed is false then 'off' else 'cap' end);
        continue;
      end if;
      perform public._lock_tidy(s.target);
      continue when exists (select 1 from public.partner_locks where target = s.target and ended_at is null);
      start_ts := start_local at time zone s.tz;
      begin
        insert into public.partner_locks (locker, target, seconds, starts_at, ends_at, message, strict, together)
        values (s.locker, s.target, s.seconds, start_ts, start_ts + make_interval(secs => s.seconds), s.message, s."strict", false);
      exception when unique_violation or raise_exception then
        -- Already locked, or an unpair request is open: leave this one. Anything else is a real error and surfaces.
        update public.lock_schedules set last_fired_on = d where id = s.id;
        s.last_fired_on := d;
        continue;
      end;
      update public.lock_schedules set last_fired_on = d where id = s.id;
      s.last_fired_on := d;
      insert into public.messages (partnership_id, sender, kind, body)
      values (v_pid, s.locker, 'event', 'lock_set|' || (s.seconds / 60)::text);
    end loop;
  end loop;
end $$;
