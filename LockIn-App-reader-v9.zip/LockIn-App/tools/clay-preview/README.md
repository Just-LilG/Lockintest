# Clay calculator preview

`clay.html` draws the calculator's clay look on a canvas using only what Compose's `DrawScope` has (rounded rects, gradients,
clip, even-odd fills, layered shadows), so it shows what `study/CalcLook.kt` paints without building the app.
Open it in a browser (`?t=light` or `?t=dark`, `&p=5` presses key 5, `&lit=SHIFT` or `&lit=pad0` lights a key).
`node shot.js "t=dark" out.png` saves a screenshot (needs Playwright). Keep the two in step when you change the look:
the palette is `ClayPalette`, the shadow maths is `softShadow`/`insetShadow`, the key is `drawClayBody`.
