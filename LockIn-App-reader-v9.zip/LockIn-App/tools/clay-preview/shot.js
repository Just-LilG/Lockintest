const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:360,height:800},deviceScaleFactor:2});
const qs=process.argv[2]||'t=light', out=process.argv[3]||'out.png';
pg.on('pageerror',e=>console.log('ERR',e.message));pg.on('console',m=>{if(m.type()==='error')console.log('CON',m.text())});
await pg.goto('file://'+process.cwd()+'/'+(process.argv[4]||'clay.html')+'?'+qs);await pg.waitForFunction(()=>document.title==='done',null,{timeout:8000});
await pg.locator('canvas').screenshot({path:out});await b.close()})();
