// Re-run from the repo root after touching QuizIntent.kt:  node tools/quiz-intent.test.mjs
// Runs the regex sources straight from QuizIntent.kt through a line-for-line port of its parse()/lenient().
import fs from "node:fs";
import assert from "node:assert/strict";
const src = fs.readFileSync(process.argv[2] ?? "app/src/main/java/com/godbless/lockin/study/QuizIntent.kt", "utf8");
const P = {};
for (const m of src.matchAll(/private val (\w+) = Regex\("""(.*?)""", RegexOption\.IGNORE_CASE\)/g)) P[m[1]] = new RegExp(m[2], "i");
const WORDS = { one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10 };
const number = (s) => (/^\d+$/.test(s) ? parseInt(s, 10) : WORDS[s.toLowerCase()] ?? null);
const full = (re, s) => new RegExp("^(?:" + re.source + ")$", "i").test(s);
function lenient(text) {
  const t = text.replace(/\s+/g, " ").trim();
  const n = (P.COUNT.exec(t) || [])[1]; const count = n ? number(n) : null;
  const difficulty = P.EASY_NOT_HARD.test(t) ? "easy" : P.HARD.test(t) ? "hard" : P.EASY.test(t) ? "easy" : "";
  let focus = (P.TOPIC.exec(t) || [])[1] ?? "";
  const e = P.TOPIC_END.exec(focus); if (e) focus = focus.slice(0, e.index);
  focus = focus.trim().replace(P.TOPIC_LEAD, "").trim().replace(/^["'\u201c\u201d ]+|["'\u201c\u201d ]+$/g, "");
  let wide = P.WIDE.test(t);
  if (focus === "" || full(P.HERE, focus)) focus = "";
  else if (full(P.BROAD, focus)) { focus = ""; wide = true; }
  return { count: count == null ? null : Math.min(10, Math.max(3, count)), focus: focus.slice(0, 120), difficulty, wide };
}
function parse(text) {
  const t = text.replace(/\s+/g, " ").trim();
  if (t.length < 3 || t.length > 240) return null;
  const named = P.ME.test(t);
  if (!named && P.ABOUT.test(t)) return null;
  if (!(named || P.OFFER.test(t) || P.KNOW.test(t) || P.QS.test(t) || P.MAKE.test(t) || P.BARE.test(t))) return null;
  const c = (P.COUNT.exec(t) || [])[1];
  if (c && number(c) === 1) return null;
  return lenient(t);
}
const yes = [
  "quiz me", "Quiz me on this", "quiz me on photosynthesis", "test me", "test me on this page", "Test me on Newton's second law, 5 questions",
  "make a quiz", "make me a quiz on chapter 3", "create a quiz from this", "generate a quiz", "give me a quiz", "give me a hard quiz on this",
  "can you quiz me?", "could you test me on this please", "can u test my understanding of this", "check my understanding", "test my knowledge on cells",
  "give me 5 questions on this", "give me practice questions", "ask me some questions on this", "write 8 multiple choice questions", "make 6 mcq on algebra",
  "I want a quiz", "I need a test on this", "do a quick quiz", "start a quiz", "quiz", "a quiz", "pop quiz", "practice test", "mcq", "multiple choice quiz please",
  "how about a quiz?", "what about a quiz", "give me a practice test on photosynthesis", "make it a 10 question quiz", "quiz me, but make it hard",
  "drill me on this", "exam me on the chapter", "Quiz me on everything I've read", "test me on the whole book", "give me three questions on this",
  "make me an easy quiz on fractions", "I want a test on the cell cycle", "pls quiz me", "quiz me on the topic of osmosis",
];
const no = [
  "what is a quiz", "why do teachers give a quiz", "how do I make a quiz", "explain this paragraph", "what does this mean", "define osmosis",
  "I need to test the formula", "why is the test important here", "what is the answer to question 3", "I want to understand this question",
  "who wrote the quiz", "describe the exam format", "how can I prepare for the exam", "Find the main idea of this paragraph",
  "give me one question on this", "ask me 1 question", "what is a multiple choice question", "tell me about the exam", "write a summary",
  "solve 2x + 3 = 11", "give me an example", "make this simpler", "why does this matter here", "ask my teacher about this", "hi", "ok",
  "what does mcq stand for", "is this on the test", "the test was hard", "thanks, that quiz was helpful", "can you explain the quiz question on page 3",
];
const bad = [];
for (const q of yes) if (!parse(q)) bad.push("MISSED  : " + q);
for (const q of no) if (parse(q)) bad.push("FALSE+  : " + q + " -> " + JSON.stringify(parse(q)));
// what is extracted
const eq = (q, want) => { const g = parse(q); if (!g) { bad.push("NULL    : " + q); return; } for (const k of Object.keys(want)) if (g[k] !== want[k]) bad.push(`FIELD ${k}: "${q}" got ${JSON.stringify(g[k])} want ${JSON.stringify(want[k])}`); };
eq("quiz me on photosynthesis", { focus: "photosynthesis", count: null, difficulty: "", wide: false });
eq("quiz me on this", { focus: "", wide: false });
eq("Test me on Newton's second law, 5 questions", { focus: "Newton's second law", count: 5 });
eq("give me 5 questions on this", { count: 5, focus: "" });
eq("give me a hard quiz on cell division please", { difficulty: "hard", focus: "cell division" });
eq("quiz me on osmosis with 4 questions", { focus: "osmosis", count: 4 });
eq("make me an easy quiz on fractions", { difficulty: "easy", focus: "fractions" });
eq("quiz me on hard water", { difficulty: "", focus: "hard water" });
eq("quiz me on simple harmonic motion", { difficulty: "", focus: "simple harmonic motion" });
eq("make a quiz that is not too hard", { difficulty: "easy" });
eq("Quiz me on everything I've read", { focus: "", wide: true });
eq("test me on the whole book", { focus: "", wide: true });
eq("quiz me on chapter 3", { wide: true, focus: "" });
eq("make a 20 question quiz", { count: 10 });
eq("give me two questions on this", { count: 3 }); // "two" is not in the number words: no count
eq("quiz me on the topic of osmosis", { focus: "osmosis" });
eq("quiz me on \"ionic bonds\"", { focus: "ionic bonds" });
eq("quiz me about the French revolution and make it hard", { focus: "the French revolution", difficulty: "hard" });
console.log(bad.length ? bad.join("\n") : "quiz intent ok", `(${yes.length} yes, ${no.length} no)`);
process.exit(bad.length ? 1 : 0);
